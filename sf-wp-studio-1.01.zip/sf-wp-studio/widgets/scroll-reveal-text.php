<?php

namespace SFWPStudio\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

if (! defined('ABSPATH')) exit;

class Scroll_Reveal_Text extends Widget_Base
{
    use \SFWPStudio\Core\Helpers\Traits\ListTrait;

    public function get_name()
    {
        return 'sf_scroll_word_reveal';
    }

    public function get_title()
    {
        return __('SF Scroll Word Reveal', 'sfwpstudio');
    }

    public function get_icon()
    {
        return 'eicon-animation';
    }

    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function get_script_depends()
    {
        return ['scroll-reveal-text'];
    }

    protected function register_controls()
    {
        // Heading
        $this->start_controls_section(
            'heading_section',
            [
                'label' => __('Heading', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'text_heading',
            [
                'label' => __('Heading Text', 'sf-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter your heading', 'sf-widget'),
            ]
        );

        $this->add_control(
            'text_heading_tag',
            [
                'label' => __('Heading Tag', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'h2',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'P',
                    'div' => 'DIV',
                ],
                'condition' => [
                    'text_heading!' => '',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'description_section',
            [
                'label' => __('Description', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'text_description',
            [
                'label' => __('Description Text', 'sf-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('With 20 + years in business, 30 000 + companies served, and tools trusted by over 1 million developers worldwide, the team behind Syncfusion now brings you BoldSales: sell faster, smarter, and without the bloat.', 'sf-widget'),
                'placeholder' => __('Enter your description text', 'sf-widget'),
            ]
        );

        $this->add_control(
            'text_description_tag',
            [
                'label' => __('Description Tag', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'h4',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'P',
                    'div' => 'DIV',
                ],
                'condition' => [
                    'text_description!' => '',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'paragraph_section',
            [
                'label' => __('Paragraph', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_paragraph',
            [
                'label' => __('Enable Paragraph', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('On', 'sf-widget'),
                'label_off' => __('Off', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'Off',
            ]
        );

        $this->add_control(
            'text_paragraph',
            [
                'label' => __('Paragraph Text', 'sf-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Grow your {report}', 'sf-widget'),
                'placeholder' => __('Enter your heading, use {text} for focused part', 'sf-widget'),
                'description' => __('"Focused Title" Settings will be worked, if you use this {something} format', 'sf-widget'),
                'condition' => [
                    'enable_paragraph' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'paragraph_link',
            [
                'label' => __('Paragraph Link', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'sf-widget'),
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'enable_paragraph' => 'yes',
                    'text_paragraph!' => '',
                ],
            ]
        );

        $this->add_control(
            'text_paragraph_tag',
            [
                'label' => __('Paragraph Tag', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'p',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'P',
                    'div' => 'DIV',
                ],
                'condition' => [
                    'enable_paragraph' => 'yes',
                    'text_paragraph!' => '',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'animation_section',
            [
                'label' => __('Animation', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_heading_animation',
            [
                'label' => __('Enable Heading Animation', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('On', 'sf-widget'),
                'label_off' => __('Off', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'enable_description_animation',
            [
                'label' => __('Enable Description Animation', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('On', 'sf-widget'),
                'label_off' => __('Off', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Section for Wrapper
        $this->start_controls_section(
            'style_wrapper_section',
            [
                'label' => __('Wrapper', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'scroll_section_background',
                'label' => __('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .scroll-section, {{WRAPPER}} .static-wrapper',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ]
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_width_scroll',
            [
                'label' => __('Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 80,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 95,
                ],
                'selectors' => [
                    '{{WRAPPER}} .inner' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'scroll_section_min_height',
            [
                'label' => __('Min Height', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5000,
                        'step' => 1,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'vh',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .scroll-section, {{WRAPPER}} .static-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .scroll-wrapper, {{WRAPPER}} .static-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label' => __('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .scroll-wrapper, {{WRAPPER}} .static-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'wrapper_justify_content',
            [
                'label' => __('Justify Content', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'sf-widget'),
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'sf-widget'),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'sf-widget'),
                        'icon' => 'eicon-flex eicon-justify-end-h',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .scroll-section, {{WRAPPER}} .static-wrapper' => 'display: flex; justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_align_items',
            [
                'label' => __('Align Items', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'flex-start' => __('Start', 'sf-widget'),
                    'center'     => __('Center', 'sf-widget'),
                    'flex-end'   => __('End', 'sf-widget'),
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .scroll-section, {{WRAPPER}} .static-wrapper' => 'display: flex; align-items: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'wrapper_flex_direction',
            [
                'label' => __('Flex Direction', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'column' => __('Column', 'sf-widget'),
                    'row' => __('Row', 'sf-widget'),
                ],
                'default' => 'column',
                'selectors' => [
                    '{{WRAPPER}} .inner' => 'display: flex; flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_heading_section',
            [
                'label' => __('Heading', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .text_heading',
            ]
        );

        $this->add_control(
            'heading_color',
            [
                'label' => __('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text_heading' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->add_control(
            'heading_alignment',
            [
                'label' => __('Text Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .text_heading' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'heading_padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .text_heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'heading_margin',
            [
                'label' => __('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .text_heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_description_section',
            [
                'label' => __('Description', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .text_description',
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text_description' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->add_control(
            'description_justify_content',
            [
                'label' => __('Block Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'sf-widget'),
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'sf-widget'),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'sf-widget'),
                        'icon' => 'eicon-flex eicon-justify-end-h',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .text-wrapper' => 'align-self: {{VALUE}};',
                ],
                'condition' => [
                    'text_description!' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_width',
            [
                'label' => __('Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .text-wrapper' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'text_description!' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .text_description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_margin',
            [
                'label' => __('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .text_description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section for paragraph
        $this->start_controls_section(
            'style_paragraph_section',
            [
                'label' => __('Paragraph', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'enable_paragraph' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'Paragraph_typography',
                'label' => __('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .text_paragraph',
            ]
        );

        $this->add_control(
            'paragraph_color',
            [
                'label' => __('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text_paragraph' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'paragraph_link_color',
            [
                'label' => __('Paragraph Link Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text_paragraph a' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'enable_paragraph' => 'yes',
                    'text_paragraph!' => '',
                ],
            ]
        );

        $this->add_control(
            'paragraph_alignment',
            [
                'label' => __('Text Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .text_paragraph' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'paragraph_padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .text_paragraph' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'paragraph_margin',
            [
                'label' => __('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .text_paragraph' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // List Control

        $this->register_list_controls("no", "row");
        
    }

    protected function render()
    {
        echo '<div class="ekit-wid-con" >';
        $this->render_raw();
        echo '</div>';
    }

    protected function render_raw()
{
    $settings = $this->get_settings_for_display();
    $raw_paragraph_text = $settings['text_paragraph'] ?? '';
    $paragraph_text = $raw_paragraph_text;

    $has_focused_text = false;
    $focused_text = '';

    if ($settings['enable_paragraph'] === 'yes' && preg_match('/\{([^}]+)\}/', $raw_paragraph_text, $matches)) {
        $focused_text = $matches[1];
        $has_focused_text = true;
        $paragraph_text = preg_replace('/\{[^}]+\}/', '<span class="focused-text">' . esc_html($focused_text) . '</span>', $raw_paragraph_text, 1);
    }
 
    if (!$has_focused_text) {
        $paragraph_text = esc_html($raw_paragraph_text);
    }

    $wrapper_class = ($settings['enable_heading_animation'] === 'yes' || $settings['enable_description_animation'] === 'yes') ? 'scroll-wrapper' : 'static-wrapper';
    ?>
    <div class="<?php echo esc_attr($wrapper_class); ?>">
        <div class="scroll-section">
            <div class="inner">
                <?php if (!empty($settings['text_heading'])) : ?>
                    <<?php echo esc_attr($settings['text_heading_tag']); ?> class="text_heading" <?php if ($settings['enable_heading_animation'] === 'yes') : ?> id="scrollText" <?php endif; ?>>
                        <?php echo esc_html($settings['text_heading']); ?>
                    </<?php echo esc_attr($settings['text_heading_tag']); ?>>
                <?php endif; ?>

                <?php if (!empty($settings['text_description'])) : ?>
                    <div class="text-wrapper">
                        <<?php echo esc_attr($settings['text_description_tag']); ?> class="text_description" <?php if ($settings['enable_description_animation'] === 'yes') : ?> id="scrollText" <?php endif; ?>>
                            <?php echo esc_html($settings['text_description']); ?>
                        </<?php echo esc_attr($settings['text_description_tag']); ?>>
                    </div>
                <?php endif; ?>

                <?php $this->render_list(); ?>

                <?php if ($settings['enable_paragraph'] === 'yes' && !empty($raw_paragraph_text)) : ?>
                    <<?php echo esc_attr($settings['text_paragraph_tag']); ?> class="text_paragraph">
                        <?php if (!empty($settings['paragraph_link']['url'])) : ?>
                            <a href="<?php echo esc_url($settings['paragraph_link']['url']); ?>"
                               <?php if ($settings['paragraph_link']['is_external']) : ?> target="_blank" <?php endif; ?>
                               <?php if ($settings['paragraph_link']['nofollow']) : ?> rel="nofollow" <?php endif; ?>>
                                <?php echo $paragraph_text; // Already processed and safe ?>
                            </a>
                        <?php else : ?>
                            <?php echo $paragraph_text; ?>
                        <?php endif; ?>
                    </<?php echo esc_attr($settings['text_paragraph_tag']); ?>>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}
}
?>