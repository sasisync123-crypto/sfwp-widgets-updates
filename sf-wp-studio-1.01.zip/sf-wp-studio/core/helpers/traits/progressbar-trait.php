<?php

namespace SFWPStudio\Core\Helpers\Traits;

use \Elementor\Controls_Manager;
use \Elementor\Repeater;

trait Progressbar_Trait
{
    public function add_progressbar_control($context, $condition = [])
    {
        $default_condition = ['enable_autoplay' => 'yes'];
        $merged_condition = array_merge($default_condition, $condition);

        $context->add_control(
            'progressbar_duration',
            [
                'label' => esc_html__('Animation Duration (ms)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1000,
                        'max' => 20000,
                        'step' => 500,
                    ],
                ],
                'default' => ['size' => 5000],
                'condition' => $merged_condition,
            ]
        );

        $context->add_control(
            'progressbar_color',
            [
                'label' => esc_html__('Progress Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'condition' => $merged_condition,
            ]
        );
    }
    protected function render_progressbar($settings)
    {
        $duration = $settings['progressbar_duration']['size'] ?? 5000;
        $color = $settings['progressbar_color'] ?? '#10b981';
        ?>
        <div class="sf-progress-wrapper" data-duration="<?php echo esc_attr($duration); ?>" style="display: none;">
            <div class="sf-progress-bar">
                <div class="sf-progress-fill" style="background: <?php echo esc_attr($color); ?>;"></div>
            </div>
        </div>
        <?php
    }
}