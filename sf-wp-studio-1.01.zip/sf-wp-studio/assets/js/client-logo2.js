(function ($) {
    'use strict';

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/sf-client-logo2.default',
            function ($scope) {
                setTimeout(() => initLogoCarousel($scope[0]), 0);
            }
        );
    });

    function initLogoCarousel(wrapper) {
        const track = wrapper.querySelector('.sf-logo-track');
        const items = wrapper.querySelectorAll('.sf-logo-item');
        if (!track || !items.length) return;

        const dirMult = 1;

        const originalCount = items.length / 2;
        const itemWidth = items[0].offsetWidth;
        const gap = parseFloat(getComputedStyle(track).gap) || 0;
        const itemFullWidth = itemWidth + gap;
        const totalWidth = originalCount * itemFullWidth;

        for (let i = 0; i < originalCount; i++) {
            track.appendChild(items[i].cloneNode(true));
        }

        let current = 0;
        let rafId = null;
        let lastTime = 0;

        const setTransform = () => {
            track.style.transform = `translateX(${current}px)`;
        };

        const resetSeamless = () => {
            if (current <= -totalWidth * 2) {
                current += totalWidth;
                track.style.transition = 'none';
                setTransform();
                void track.offsetHeight;
                track.style.transition = '';
            }
        };

        const animate = (time) => {
            if (!lastTime) lastTime = time;
            const delta = time - lastTime;
            lastTime = time;

            const rect = wrapper.getBoundingClientRect();
            const vh = window.innerHeight;

            if (rect.top < vh && rect.bottom > 0) {
                const progress = Math.max(0, Math.min(1, (vh - rect.top) / (vh + rect.height)));
                const target = -progress * totalWidth * dirMult;
                current += (target - current) * 0.08;
                resetSeamless();
            }

            setTransform();
            rafId = requestAnimationFrame(animate);
        };

        rafId = requestAnimationFrame(animate);

        const cleanup = () => rafId && cancelAnimationFrame(rafId);
        window.addEventListener('beforeunload', cleanup);
        wrapper.cleanupLogoCarousel = cleanup;
    }
})(jQuery);