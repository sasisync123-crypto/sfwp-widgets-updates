(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/sf-client-logo.default',
            function ($scope) {
                initClientLogo($scope);
            }
        );
    });

    function initClientLogo($scope) {
        var t = $scope.find(".elementskit-clients-slider").data("config");
        console.log("Client Logo config:", t);

        if (t.arrows) {
            t.navigation = {
                prevEl: $scope.find(".swiper-button-prev").get(0),
                nextEl: $scope.find(".swiper-button-next").get(0),
            };
        }

        if (t.dots) {
            t.pagination = {
                el: $scope.find(".swiper-pagination").get(0),
                type: "bullets",
                clickable: true,
            };
        }

        let n = $scope.find(`.${elementorFrontend.config.swiperClass}`);
        ElementsKit_Helper.swiper(n, t).then(function (swiperInstance) {
            if (t.autoplay && t.pauseOnHover) {
                n.hover(
                    function () {
                        swiperInstance.autoplay.stop();
                    },
                    function () {
                        swiperInstance.autoplay.start();
                    }
                );
            }
        });
    }
})(jQuery);

