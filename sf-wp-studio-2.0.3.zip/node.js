// deploy.js
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const simpleGit = require('simple-git');

const VERSION = '2.0.3';
const PLUGIN_NAME = 'sf-wp-studio';
const SOURCE_DIR = process.cwd(); // where you run deploy.js
const TARGET_DIR = 'D:/Browser-Downloads/sfwp-widgets-updates';
const REPO_URL = 'https://github.com/sasisync123-crypto/sfwp-widgets-updates.git';
const BRANCH = 'main';

async function zipSourceFolder() {
  const zipPath = path.join(TARGET_DIR, `${PLUGIN_NAME}-${VERSION}.zip`);
  const output = fs.createWriteStream(zipPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(SOURCE_DIR, false); // zip current folder
    archive.finalize();
  });
}

function writeUpdateJson() {
  const jsonPath = path.join(TARGET_DIR, 'update.json');
  const jsonData = {
    name: 'Sasi widget',
    version: VERSION,
    download_url: `https://github.com/sasisync123-crypto/sfwp-widgets-updates/raw/${BRANCH}/${PLUGIN_NAME}-${VERSION}.zip`,
    sections: {
      description: 'Powerful widget from sfwp team'
    }
  };
  fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2));
  return jsonPath;
}

async function pushProductionFolder() {
  const git = simpleGit(TARGET_DIR);

  const remotes = await git.getRemotes(true);
  const hasOrigin = remotes.some(r => r.name === 'origin');
  if (!hasOrigin) {
    await git.addRemote('origin', REPO_URL);
  }

  await git.add(['*.zip', 'update.json']);
  await git.commit(`Deploy version ${VERSION}`);
  await git.push('origin', BRANCH);

  console.log(`✅ Deployed ${VERSION} to GitHub from production folder`);
}

async function deploy() {
  await zipSourceFolder();
  writeUpdateJson();
  await pushProductionFolder();
}

deploy().catch(err => {
  console.error('❌ Deployment failed:', err);
});
