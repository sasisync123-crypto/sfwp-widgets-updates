<?php
namespace SFWPStudio\Widgets;
// Elementor Base
use Elementor\Controls_Manager;
use Elementor\Repeater;

// Group Controls
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

// Media & Icons
use Elementor\Icons_Manager;
use Elementor\Plugin;


if (!defined('ABSPATH'))
    exit;

class Timeline extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'sf_timeline';
    }

    public function get_title()
    {
        return __('SF Timeline', 'plugin-name');
    }

    public function get_icon()
    {
        return 'eicon-time-line';
    }

    //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS

    public function get_script_depends()
    {
        return ['timeline'];
    }


    public function has_widget_inner_wrapper(): bool
    {
        return !Plugin::$instance->experiments->is_feature_active('e_optimized_markup');
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'ekit_timeline_content_section',
            [
                'label' => esc_html__('Content', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'ekit_timeline_style',
            [
                'label' => esc_html__('Time line Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'vertical',
                'options' => [
                    'vertical' => esc_html__('Vertical', 'sf-widget'),
                    'horizontal' => esc_html__('Horizontal', 'sf-widget'),
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_vertical_style',
            [
                'label' => esc_html__('Content Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'bothside',
                'options' => [
                    'oneside' => esc_html__('Same Side', 'sf-widget'),
                    'bothside' => esc_html__('Both side', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_horizontal_style',
            [
                'label' => esc_html__('Content Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => esc_html__('Top', 'sf-widget'),
                    'bottom' => esc_html__('Bottom', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_timeline_style' => 'horizontal',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_alignment',
            [
                'label' => esc_html__('Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ]
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .timeline-area.horizantal-timeline' => 'justify-content: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_line_break',
            [
                'label' => esc_html__('Line Break', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'ekit_timeline_style' => 'horizontal',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline' => 'flex-wrap: wrap;',
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'ekit_timeline_line_subtitle',
            [
                'label' => esc_html__('Sub Title', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_line_title',
            [
                'label' => esc_html__('Title', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_date_link',
            [
                'label' => esc_html__('Title Link', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://example.com', 'sf-widget'),
                'show_external' => true,
                'default' => [
                    'url' => '',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_line_content',
            [
                'label' => esc_html__('Description', 'sf-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 5,
                'default' => esc_html__('Item content. Click the edit button to change this text.', 'sf-widget'),
                'placeholder' => esc_html__('Type your description here', 'sf-widget'),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_title_icons',
            [
                'label' => esc_html__('Title Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_timeline_title_icon',
                'default' => [
                    'value' => '',
                    'library' => 'ekiticons',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_content_date_enable',
            [
                'label' => esc_html__('Enable Date', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'ekit_timeline_content_date',
            [
                'label' => esc_html__('Date', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('', 'sf-widget'),
                'label_block' => true,
                'separator' => 'before',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'ekit_timeline_content_date_enable' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timelinehr_content_address',
            [
                'label' => esc_html__('Address', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_pinpoint_text_enable',
            [
                'label' => esc_html__('Enable Pinpoint Text', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'ekit_timeline_pinpoint_text',
            [
                'label' => esc_html__('Pinpoint Text', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Text', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'ekit_timeline_pinpoint_text_enable' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timelinehr_repeater_style',
            [
                'label' => esc_html__('Repeater Item Style', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $repeater->start_controls_tabs('ekit_timeline_repeater_style_tab');

        $repeater->start_controls_tab(
            'ekit_timeline_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $repeater->add_control(
            'ekit_timelinearrow_title_color',
            [
                'label' => esc_html__('Title Color ', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .timeline-item .timeline-content .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timelinearrow_subtitle_color',
            [
                'label' => esc_html__('Sub Title Color ', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .timeline-item .timeline-content .subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_background_color_group',
            [
                'label' => esc_html__('Content box Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con {{CURRENT_ITEM}} .timeline-item, {{WRAPPER}} .ekit-wid-con {{CURRENT_ITEM}} .single-timeline .timeline-item .timeline-icon, {{WRAPPER}} .ekit-wid-con {{CURRENT_ITEM}} .single-timeline .timeline-item .timeline-icon' => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline {{CURRENT_ITEM}}:nth-child(odd) .timeline-pin' => 'border-color: {{VALUE}} {{VALUE}} transparent transparent;',
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline {{CURRENT_ITEM}}:nth-child(even) .timeline-pin' => 'border-color: transparent transparent {{VALUE}} {{VALUE}};',
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline {{CURRENT_ITEM}} .timeline-pin' => 'border-color: transparent transparent {{VALUE}} {{VALUE}};',
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline {{CURRENT_ITEM}} .pin-top' => 'border-color: {{VALUE}} {{VALUE}} transparent transparent;',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_icon_color_section_title',
            [
                'label' => esc_html__('Icon section', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_icon_color',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .timeline-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .timeline-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};'
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_icon_bg_color_group',
            [
                'label' => esc_html__('Icon Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .timeline-icon' => 'background-color:{{VALUE}}',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_hover_acitve',
            [
                'label' => esc_html__('Keep TimleLine open? ', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            'ekit_timeline_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $repeater->add_control(
            'ekit_timelinearrow_itle_color_hover',
            [
                'label' => esc_html__('Title Color ', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover .timeline-item .title' => 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timelinearrow_subtitle_color_hover',
            [
                'label' => esc_html__('Sub Title Color ', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover .timeline-item .subtitle' => 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_background__hv_color_group',
            [
                'label' => esc_html__('Content box Background', 'sf-widget'),
                'default' => '',
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con {{CURRENT_ITEM}}:hover .timeline-item, {{WRAPPER}} .ekit-wid-con {{CURRENT_ITEM}}:hover .single-timeline .timeline-item .timeline-icon, {{WRAPPER}} .ekit-wid-con {{CURRENT_ITEM}}:hover .single-timeline .timeline-item .timeline-icon' => 'background-color:{{VALUE}}',
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline {{CURRENT_ITEM}}:nth-child(odd):hover .timeline-pin' => 'border-color: {{VALUE}} {{VALUE}} transparent transparent;',
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline {{CURRENT_ITEM}}:nth-child(even):hover .timeline-pin' => 'border-color: transparent transparent {{VALUE}} {{VALUE}};',
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline {{CURRENT_ITEM}}:hover .timeline-pin' => 'border-color: transparent transparent {{VALUE}} {{VALUE}};',
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline {{CURRENT_ITEM}}:hover .pin-top' => 'border-color: {{VALUE}} {{VALUE}} transparent transparent;',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_icon_color_section_title_hv',
            [
                'label' => esc_html__('Icon section', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_icon_color_hv',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover .timeline-icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover .timeline-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};'
                ],
            ]
        );

        $repeater->add_control(
            'ekit_timeline_item_icon_bg_color_hv_group',
            [
                'label' => esc_html__('Icon Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover .timeline-icon' => 'background-color:{{VALUE}}',
                ],
            ]
        );

        $repeater->end_controls_tab();

        $repeater->end_controls_tabs();

        $this->add_control(
            'ekit_timelinehr_content_repeater',
            [
                'label' => esc_html__('Time Line Content', 'sf-widget'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'ekit_timeline_line_title' => esc_html__('', 'sf-widget'),
                        'ekit_timeline_line_content' => esc_html__('Item content. Click the edit button to change this text.', 'sf-widget'),
                        'ekit_timeline_pinpoint_text_enable' => 'yes',
                        'ekit_timeline_pinpoint_text' => esc_html__('Text', 'sf-widget'),
                        'ekit_timeline_hover_acitve' => 'yes',
                    ],
                    [
                        esc_html__('', 'sf-widget'),
                        'ekit_timeline_line_title' => esc_html__('', 'sf-widget'),
                        'ekit_timeline_line_content' => esc_html__('Item content. Click the edit button to change this text.', 'sf-widget'),
                        'ekit_timeline_pinpoint_text_enable' => 'yes',
                        'ekit_timeline_pinpoint_text' => esc_html__('Text', 'sf-widget'),
                    ],
                    [
                        'ekit_timeline_line_title' => esc_html__('', 'sf-widget'),
                        'ekit_timeline_line_content' => esc_html__('Item content. Click the edit button to change this text.', 'sf-widget'),
                        'ekit_timeline_pinpoint_text_enable' => 'yes',
                        'ekit_timeline_pinpoint_text' => esc_html__('Text', 'sf-widget'),
                    ],
                ],
                'title_field' => '{{{ ekit_timeline_line_title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_timeline_setting_section',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'ekit_timeline_date_icons',
            [
                'label' => esc_html__('Date Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_timeline_date_icon',
                'default' => [
                    'value' => '',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                ]
            ]
        );

        $this->add_control(
            'ekit_timelinehr_address_icons',
            [
                'label' => esc_html__('Address Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_timelinehr_address_icon',
                'default' => [
                    'value' => '',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_left_entrance_animation',
            [
                'label' => esc_html__('Content box Entrance Animation', 'sf-widget'),
                'type' => Controls_Manager::ANIMATION,
            ]
        );

        $this->add_control(
            'ekit_timeline_right_entrance_animation',
            [
                'label' => esc_html__('Address, date Entrance Animation', 'sf-widget'),
                'type' => Controls_Manager::ANIMATION,
            ]
        );

        $this->add_control(
            'ekit_timelinehr_pinpoint_icon',
            [
                'label' => esc_html__('Pinpoint Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'doted' => esc_html__('Default', 'sf-widget'),
                    'icon' => esc_html__('Icon', 'sf-widget'),
                    'text' => esc_html__('Text', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_icons',
            [
                'label' => esc_html__('Pinpoint Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_timeline_icon',
                'default' => [
                    'value' => 'icon icon-star1',
                    'library' => 'ekiticons',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'icon',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_timeline_style_section',
            [
                'label' => esc_html__('Content', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'ekit_timelinehr_alignment',
            [
                'label' => esc_html__('Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('justify', 'sf-widget'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-content' => 'text-align: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timelinehr_icon_alignment',
            [
                'label' => esc_html__('Icon Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Top', 'sf-widget'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Middle', 'sf-widget'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Bottom', 'sf-widget'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .timeline-item.media' => 'align-items:{{VALUE}};',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline__container_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 16,
                    'right' => 24,
                    'bottom' => 16,
                    'left' => 24,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline__container_inner_padding',
            [
                'label' => esc_html__('Inner Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .timeline-item .timeline-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'timeline_item_media_width',
            [
                'label' => __('Timeline Item Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1000],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'timeline_item_media_height',
            [
                'label' => __('Timeline Item Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1000],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'timeline_item_gradient_border',
            [
                'label' => esc_html__('Timeline Gradient Border', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'timeline_item_gradient_color_1',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => '--grad-color-1: {{VALUE}};',
                ],
                'condition' => [
                    'timeline_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'timeline_item_gradient_color_2',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => '--grad-color-2: {{VALUE}};',
                ],
                'condition' => [
                    'timeline_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'timeline_item_gradient_color_3',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => '--grad-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'timeline_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'timeline_gradient_direction',
            [
                'label' => __('Gradient Direction', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'to top',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => '--grad-direction: {{VALUE}};',
                ],
                'condition' => [
                    'timeline_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline__container_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .timeline-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timelinearrow_inactive_title_color',
            [
                'label' => esc_html__('Inactive Title Color ', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .top-content .title' => 'color: {{VALUE}}!important;',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'horizontal',
                ],
            ]
        );

        $this->start_controls_tabs(
            'ekit_timeline_style_content_tabs'
        );

        $this->start_controls_tab(
            'ekit_timeline_style_content_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_timeline_subtitle_color_nl',
            [
                'label' => esc_html__('Sub Title Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-content .subtitle' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_timeline_content__sub_title_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .subtitle',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_content__sub_title_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_content__sub_title_margin_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'ekit_timeline_content_title_color',
            [
                'label' => esc_html__('Title Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_content_title_color_a',
            [
                'label' => esc_html__('Title Anchor Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .title a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_timeline_content_title_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .single-timeline .title',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_content_title_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_content__title_margin_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'ekit_timeline_content_color',
            [
                'label' => esc_html__('Content Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_timeline_content_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .single-timeline .timeline-content p',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_content_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_arrow_separator',
            [
                'label' => esc_html__('Arrow', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_arrow_size',
            [
                'label' => esc_html__('Arrow Size (px)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 2,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline .timeline-pin' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; right: calc(-{{SIZE}}{{UNIT}} / 2); border-width: calc({{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline .single-timeline:nth-child(even) .timeline-pin' => 'right: inherit; left: calc(-{{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline .single-timeline .timeline-pin' => 'top: calc(100% - {{SIZE}}{{UNIT}}/2); width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; border-width: calc({{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline .single-timeline .pin-top' => 'top: unset; bottom: calc(100% - {{SIZE}}{{UNIT}}/2);',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_gradient_border_size',
            [
                'label' => esc_html__('Gradient Border Size (px)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 2,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline .single-timeline:nth-child(odd) .timeline-pin[data-gradient-border="yes"]::before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; top: calc(-{{SIZE}}{{UNIT}} / 2); left: calc(-{{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .ekit-wid-con .vertical-timeline .single-timeline:nth-child(even) .timeline-pin[data-gradient-border="yes"]::before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; top: calc(-{{SIZE}}{{UNIT}} / 2); left: calc(-{{SIZE}}{{UNIT}} / 2);',
                ],
            ]
        );


        $this->add_control(
            'ekit_timeline_round_color_separator',
            [
                'label' => esc_html__('Round icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ekit_timeline_icon_color',
            [
                'label' => esc_html__('Round Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .timeline-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_item_icon_bg_color_group',
            [
                'label' => esc_html__('Round Icon Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-icon' => 'background-color:{{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_tab_nav_header_box_shadow_group',
                'label' => esc_html__('Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .ekit-wid-con .timeline-icon',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_icon_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline .timeline-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'horizontal',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_timeline_more_options',
            [
                'label' => esc_html__('Timeline info', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ekit_timeline_icon_date_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .floating-style .single-timeline .timeline-info .date' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .floating-style .single-timeline .timeline-info .date a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .horizantal-timeline .bottom-content .date' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .single-timeline .timeline-info .date svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_icon_date_icon_size',
            [
                'label' => esc_html__('Icon Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-info .date i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .single-timeline .timeline-info .date svg' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_timeline_icon_date_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .single-timeline .timeline-info .date, {{WRAPPER}} .horizantal-timeline .bottom-content .date',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_icon_date_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-info .date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .horizantal-timeline .bottom-content .date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_timeline_address_head',
            [
                'label' => esc_html__('Address', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ekit_timeline_icon_address_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .floating-style .single-timeline .timeline-info p' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .single-timeline .timeline-info p' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .single-timeline .timeline-info .place svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_icon_address_icon_size',
            [
                'label' => esc_html__('Icon Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-info .place i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .single-timeline .timeline-info .place svg' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_timeline_icon_address_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .single-timeline .timeline-info .place',
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_icon_address_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-info p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_timeline_style_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_timeline_subtitle_color_hv',
            [
                'label' => esc_html__('Sub Title Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-content .subtitle' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_content_title_color_hv',
            [
                'label' => esc_html__('Title Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-item .title' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .single-timeline:hover .timeline-item .title a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_content_title_color_a_hv',
            [
                'label' => esc_html__('Title Anchor Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline .timeline-item .title a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_content_color_hv',
            [
                'label' => esc_html__('Content Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_icon_color_hv',
            [
                'label' => esc_html__('Round Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-area .timeline-item:hover .timeline-icon>i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_item_icon_bg_color_group_hv',
            [
                'label' => esc_html__('Round Icon Background', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-item:hover .timeline-icon' => 'background-color:{{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_more_options_hover',
            [
                'label' => esc_html__('Timeline info', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ekit_timeline_icon_date_color_hv',
            [
                'label' => esc_html__('Date', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-info .date' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .single-timeline:hover .timeline-info .date a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_icon_address_color_hv',
            [
                'label' => esc_html__('Address', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-info p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_timeline_style_line_section',
            [
                'label' => esc_html__('Line ', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'ekit_timeline_line_color',
            [
                'label' => esc_html__('Line Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    // '{{WRAPPER}} .timeline-bar' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .horizantal-timeline .bar' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'ekit_timeline_style' => 'horizontal',
                ]
            ]
        );

        $this->add_control(
            'timeline_bar_gradient_border',
            [
                'label' => esc_html__('Use Dash Border', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_responsive_control(
            'timeline_bar_border_width',
            [
                'label' => esc_html__('Border Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'size' => 1,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-bar' => 'border-width: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'timeline_bar_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'timeline_bar_border_style',
            [
                'label' => esc_html__('Border Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'solid',
                'options' => [
                    'solid' => esc_html__('Solid', 'sf-widget'),
                    'dashed' => esc_html__('Dashed', 'sf-widget'),
                    'dotted' => esc_html__('Dotted', 'sf-widget'),
                    'double' => esc_html__('Double', 'sf-widget'),
                    'none' => esc_html__('None', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-bar' => 'border-style: {{VALUE}}',
                ],
                'condition' => [
                    'timeline_bar_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'timeline_bar_border_color',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-bar' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'timeline_bar_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'timeline_bar_dashed_border',
            [
                'label' => __('Timeline dash border color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-bar' => '--grad-timeline-bar-dash-color: {{VALUE}};',
                ],
                'condition' => [
                    'timeline_bar_gradient_border' => 'yes',
                ],
            ]
        );

        // $this->add_control(
        //     'timeline_bar_gradient_color_1',
        //     [
        //         'label' => __('Gradient Border Color 1', 'sf-widget'),
        //         'type' => Controls_Manager::COLOR,
        //         'selectors' => [
        //             '{{WRAPPER}} .sf-timeline-bar' => '--grad-timeline-bar-color-1: {{VALUE}};',
        //         ],
        //         'condition' => [
        //             'timeline_bar_gradient_border' => 'yes',
        //         ],
        //     ]
        // );

        // $this->add_control(
        //     'timeline_bar_gradient_color_2',
        //     [
        //         'label' => __('Gradient Border Color 2', 'sf-widget'),
        //         'type' => Controls_Manager::COLOR,
        //         'selectors' => [
        //             '{{WRAPPER}} .sf-timeline-bar' => '--grad-timeline-bar-color-2: {{VALUE}};',
        //         ],
        //         'condition' => [
        //             'timeline_bar_gradient_border' => 'yes',
        //         ],
        //     ]
        // );

        // $this->add_control(
        //     'timeline_bar_gradient_color_3',
        //     [
        //         'label' => __('Gradient Border Color 3', 'sf-widget'),
        //         'type' => Controls_Manager::COLOR,
        //         'selectors' => [
        //             '{{WRAPPER}} .sf-timeline-bar' => '--grad-timeline-bar-color-3: {{VALUE}};',
        //         ],
        //         'condition' => [
        //             'timeline_bar_gradient_border' => 'yes',
        //         ],
        //     ]
        // );

        // $this->add_control(
        //     'timeline_bar_text_gradient_direction',
        //     [
        //         'label' => __('Gradient Direction', 'sf-widget'),
        //         'type' => Controls_Manager::SELECT,
        //         'default' => 'to bottom',
        //         'options' => [
        //             'to top' => 'Bottom → Top',
        //             'to bottom' => 'Top → Bottom',
        //         ],
        //         'selectors' => [
        //             '{{WRAPPER}} .sf-timeline-bar' => '--grad-direction: {{VALUE}};',
        //         ],
        //         'condition' => [
        //             'timeline_bar_gradient_border' => 'yes',
        //         ],
        //     ]
        // );

        do_action('sf_timeline_active_item',$this);

        $this->add_control(
            'ekit_timeline_pinpoint_separator',
            [
                'label' => esc_html__('Pinpoint', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ekit_timeline_pin_color',
            [
                'label' => esc_html__('Pin Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-img' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .horizantal-timeline .bar .pin' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'doted',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_pin_active_border_color',
            [
                'label' => esc_html__('Active Pin Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .horizantal-timeline .single-timeline.hover .bar .pin' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'doted',
                ]
            ]
        );

        $this->add_control(
            'ekit_timeline_pin_hover_color',
            [
                'label' => esc_html__('Pinpoint Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .timeline-img:before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'doted',
                    'ekit_timeline_style' => 'vertical',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_pinpoint_icon_size',
            [
                'label' => esc_html__('Pinpoint Icon Size (px)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .timeline-pin-icon :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'icon',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_pinpoint_height_widht',
            [
                'label' => esc_html__('Pinpoint Height & Width (px)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .timeline-pin-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: calc({{SIZE}}{{UNIT}} - 2px);',
                ],
            ]
        );

        $this->start_controls_tabs(
            'ekit_timeline_line_style_tabs',
            [
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'icon',
                ]
            ]
        );

        $this->start_controls_tab(
            'ekit_timeline_line_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_timeline_line_icon_color',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .timeline-pin-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .timeline-pin-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_timeline_line_icon_background_group',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .single-timeline .timeline-pin-icon'
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_timeline_line_icon_border',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .timeline-pin-icon'
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_line_icon_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .timeline-pin-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_timeline_line_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_timeline_line_icon_color_hover',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-pin-icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .single-timeline:hover .timeline-pin-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_timeline_line_icon_background_hover_group',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .single-timeline:hover .timeline-pin-icon'
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_timeline_line_icon_border_hover',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .single-timeline:hover .timeline-pin-icon'
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_line_icon_border_radius_hover',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .timeline-pin-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_tabs();

        $this->add_control(
            'ekit_timeline_pinpoint_text_separator',
            [
                'label' => esc_html__('Pinpoint Text', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                ]
            ]
        );

        $this->start_controls_tabs(
            'ekit_timeline_pinpoint_text_style_tabs',
            [
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                ]
            ]
        );

        $this->start_controls_tab(
            'ekit_timeline_pinpoint_text_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_color_global',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_background_color_global',
            [
                'label' => esc_html__('Background Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'use_gradient_border',
            [
                'label' => esc_html__('Use Gradient Border Color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'No',
            ]
        );

        $this->add_responsive_control(
            'border_width',
            [
                'label' => esc_html__('Border Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'size' => 2,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'border_style',
            [
                'label' => esc_html__('Border Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'solid' => esc_html__('Solid', 'sf-widget'),
                    'dashed' => esc_html__('Dashed', 'sf-widget'),
                    'dotted' => esc_html__('Dotted', 'sf-widget'),
                    'double' => esc_html__('Double', 'sf-widget'),
                    'none' => esc_html__('None', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_1',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-1: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_2',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-2: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_3',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'text_gradient_direction',
            [
                'label' => __('Gradient Direction', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'to bottom right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--normal-grad-direction: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'use_active_item_gradient_border',
            [
                'label' => esc_html__('Active pinpoint gradient color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'No',
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                ],
            ]
        );

        $this->add_control(
            'active_item_gradient_color_1',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-1: {{VALUE}};',
                ],
                'condition' => [
                    'use_active_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'active_item_gradient_color_2',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-2: {{VALUE}};',
                ],
                'condition' => [
                    'use_active_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'active_item_gradient_color_3',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'use_active_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'active_item_gradient_direction',
            [
                'label' => __('Gradient Direction', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'to bottom right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--normal-grad-direction: {{VALUE}};',
                ],
                'condition' => [
                    'use_active_item_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_shape',
            [
                'label' => esc_html__('Shape', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'circle',
                'options' => [
                    'rectangle' => esc_html__('Rectangle', 'sf-widget'),
                    'circle' => esc_html__('Circle', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_pinpoint_text_border_radius_global',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '4',
                    'right' => '4',
                    'bottom' => '4',
                    'left' => '4',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'rectangle',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_pinpoint_text_padding_global',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '5',
                    'right' => '10',
                    'bottom' => '5',
                    'left' => '10',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'rectangle',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_min_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 170,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'min-width: {{SIZE}}{{UNIT}}; max-width: 170px; width: auto;',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'rectangle',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_pinpoint_text_circle_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 20, 'max' => 200],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_pinpoint_text_circle_height',
            [
                'label' => esc_html__('Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 20, 'max' => 200],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_pinpoint_text_circle_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                    '%' => ['min' => 0, 'max' => 50],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline_pinpoint_text_circle_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    'ekit_timeline_pinpoint_text_shape' => 'circle',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_content_alignment',
            [
                'label' => esc_html__('Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ]
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => 'justify-content: {{VALUE}}',
                ],
                'condition' => [
                    'ekit_timelinehr_pinpoint_icon' => 'text',
                    // 'ekit_timeline_pinpoint_text_shape' => 'circle',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_timeline_pinpoint_text_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_color_hover_global',
            [
                'label' => esc_html__('Text Color Hover', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .sf-timeline-pin-text, {{WRAPPER}} .single-timeline.hover .sf-timeline-pin-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_timeline_pinpoint_text_background_color_hover_global',
            [
                'label' => esc_html__('Background Color Hover', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:hover .sf-timeline-pin-text, {{WRAPPER}} .single-timeline.hover .sf-timeline-pin-text' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'use_gradient_border_hover',
            [
                'label' => esc_html__('Use Gradient Border Color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'hover_border_color',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_1_hover',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-1-hover: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_2_hover',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-2-hover: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_3_hover',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-circle-border-color-3-hover: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'text_gradient_direction_hover',
            [
                'label' => __('Gradient Direction', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'to bottom right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-timeline-pin-text' => '--grad-direction: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_timeline__container_style_tab',
            [
                'label' => esc_html__('Container', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_timeline_style' => 'vertical',
                    'ekit_timeline_vertical_style' => 'bothside',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline__container_info_margin_right',
            [
                'label' => esc_html__('Info (Address, date) Gap', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 60,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 106,
                ],
                'selectors' => [
                    '{{WRAPPER}} .vertical-timeline .single-timeline:nth-child(even) .timeline-info' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .vertical-timeline .single-timeline:nth-child(odd) .timeline-info' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timeline_vertical_style' => 'bothside'
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_timeline__item_margin_bottom',
            [
                'label' => esc_html__('Item Bottom Spacing', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 30,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 80,
                ],
                'selectors' => [
                    '{{WRAPPER}} .single-timeline:not(:nth-last-child(2)), {{WRAPPER}} .horizantal-timeline > .single-timeline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_timeline_vertical_style' => 'bothside'
                ]
            ]
        );


        $this->end_controls_section();
    }


    private function has_animation($dir)
    {
        $settings = $this->get_settings_for_display();
        $name = 'ekit_timeline_' . $dir . '_entrance_animation';

        if ($settings[$name] && $settings[$name] !== 'none') {
            return ' elementskit-invisible';
        }

        return '';
    }

    protected function render() {
        echo '<div class="ekit-wid-con">';
        $this->render_raw();
        echo '</div>';
    }

    protected function render_raw()
    {
        $settings = $this->get_settings_for_display();

        $timeline_class = 'timeline-area sf-timeline';

        switch ($settings['ekit_timeline_style']) {
            case 'vertical':
                $timeline_class .= ' vertical-timeline multi-gradient floating-style';
                break;
            case 'horizontal':
                $timeline_class .= ' horizantal-timeline clearfix';
                break;
        }

        $this->add_render_attribute('timeline', 'class', $timeline_class);
        $this->add_render_attribute('timeline', 'class', $settings['ekit_timeline_vertical_style']);
        ?>
        <div <?php echo \ElementsKit_Lite\Utils::render($this->get_render_attribute_string('timeline')); ?>>

            <?php
            $contents = $settings['ekit_timelinehr_content_repeater'];
            $count = 0;
            foreach ($contents as $content):
                $left_entranceAnimation = [
                    '_animation' => $settings['ekit_timeline_left_entrance_animation']
                ];
                $right_entranceAnimation = [
                    '_animation' => $settings['ekit_timeline_right_entrance_animation']
                ];
                $link_before = $link_after = '';
                if (!empty($content['ekit_timeline_date_link']['url'])) {
                    $this->add_link_attributes('info_link_' . $content['_id'], $content['ekit_timeline_date_link']);
                    $link_before = "<a " . $this->get_render_attribute_string('info_link_' . $content['_id']) . ">";
                    $link_after = '</a>';
                }
                if ($settings['ekit_timeline_style'] == 'vertical'): ?>
                                    <div
                                        class="single-timeline media single-timeline-count-<?php echo esc_attr(($count + 1)); ?> elementor-repeater-item-<?php echo esc_attr($content['_id']); ?>">
                                        <div class="timeline-item media<?php echo esc_attr($this->has_animation('left')); ?>"
                                            data-settings="<?php echo esc_attr(json_encode($left_entranceAnimation)); ?>"
                                            data-gradient-border="<?php echo esc_attr($settings['timeline_item_gradient_border']); ?>">
                                            <div class="timeline-content">
                                                <?php if (!empty($content['ekit_timeline_line_subtitle'])): ?>
                                                            <span class="subtitle"><?php echo esc_html($content['ekit_timeline_line_subtitle']); ?></span>
                                                <?php endif; ?>
                                                <?php if (!empty($content['ekit_timeline_line_title'])): ?>
                                                            <h3 class="title">
                                                                <?php echo $link_before . wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_title']), \ElementsKit_Lite\Utils::get_kses_array()) . $link_after; ?>
                                                            </h3>
                                                <?php endif; ?>
                                                <?php if (!empty($content['ekit_timeline_line_content'])): ?>
                                                            <p><?php echo wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_content']), \ElementsKit_Lite\Utils::get_kses_array()); ?>
                                                            </p>
                                                <?php endif; ?>
                                                <?php if ($settings['ekit_timeline_style'] == 'vertical' && $settings['ekit_timeline_vertical_style'] == 'oneside'): ?>
                                                            <div class="timeline-info timeline-info-onside<?php echo esc_attr($this->has_animation('right')); ?>"
                                                                data-settings="<?php echo esc_attr(json_encode($right_entranceAnimation)); ?>">
                                                                <?php if (!empty($content['ekit_timeline_content_date']) && $content['ekit_timeline_content_date_enable'] == 'yes'): ?>
                                                                            <h4 class="date">
                                                                                <?php Icons_Manager::render_icon($settings['ekit_timeline_date_icons'], ['aria-hidden' => 'true']); ?>
                                                                                <?php echo \ElementsKit_Lite\Utils::render(esc_html($content['ekit_timeline_content_date'])); ?>
                                                                            </h4>
                                                                <?php endif; ?>
                                                                <?php if (!empty($content['ekit_timelinehr_content_address'])): ?>
                                                                            <p class="place">
                                                                                <?php if ($settings['ekit_timelinehr_address_icons']): ?>
                                                                                            <?php Icons_Manager::render_icon($settings['ekit_timelinehr_address_icons'], ['aria-hidden' => 'true']); ?>
                                                                                <?php endif; ?>
                                                                                <span><?php echo esc_html($content['ekit_timelinehr_content_address']); ?></span>
                                                                            </p>
                                                                <?php endif; ?>
                                                            </div>
                                                <?php endif; ?>
                                            </div><!-- .timeline-content END -->
                                            <?php if (!empty($content['ekit_timeline_title_icons']['value'])): ?>
                                                        <div class="timeline-icon">
                                                            <?php
                                                            $migrated = isset($content['__fa4_migrated']['ekit_timeline_title_icons']);
                                                            $is_new = empty($content['ekit_timeline_title_icon']);
                                                            if ($is_new || $migrated) {
                                                                Icons_Manager::render_icon($content['ekit_timeline_title_icons'], ['aria-hidden' => 'true']);
                                                            } else {
                                                                ?>
                                                                        <i class="<?php echo esc_attr($content['ekit_timeline_title_icon']); ?>" aria-hidden="true"></i>
                                                                        <?php
                                                            }
                                                            ?>
                                                        </div>
                                            <?php endif; ?>
                                            <?php if (!empty($content['ekit_timeline_title_icons']['value'])): ?>
                                                        <div class="watermark-icon">
                                                            <?php
                                                            $migrated = isset($content['__fa4_migrated']['ekit_timeline_title_icons']);
                                                            $is_new = empty($content['ekit_timeline_title_icon']);
                                                            if ($is_new || $migrated) {
                                                                Icons_Manager::render_icon($content['ekit_timeline_title_icons'], ['aria-hidden' => 'true']);
                                                            } else {
                                                                ?>
                                                                        <i class="<?php echo esc_attr($content['ekit_timeline_title_icon']); ?>" aria-hidden="true"></i>
                                                                        <?php
                                                            }
                                                            ?>
                                                        </div>
                                            <?php endif; ?>
                                            <div class="timeline-pin" data-gradient-border="<?php echo esc_attr($settings['timeline_item_gradient_border']); ?>"></div>
                                        </div><!-- .timeline-item .media END -->
                                        <?php if ($settings['ekit_timeline_style'] == 'vertical' && $settings['ekit_timeline_vertical_style'] == 'bothside'): ?>
                                                    <div class="timeline-info<?php echo esc_attr($this->has_animation('right')); ?>"
                                                        data-settings="<?php echo esc_attr(json_encode($right_entranceAnimation)); ?>">
                                                        <?php if (!empty($content['ekit_timeline_content_date']) && $content['ekit_timeline_content_date_enable'] == 'yes'): ?>
                                                                    <h4 class="date">
                                                                        <?php Icons_Manager::render_icon($settings['ekit_timeline_date_icons'], ['aria-hidden' => 'true']); ?>
                                                                        <?php echo \ElementsKit_Lite\Utils::render(esc_html($content['ekit_timeline_content_date'])); ?>
                                                                    </h4>
                                                        <?php endif; ?>
                                                        <?php if (!empty($content['ekit_timelinehr_content_address'])): ?>
                                                                    <p class="place">
                                                                        <?php if ($settings['ekit_timelinehr_address_icons']): ?>
                                                                                    <?php Icons_Manager::render_icon($settings['ekit_timelinehr_address_icons'], ['aria-hidden' => 'true']); ?>
                                                                        <?php endif; ?>
                                                                        <?php echo \ElementsKit_Lite\Utils::render(esc_html($content['ekit_timelinehr_content_address'])); ?>
                                                                    </p>
                                                        <?php endif; ?>
                                                    </div>
                                        <?php endif; ?>
                                        <?php if ($settings['ekit_timelinehr_pinpoint_icon'] == 'doted'): ?>
                                                    <div class="timeline-img"></div>
                                        <?php endif; ?>
                                        <?php if ($settings['ekit_timelinehr_pinpoint_icon'] == 'icon'): ?>
                                                    <div class="timeline-pin-icon">
                                                        <?php
                                                        $migrated = isset($settings['__fa4_migrated']['ekit_timeline_icons']);
                                                        $is_new = empty($settings['ekit_timeline_icon']);
                                                        if ($is_new || $migrated) {
                                                            Icons_Manager::render_icon($settings['ekit_timeline_icons'], ['aria-hidden' => 'true']);
                                                        } else {
                                                            ?>
                                                                    <i class="<?php echo esc_attr($settings['ekit_timeline_icon']); ?>" aria-hidden="true"></i>
                                                                    <?php
                                                        }
                                                        ?>
                                                    </div>
                                        <?php endif; ?>

                                        <!-- Timeline pinpoint text -->
                                        <?php if ($settings['ekit_timeline_style'] == 'vertical'): ?>

                                                    <?php
                                                    if (
                                                        $settings['ekit_timelinehr_pinpoint_icon'] === 'text' &&
                                                        !empty($content['ekit_timeline_pinpoint_text_enable']) && $content['ekit_timeline_pinpoint_text_enable'] === 'yes' &&
                                                        !empty($content['ekit_timeline_pinpoint_text'])
                                                    ):

                                                        $shape = $settings['ekit_timeline_pinpoint_text_shape'] ?? 'circle';
                                                        $pin_class = 'sf-timeline-pin-text sf-pinpoint-text-' . esc_attr($shape);

                                                        $gradient_attr = sprintf(
                                                            'data-gradient-border="%s" data-gradient-border-hover="%s"',
                                                            esc_attr($settings['use_gradient_border'] ?? ''),
                                                            esc_attr($settings['use_gradient_border_hover'] ?? '')
                                                        );
                                                        ?>
                                                                <div class="<?php echo $pin_class; ?>" <?php echo $gradient_attr; ?>>
                                                                    <?php echo esc_html($content['ekit_timeline_pinpoint_text']); ?>
                                                                </div>
                                                    <?php endif; ?>

            
                                        <?php endif; ?>

                                    </div><!-- .single-timeline .media END -->
                        <?php endif; ?>
                        <?php if ($settings['ekit_timeline_style'] == 'horizontal'): ?>
                                    <?php if ($settings['ekit_timeline_horizontal_style'] == 'top'): ?>
                                                <div
                                                    class="single-timeline <?php echo esc_attr($content['ekit_timeline_hover_acitve'] === 'yes' ? 'hover' : ''); ?> elementor-repeater-item-<?php echo esc_attr($content['_id']); ?>">
                                                    <div class="timeline-item <?php echo esc_attr($this->has_animation('left')); ?>"
                                                        data-settings="<?php echo esc_attr(json_encode($left_entranceAnimation)); ?>">
                                                        <?php if (!empty($content['ekit_timeline_title_icons']['value'])): ?>
                                                                    <div class="timeline-icon">
                                                                        <?php
                                                                        $migrated = isset($content['__fa4_migrated']['ekit_timeline_title_icons']);
                                                                        $is_new = empty($content['ekit_timeline_title_icon']);
                                                                        if ($is_new || $migrated) {
                                                                            Icons_Manager::render_icon($content['ekit_timeline_title_icons'], ['aria-hidden' => 'true']);
                                                                        } else {
                                                                            ?>
                                                                                    <i class="<?php echo esc_attr($content['ekit_timeline_title_icon']); ?>" aria-hidden="true"></i>
                                                                                    <?php
                                                                        }
                                                                        ?>
                                                                    </div><!-- .timeline-icon END -->
                                                        <?php endif; ?>
                                                        <div class="timeline-content">
                                                            <?php if (!empty($content['ekit_timeline_line_subtitle'])): ?>
                                                                        <span class="subtitle"><?php echo esc_html($content['ekit_timeline_line_subtitle']); ?></span>
                                                            <?php endif; ?>
                                                            <?php if (!empty($content['ekit_timeline_line_title'])): ?>
                                                                        <h3 class="title">
                                                                            <?php echo $link_before . wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_title']), \ElementsKit_Lite\Utils::get_kses_array()) . $link_after; ?>
                                                                        </h3>
                                                            <?php endif; ?>
                                                            <?php if (!empty($content['ekit_timeline_line_content'])): ?>
                                                                        <p><?php echo wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_content']), \ElementsKit_Lite\Utils::get_kses_array()); ?>
                                                                        </p>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="timeline-pin"></div>
                                                    </div>
                                                    <div class="content-group text-center">
                                                        <div class="top-content<?php echo esc_attr($this->has_animation('right')); ?>"
                                                            data-settings="<?php echo esc_attr(json_encode($right_entranceAnimation)); ?>">
                                                            <?php if (!empty($content['ekit_timeline_line_title'])): ?>
                                                                        <h3 class="title">
                                                                            <?php echo $link_before . wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_title']), \ElementsKit_Lite\Utils::get_kses_array()) . $link_after; ?>
                                                                        </h3>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="bar">
                                                            <div class="pin"></div>
                                                        </div>
                                                        <?php if (!empty($content['ekit_timeline_content_date']) && $content['ekit_timeline_content_date_enable'] == 'yes'): ?>
                                                                    <div class="bottom-content<?php echo esc_attr($this->has_animation('right')); ?>"
                                                                        data-settings="<?php echo esc_attr(json_encode($right_entranceAnimation)); ?>">
                                                                        <p class="date"><?php echo esc_html($content['ekit_timeline_content_date']); ?></p>
                                                                    </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                    <?php else: ?>
                                                <div
                                                    class="single-timeline <?php echo esc_attr($content['ekit_timeline_hover_acitve'] === 'yes' ? 'hover' : ''); ?> elementor-repeater-item-<?php echo esc_attr($content['_id']); ?>">
                                                    <div class="content-group text-center">
                                                        <?php if (!empty($content['ekit_timeline_content_date']) && $content['ekit_timeline_content_date_enable'] == 'yes'): ?>
                                                                    <div class="bottom-content<?php echo esc_attr($this->has_animation('right')); ?>"
                                                                        data-settings="<?php echo esc_attr(json_encode($right_entranceAnimation)); ?>">
                                                                        <p class="date"><?php echo esc_html($content['ekit_timeline_content_date']); ?></p>
                                                                    </div>
                                                        <?php endif; ?>
                                                        <div class="bar">
                                                            <div class="pin"></div>
                                                        </div>
                                                        <div class="top-content<?php echo esc_attr($this->has_animation('right')); ?>"
                                                            data-settings="<?php echo esc_attr(json_encode($right_entranceAnimation)); ?>">
                                                            <?php if (!empty($content['ekit_timeline_line_title'])): ?>
                                                                        <h3 class="title">
                                                                            <?php echo $link_before . wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_title']), \ElementsKit_Lite\Utils::get_kses_array()) . $link_after; ?>
                                                                        </h3>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="timeline-item timeline-item-horizontal-bottom <?php echo esc_attr($this->has_animation('left')); ?>"
                                                        data-settings="<?php echo esc_attr(json_encode($left_entranceAnimation)); ?>">
                                                        <div class="timeline-pin pin-top"></div>
                                                        <?php if (!empty($content['ekit_timeline_title_icons']['value'])): ?>
                                                                    <div class="timeline-icon">
                                                                        <?php
                                                                        $migrated = isset($content['__fa4_migrated']['ekit_timeline_title_icons']);
                                                                        $is_new = empty($content['ekit_timeline_title_icon']);
                                                                        if ($is_new || $migrated) {
                                                                            Icons_Manager::render_icon($content['ekit_timeline_title_icons'], ['aria-hidden' => 'true']);
                                                                        } else {
                                                                            ?>
                                                                                    <i class="<?php echo esc_attr($content['ekit_timeline_title_icon']); ?>" aria-hidden="true"></i>
                                                                                    <?php
                                                                        }
                                                                        ?>
                                                                    </div><!-- .timeline-icon END -->
                                                        <?php endif; ?>
                                                        <div class="timeline-content">
                                                            <?php if (!empty($content['ekit_timeline_line_subtitle'])): ?>
                                                                        <span class="subtitle"><?php echo esc_html($content['ekit_timeline_line_subtitle']); ?></span>
                                                            <?php endif; ?>
                                                            <?php if (!empty($content['ekit_timeline_line_title'])): ?>
                                                                        <h3 class="title">
                                                                            <?php echo $link_before . wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_title']), \ElementsKit_Lite\Utils::get_kses_array()) . $link_after; ?>
                                                                        </h3>
                                                            <?php endif; ?>
                                                            <?php if (!empty($content['ekit_timeline_line_content'])): ?>
                                                                        <p><?php echo wp_kses(\ElementsKit_Lite\Utils::kses($content['ekit_timeline_line_content']), \ElementsKit_Lite\Utils::get_kses_array()); ?>
                                                                        </p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                    <?php endif; ?>
                        <?php endif; ?>
                        <?php $count++; ?>
            <?php endforeach; ?>
            <?php if ($settings['ekit_timeline_style'] == 'vertical'): ?>
                        <div class="timeline-bar sf-timeline-bar" data-gradient-border="<?php echo esc_attr($settings['timeline_bar_gradient_border']); ?>"></div>
            <?php endif; ?>
        </div>
        <?php
    }
}