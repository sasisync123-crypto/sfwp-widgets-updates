<?php
namespace SFWPStudio\Widgets;

use Elementor\Widget_Base;

if (!defined('ABSPATH')) {
    exit;
}

class Button extends Widget_Base
{
    use \SFWPStudio\Core\Helpers\Traits\ButtonTrait;

    public function get_name() {
        return 'sf-button';
    }

    public function get_title() {
        return esc_html__('SF Button', 'sf-widget');
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return ['syncfusion-widgets'];
    }

    protected function _register_controls() {
        $this->register_button_controls("One");
    }

    protected function render() {
         echo '<div class="ekit-wid-con" >';
          $this->render_button("One");
        echo '</div>';
    }
}
