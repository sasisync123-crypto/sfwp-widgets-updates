<?php
namespace SFWPStudio\Widgets;

if (!defined('ABSPATH')) exit;

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Repeater;

class Image_Overlay extends Widget_Base
{
    public function get_name()
    {
        return 'sf-image-overlay';
    }

    public function get_title()
    {
        return __('SF Image Overlay', 'demo-sample');
    }

    public function get_icon()
    {
        return 'sync-widget-icon eicon-image';
    }

    public function get_keywords()
    {
        return ['sf', 'image', 'overlay', 'card'];
    }

    //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS

    protected function register_controls()
    {
        // Image Section
        $this->start_controls_section(
            'image_section',
            [
                'label' => __('Image', 'demo-sample'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => __('Image', 'demo-sample'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_shape',
            [
                'label' => __('Image Shape', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => 'square',
                'options' => [
                    'circle' => __('Circle', 'demo-sample'),
                    'rounded_square' => __('Rounded Square', 'demo-sample'),
                    'square' => __('Square', 'demo-sample'),
                    'organic_blob' => __('Organic Blob', 'demo-sample'),
                ],
            ]
        );

        $this->end_controls_section();

        // Overlay Images Section
        $this->start_controls_section(
            'overlay_images_section',
            [
                'label' => __('Overlay Images', 'demo-sample'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_overlay_images',
            [
                'label' => __('Enable Overlay Images', 'demo-sample'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'demo-sample'),
                'label_off' => __('No', 'demo-sample'),
                'default' => '',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'overlay_image',
            [
                'label' => __('Overlay Image', 'demo-sample'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_responsive_control(
            'overlay_position_top',
            [
                'label' => __('Top Position', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 200],
                    'px' => ['min' => -500, 'max' => 1000],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'overlay_position_left',
            [
                'label' => __('Left Position', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 200],
                    'px' => ['min' => -500, 'max' => 1000],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'overlay_image_width',
            [
                'label' => __('Width', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 180,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 150,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'overlay_image_height',
            [
                'label' => __('Height', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 500],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 180,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 155,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'overlay_image_padding',
            [
                'label' => __('Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'overlay_image_margin',
            [
                'label' => __('Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_control(
            'overlay_image_background',
            [
                'label' => __('Background Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ededede9',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} img' => 'background: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'overlay_z_index',
            [
                'label' => __('Z-Index', 'demo-sample'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 10,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'z-index: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_images',
            [
                'label' => __('Overlay Images', 'demo-sample'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
                'title_field' => '{{{ overlay_image.url ? "Image" : "No Image" }}}',
                'condition' => [
                    'enable_overlay_images' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Card 1 Controls
        $this->start_controls_section(
            'card_1_section',
            [
                'label' => __('Card 1', 'demo-sample'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'card_title_1',
            [
                'label' => __('Card 1 Title', 'demo-sample'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Income', 'demo-sample'),
            ]
        );

        $this->add_control(
            'card_content_1',
            [
                'label' => __('Card 1 Content', 'demo-sample'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('256K'),
            ]
        );

        $this->add_control(
            'badge_text',
            [
                'label' => __('Badge Text', 'demo-sample'),
                'type' => Controls_Manager::TEXT,
                'default' => __('New', 'demo-sample'),
            ]
        );

        $this->add_control(
            'badge_icon',
            [
                'label' => __('Badge Icon', 'demo-sample'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'eicon-arrow-up',
                    'library' => 'elementor',
                ],
            ]
        );

        $this->end_controls_section();

        // Card 2 Controls
        $this->start_controls_section(
            'card_2_section',
            [
                'label' => __('Card 2', 'demo-sample'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_card_2',
            [
                'label' => __('Enable Card 2', 'demo-sample'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'demo-sample'),
                'label_off' => __('No', 'demo-sample'),
                'default' => '',
            ]
        );

        $this->add_control(
            'card_title_2',
            [
                'label' => __('Card 2 Title', 'demo-sample'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Event Details', 'demo-sample'),
                'condition' => [
                    'enable_card_2' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'card_content_2',
            [
                'label' => __('Card 2 Content', 'demo-sample'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Join us for an exciting event!', 'demo-sample'),
                'condition' => [
                    'enable_card_2' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'enable_card_button_2',
            [
                'label' => __('Enable Button', 'demo-sample'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'demo-sample'),
                'label_off' => __('No', 'demo-sample'),
                'default' => 'yes',
                'condition' => [
                    'enable_card_2' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'card_button_text_2',
            [
                'label' => __('Card 2 Button Text', 'demo-sample'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Learn More', 'demo-sample'),
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'card_button_url_2',
            [
                'label' => __('Card 2 Button URL', 'demo-sample'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Image Styling Section
        $this->start_controls_section(
            'image_style_section',
            [
                'label' => __('Image Styling', 'demo-sample'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_width',
            [
                'label' => __('Image Width', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vw'],
                'range' => [
                    '%' => ['min' => 10, 'max' => 100],
                    'px' => ['min' => 100, 'max' => 1000],
                    'vw' => ['min' => 10, 'max' => 100],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 66,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .image-container img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_max_height',
            [
                'label' => __('Image Max Height', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => ['min' => 100, 'max' => 800],
                    'vh' => ['min' => 10, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 250,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 200,
                ],
                'selectors' => [
                    '{{WRAPPER}} .image-container img' => 'max-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => __('Image Border Radius', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                    '%' => ['min' => 0, 'max' => 50],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .image-container img.shape-rounded_square' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'image_shape' => 'rounded_square',
                ],
            ]
        );

        $this->add_control(
            'image_shape_styles',
            [
                'label' => __('Image Shape Styles', 'demo-sample'),
                'type' => Controls_Manager::HIDDEN,
                'selectors' => [
                    '{{WRAPPER}} .image-container img.shape-circle' => 'border-radius: 50%; aspect-ratio: 1/1; object-fit: cover;',
                    '{{WRAPPER}} .image-container img.shape-square' => 'border-radius: 0; aspect-ratio: 1/1; object-fit: cover;',
                    '{{WRAPPER}} .image-container img.shape-organic_blob' => 'clip-path: polygon(25% 15%, 75% 10%, 90% 50%, 75% 85%, 25% 90%, 10% 50%);',
                ],
            ]
        );

        $this->add_control(
            'image_divider_style',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->end_controls_section();

        // Card 1 Styling Section
        $this->start_controls_section(
            'card_1_style_section',
            [
                'label' => __('Card 1 Styling', 'demo-sample'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_1_position_type',
            [
                'label' => __('Position Type', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => 'absolute',
                'options' => [
                    'absolute' => __('Absolute', 'demo-sample'),
                    'relative' => __('Relative', 'demo-sample'),
                    'fixed' => __('Fixed', 'demo-sample'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'position: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_position_top',
            [
                'label' => __('Top Position', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 500],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 2.6,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 2,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'card_1_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_position_left',
            [
                'label' => __('Left Position', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 43,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 56,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 70,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'card_1_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_control(
            'card_1_transform',
            [
                'label' => __('Horizontal Center', 'demo-sample'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'transform: translateX(-50%);',
                ],
                'condition' => [
                    'card_1_position_left[unit]' => '%',
                    'card_1_position_left[size]' => 50,
                    'card_1_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_width',
            [
                'label' => __('Width', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 190,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 150,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'max-width: {{SIZE}}{{UNIT}}; width: 100%;',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_height',
            [
                'label' => __('Height', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 160,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 60,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_1_background',
            [
                'label' => __('Background', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => 'rgba(255, 255, 255, 0.8)',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_title_font_size',
            [
                'label' => __('Title Font Size', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 50],
                    'em' => ['min' => 0.5, 'max' => 3],
                    'rem' => ['min' => 0.5, 'max' => 3],
                ],
                'default' => [
                    'unit' => 'em',
                    'size' => 1.3,
                ],
                'tablet_default' => [
                    'unit' => 'em',
                    'size' => 1.1,
                ],
                'mobile_default' => [
                    'unit' => 'em',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-title' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_title_font_weight',
            [
                'label' => __('Title Font Weight', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => '400',
                'options' => [
                    '100' => __('100', 'demo-sample'),
                    '200' => __('200', 'demo-sample'),
                    '300' => __('300', 'demo-sample'),
                    '400' => __('400', 'demo-sample'),
                    '500' => __('500', 'demo-sample'),
                    '600' => __('600', 'demo-sample'),
                    '700' => __('700', 'demo-sample'),
                    '800' => __('800', 'demo-sample'),
                    '900' => __('900', 'demo-sample'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-title' => 'font-weight: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_content_font_size',
            [
                'label' => __('Content Font Size', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 50],
                    'em' => ['min' => 0.5, 'max' => 3],
                    'rem' => ['min' => 0.5, 'max' => 3],
                ],
                'default' => [
                    'unit' => 'em',
                    'size' => 3,
                ],
                'tablet_default' => [
                    'unit' => 'em',
                    'size' => 2.5,
                ],
                'mobile_default' => [
                    'unit' => 'em',
                    'size' => 1.5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-content' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_content_font_weight',
            [
                'label' => __('Content Font Weight', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => '600',
                'options' => [
                    '100' => __('100', 'demo-sample'),
                    '200' => __('200', 'demo-sample'),
                    '300' => __('300', 'demo-sample'),
                    '400' => __('400', 'demo-sample'),
                    '500' => __('500', 'demo-sample'),
                    '600' => __('600', 'demo-sample'),
                    '700' => __('700', 'demo-sample'),
                    '800' => __('800', 'demo-sample'),
                    '900' => __('900', 'demo-sample'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-content' => 'font-weight: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_1_text_color',
            [
                'label' => __('Text Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-text);',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-title, {{WRAPPER}} .overlay-card-1 .card-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_title_padding',
            [
                'label' => __('Title Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 0,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 6,
                    'right' => 6,
                    'bottom' => 0,
                    'left' => 6,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 4,
                    'right' => 4,
                    'bottom' => 0,
                    'left' => 4,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_title_margin',
            [
                'label' => __('Title Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_content_padding',
            [
                'label' => __('Content Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 6,
                    'right' => 6,
                    'bottom' => 6,
                    'left' => 6,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 4,
                    'right' => 4,
                    'bottom' => 4,
                    'left' => 4,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_content_margin',
            [
                'label' => __('Content Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 8,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 6,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 4,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1 .card-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_padding',
            [
                'label' => __('Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_1_margin',
            [
                'label' => __('Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Badge Styles
        $this->add_control(
            'badge_background_color',
            [
                'label' => __('Badge Background Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--e-global-color-secondary)',
                'selectors' => [
                    '{{WRAPPER}} .badge' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'badge_text_color',
            [
                'label' => __('Badge Text Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .badge' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'badge_padding',
            [
                'label' => __('Badge Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'default' => [
                    'top' => 5,
                    'right' => 10,
                    'bottom' => 5,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 4,
                    'right' => 8,
                    'bottom' => 4,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 3,
                    'right' => 6,
                    'bottom' => 3,
                    'left' => 6,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'badge_margin',
            [
                'label' => __('Badge Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 0,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 0,
                    'right' => 6,
                    'bottom' => 6,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'badge_border_radius',
            [
                'label' => __('Badge Border Radius', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 20],
                    '%' => ['min' => 0, 'max' => 50],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .badge' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Card 2 Styling Section
        $this->start_controls_section(
            'card_2_style_section',
            [
                'label' => __('Card 2 Styling', 'demo-sample'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'enable_card_2' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'card_2_position_type',
            [
                'label' => __('Position Type', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => 'absolute',
                'options' => [
                    'absolute' => __('Absolute', 'demo-sample'),
                    'relative' => __('Relative', 'demo-sample'),
                    'fixed' => __('Fixed', 'demo-sample'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'position: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_position_top',
            [
                'label' => __('Top Position', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 15,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => 18.8,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => 17,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'card_2_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_position_left',
            [
                'label' => __('Left Position', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => -4,
                ],
                'tablet_default' => [
                    'unit' => '%',
                    'size' => -1,
                ],
                'mobile_default' => [
                    'unit' => '%',
                    'size' => -4,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'card_2_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_control(
            'card_2_transform',
            [
                'label' => __('Horizontal Center', 'demo-sample'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'transform: translateX(-50%);',
                ],
                'condition' => [
                    'card_2_position_left[unit]' => '%',
                    'card_2_position_left[size]' => 50,
                    'card_2_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_width',
            [
                'label' => __('Width', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 290,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 215,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 150,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'max-width: {{SIZE}}{{UNIT}}; width: 100%;',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_height',
            [
                'label' => __('Height', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 500],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 160,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 60,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_2_background',
            [
                'label' => __('Background', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => 'rgba(255, 255, 255, 0.8)',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_title_font_size',
            [
                'label' => __('Title Font Size', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 50],
                    'em' => ['min' => 0.5, 'max' => 3],
                    'rem' => ['min' => 0.5, 'max' => 3],
                ],
                'default' => [
                    'unit' => 'em',
                    'size' => 1.5,
                ],
                'tablet_default' => [
                    'unit' => 'em',
                    'size' => 1.3,
                ],
                'mobile_default' => [
                    'unit' => 'em',
                    'size' => 1.1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-title' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_title_font_weight',
            [
                'label' => __('Title Font Weight', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => '600',
                'options' => [
                    '100' => __('100', 'demo-sample'),
                    '200' => __('200', 'demo-sample'),
                    '300' => __('300', 'demo-sample'),
                    '400' => __('400', 'demo-sample'),
                    '500' => __('500', 'demo-sample'),
                    '600' => __('600', 'demo-sample'),
                    '700' => __('700', 'demo-sample'),
                    '800' => __('800', 'demo-sample'),
                    '900' => __('900', 'demo-sample'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-title' => 'font-weight: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_content_font_size',
            [
                'label' => __('Content Font Size', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 50],
                    'em' => ['min' => 0.5, 'max' => 3],
                    'rem' => ['min' => 0.5, 'max' => 3],
                ],
                'default' => [
                    'unit' => 'em',
                    'size' => 1,
                ],
                'tablet_default' => [
                    'unit' => 'em',
                    'size' => 0.95,
                ],
                'mobile_default' => [
                    'unit' => 'em',
                    'size' => 0.85,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-content' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_content_font_weight',
            [
                'label' => __('Content Font Weight', 'demo-sample'),
                'type' => Controls_Manager::SELECT,
                'default' => '400',
                'options' => [
                    '100' => __('100', 'demo-sample'),
                    '200' => __('200', 'demo-sample'),
                    '300' => __('300', 'demo-sample'),
                    '400' => __('400', 'demo-sample'),
                    '500' => __('500', 'demo-sample'),
                    '600' => __('600', 'demo-sample'),
                    '700' => __('700', 'demo-sample'),
                    '800' => __('800', 'demo-sample'),
                    '900' => __('900', 'demo-sample'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-content' => 'font-weight: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_2_text_color',
            [
                'label' => __('Text Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-text);',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-title, {{WRAPPER}} .overlay-card-2 .card-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_title_padding',
            [
                'label' => __('Title Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 6,
                    'right' => 6,
                    'bottom' => 6,
                    'left' => 6,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 4,
                    'right' => 4,
                    'bottom' => 4,
                    'left' => 4,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_title_margin',
            [
                'label' => __('Title Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 8,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 6,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 4,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_content_padding',
            [
                'label' => __('Content Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 6,
                    'right' => 6,
                    'bottom' => 6,
                    'left' => 6,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 4,
                    'right' => 4,
                    'bottom' => 4,
                    'left' => 4,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_content_margin',
            [
                'label' => __('Content Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 8,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 6,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 4,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_padding',
            [
                'label' => __('Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_2_margin',
            [
                'label' => __('Margin', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 8,
                    'right' => 8,
                    'bottom' => 8,
                    'left' => 8,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        // Button Styles
        $this->add_control(
            'card_button_text_color',
            [
                'label' => __('Button Text Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-button' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'card_button_background_color',
            [
                'label' => __('Button Background Color', 'demo-sample'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--e-global-color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-button' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_button_border_radius',
            [
                'label' => __('Button Border Radius', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 50],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'tablet_default' => [
                    'unit' => 'px',
                    'size' => 4,
                ],
                'mobile_default' => [
                    'unit' => 'px',
                    'size' => 3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-button' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_button_padding',
            [
                'label' => __('Button Padding', 'demo-sample'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => 10,
                    'right' => 20,
                    'bottom' => 10,
                    'left' => 20,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'top' => 8,
                    'right' => 16,
                    'bottom' => 8,
                    'left' => 16,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'top' => 6,
                    'right' => 12,
                    'bottom' => 6,
                    'left' => 12,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_button_font_size',
            [
                'label' => __('Button Font Size', 'demo-sample'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 50],
                    'em' => ['min' => 0.5, 'max' => 3],
                    'rem' => ['min' => 0.5, 'max' => 3],
                ],
                'default' => [
                    'unit' => 'em',
                    'size' => 1,
                ],
                'tablet_default' => [
                    'unit' => 'em',
                    'size' => 0.95,
                ],
                'mobile_default' => [
                    'unit' => 'em',
                    'size' => 0.85,
                ],
                'selectors' => [
                    '{{WRAPPER}} .overlay-card-2 .card-button' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'enable_card_2' => 'yes',
                    'enable_card_button_2' => 'yes',
                ],
            ]
        );
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $image_url = $settings['image']['url'] ?? Utils::get_placeholder_image_src();
        $card_title_1 = $settings['card_title_1'] ?? '';
        $card_content_1 = $settings['card_content_1'] ?? '';
        $card_title_2 = $settings['card_title_2'] ?? '';
        $card_content_2 = $settings['card_content_2'] ?? '';
        $button_text_2 = $settings['card_button_text_2'] ?? '';
        $button_url_2 = $settings['card_button_url_2']['url'] ?? '#';
        $enable_button_2 = $settings['enable_card_button_2'] ?? 'yes';
        $enable_card_2 = $settings['enable_card_2'] ?? '';
        $enable_overlay_images = $settings['enable_overlay_images'] ?? '';
        $image_shape = $settings['image_shape'] ?? 'square';
        $badge_text = $settings['badge_text'] ?? '';
        $badge_icon = $settings['badge_icon']['value'] ?? 'eicon-arrow-up';
?>
        <div class="image-overlay-widget" style="position: relative;">
            <div class="image-container">
                <img src="<?php echo esc_url($image_url); ?>" alt="Main Image" class="shape-<?php echo esc_attr($image_shape); ?>">
            </div>

            <?php if ($enable_overlay_images === 'yes' && !empty($settings['overlay_images'])) : ?>
                <?php foreach ($settings['overlay_images'] as $item) : ?>
                    <?php if (!empty($item['overlay_image']['url'])) : ?>
                        <div class="overlay-image-container elementor-repeater-item-<?php echo esc_attr($item['_id']); ?>" style="position: absolute;">
                            <img src="<?php echo esc_url($item['overlay_image']['url']); ?>" alt="Overlay Image">
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>

            <div class="overlay-card-1">
                <?php if (!empty($card_title_1)) : ?>
                    <h3 class="card-title"><?php echo esc_html($card_title_1); ?></h3>
                <?php endif; ?>
                <?php if (!empty($card_content_1)) : ?>
                    <p class="card-content"><?php echo esc_html($card_content_1); ?></p>
                <?php endif; ?>
                <?php if (!empty($badge_text) && !empty($badge_icon)) : ?>
                    <span class="badge">
                        <?php Icons_Manager::render_icon($settings['badge_icon'], ['aria-hidden' => 'true', 'style' => 'margin-right: 5px; width: 15px']); ?>
                        <?php echo esc_html($badge_text); ?>
                    </span>
                <?php endif; ?>
            </div>

            <?php if ($enable_card_2 === 'yes') : ?>
                <div class="overlay-card-2">
                    <?php if (!empty($card_title_2)) : ?>
                        <h3 class="card-title"><?php echo esc_html($card_title_2); ?></h3>
                    <?php endif; ?>
                    <?php if (!empty($card_content_2)) : ?>
                        <p class="card-content"><?php echo esc_html($card_content_2); ?></p>
                    <?php endif; ?>
                    <?php if ($enable_button_2 === 'yes' && !empty($button_text_2)) : ?>
                        <a href="<?php echo esc_url($button_url_2); ?>" class="card-button" style="text-decoration: none; display: inline-block;"><?php echo esc_html($button_text_2); ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php
    }

    protected function content_template()
    {
    ?>
        <div class="image-overlay-widget" style="position: relative;">
            <div class="image-container">
                <img src="{{{ settings.image.url || '<?php echo esc_url(Utils::get_placeholder_image_src()); ?>' }}}" alt="Main Image" class="shape-{{{ settings.image_shape || 'square' }}}">
            </div>

            <# if ( settings.enable_overlay_images==='yes' && settings.overlay_images.length ) { #>
                <# _.each( settings.overlay_images, function( item ) { #>
                    <# if ( item.overlay_image.url ) { #>
                        <div class="overlay-image-container elementor-repeater-item-{{ item._id }}" style="position: absolute;">
                            <img src="{{ item.overlay_image.url }}" alt="Overlay Image">
                        </div>
                        <# } #>
                            <# }); #>
                                <# } #>

                                    <div class="overlay-card-1">
                                        <# if (settings.card_title_1) { #>
                                            <h3 class="card-title">{{{ settings.card_title_1 }}}</h3>
                                            <# } #>
                                                <# if (settings.card_content_1) { #>
                                                    <p class="card-content">{{{ settings.card_content_1 }}}</p>
                                                    <# } #>
                                                        <# if (settings.badge_text && settings.badge_icon.value) { #>
                                                            <span class="badge">
                                                                <?php Icons_Manager::render_icon(['value' => '{{ settings.badge_icon.value }}', 'library' => '{{ settings.badge_icon.library }}'], ['aria-hidden' => 'true', 'style' => 'margin-right: 5px;']); ?>
                                                                {{{ settings.badge_text }}}
                                                            </span>
                                                            <# } #>
                                    </div>

                                    <# if (settings.enable_card_2==='yes' ) { #>
                                        <div class="overlay-card-2">
                                            <# if (settings.card_title_2) { #>
                                                <h3 class="card-title">{{{ settings.card_title_2 }}}</h3>
                                                <# } #>
                                                    <# if (settings.card_content_2) { #>
                                                        <p class="card-content">{{{ settings.card_content_2 }}}</p>
                                                        <# } #>
                                                            <# if (settings.enable_card_button_2==='yes' && settings.card_button_text_2) { #>
                                                                <a href="{{ settings.card_button_url_2.url || '#' }}" class="card-button" style="text-decoration: none; display: inline-block;">{{{ settings.card_button_text_2 }}}</a>
                                                                <# } #>
                                        </div>
                                        <# } #>
        </div>
<?php
    }
}
