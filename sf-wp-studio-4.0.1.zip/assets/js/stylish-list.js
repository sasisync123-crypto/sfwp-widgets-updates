(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf-stylish-list.default', function ($scope) {
            customTimelineHover($scope);
        });
    });

    function customTimelineHover($scope) {
        const containers = document.getElementsByClassName("section");
        const images = document.getElementsByClassName("image");

        function isInViewport(element) {
            if (!element) return false;
            const rect = element.getBoundingClientRect();
            const windowHeight = window.innerHeight || document.documentElement.clientHeight;
            return rect.top <= windowHeight / 2 && rect.bottom >= windowHeight / 2;
        }

      function handleImageVisibility() {
            let activeSectionFound = false;

            Array.from(containers).forEach((section, index) => {
                const image = images[index];
                if (!image) return;

                if (section && isInViewport(section)) {
                    image.classList.add('active');
                    activeSectionFound = true;
                } else {
                    image.classList.remove('active');
                }
            });

            if (!activeSectionFound && images.length > 0) {
                images[0].classList.add('active');
            }
        }

        window.addEventListener('scroll', handleImageVisibility);
        window.addEventListener('load', handleImageVisibility);

        handleImageVisibility();

        //glow effect
        document.querySelectorAll(".stylish").forEach((card) => {
            const blob = card.querySelector(".blob");
            const fakeBlob = card.querySelector(".fakeblob");
 
            if (!blob || !fakeBlob) return;
 
            const showGlow = () => {
                blob.style.opacity = "1";
            };
 
            const moveGlow = (event) => {
                const rect = fakeBlob.getBoundingClientRect();
                const x = event.clientX - rect.left - rect.width / 2;
                const y = event.clientY - rect.top - rect.height / 2;
 
                blob.animate([{ transform: `translate(${x}px, ${y}px)` }], {
                    duration: 300,
                    fill: "forwards"
                });
            };
 
            const hideGlow = () => {
                blob.style.opacity = "0";
            };
 
            card.addEventListener("mouseenter", showGlow);
            card.addEventListener("mousemove", moveGlow);
            card.addEventListener("mouseleave", hideGlow);
        });
 
    }
})(jQuery);
