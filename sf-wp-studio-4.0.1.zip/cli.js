#!/usr/bin/env node
import { Command } from 'commander';
import inquirer from 'inquirer';
import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import simpleGit from 'simple-git';
const program = new Command();

// Config
const TARGET_DIR = 'D:/Browser-Downloads/sfwp-widgets-updates';
const REPO_URL = 'git@github.com:sasisync123-crypto/sfwp-widgets-updates.git';
const BRANCH = 'main';
const PLUGIN_NAME = 'sf-wp-studio';

async function zipSourceFolder(version) {
  const zipPath = path.join(TARGET_DIR, `${PLUGIN_NAME}-${version}.zip`);
  const output = fs.createWriteStream(zipPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(process.cwd(), false); // zip current folder
    archive.finalize();
  });
}

function writeUpdateJson(version, description) {
  const jsonPath = path.join(TARGET_DIR, 'update.json');
  const jsonData = {
    name: 'Sasi widget',
    version,
    download_url: `https://github.com/sasisync123-crypto/sfwp-widgets-updates/raw/${BRANCH}/${PLUGIN_NAME}-${version}.zip`,
    sections: {
      description
    }
  };
  fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2));
  return jsonPath;
}

async function pushProductionFolder(version) {
  const git = simpleGit(TARGET_DIR);

  const remotes = await git.getRemotes(true);
  const hasOrigin = remotes.some(r => r.name === 'origin');
  if (!hasOrigin) {
    await git.addRemote('origin', REPO_URL);
  }

  await git.add(['*.zip', 'update.json']);
  await git.commit(`Deploy version ${version}`);
  await git.push('origin', BRANCH);

  console.log(`✅ Deployed ${version} to GitHub`);
}

async function deploy() {
  const answers = await inquirer.prompt([
    {
      type: 'input',
      name: 'version',
      message: 'Enter version number:',
      validate: input => input ? true : 'Version is required'
    },
    {
      type: 'input',
      name: 'description',
      message: 'Enter description:',
      default: 'Powerful widget from sfwp team'
    }
  ]);

  const { version, description } = answers;

  await zipSourceFolder(version);
  writeUpdateJson(version, description);
  await pushProductionFolder(version);
}

program
  .command('deploy')
  .description('Deploy plugin to production GitHub repo')
  .action(deploy);

program.parse(process.argv);
