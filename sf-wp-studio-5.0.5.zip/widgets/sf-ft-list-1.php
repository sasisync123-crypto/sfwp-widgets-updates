<?php

namespace SFWPStudio\Widgets;

if (!defined('ABSPATH')) exit;

if (!function_exists('wp_get_attachment_image_url')) {
    require_once ABSPATH . 'wp-includes/media.php';
}

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Icons_Manager;

class SF_FT_LIST_1 extends Widget_Base
{
    use \SFWPStudio\Core\Helpers\Traits\Progressbar_Trait;
    public function get_name()
    {
        return 'sf-ft-list-1';
    }
    public function get_title()
    {
        return esc_html__('SF FT List 1', 'sf-widget');
    }
    public function get_icon()
    {
        return 'eicon-library-list';
    }
    public function get_keywords()
    {
        return ['dual', 'interactive', 'rows', 'image', 'heading'];
    }
    public function get_script_depends()
    {
        return ['sf-ft-list-1'];
    }
    public function get_style_depends()
    {
        return ['sf-ft-list-1'];
    }
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    protected function register_controls()
    {
        // === CONTENT TAB: Rows ===
        $this->start_controls_section('rows_section', [
            'label' => esc_html__('Rows', 'sf-widget'),
            'tab' => Controls_Manager::TAB_CONTENT
        ]);

        $repeater = new Repeater();

        $repeater->add_control('row_icon', [
            'label' => esc_html__('Icon', 'sf-widget'),
            'type' => Controls_Manager::ICONS,
            'default' => ['value' => 'fas fa-check', 'library' => 'fa-solid'],
        ]);

        $repeater->add_control('row_title', [
            'label' => esc_html__('Title', 'sf-widget'),
            'type' => Controls_Manager::TEXT,
            'default' => 'Real time data',
            'label_block' => true
        ]);

        $repeater->add_control('row_desc_show', [
            'label' => esc_html__('Show Description', 'sf-widget'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes'
        ]);

        $repeater->add_control('row_desc', [
            'label' => esc_html__('Description', 'sf-widget'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => '',
            'condition' => ['row_desc_show' => 'yes']
        ]);

        $repeater->add_control('row_image', [
            'label' => esc_html__('Image', 'sf-widget'),
            'type' => Controls_Manager::MEDIA,
            'default' => ['url' => '']
        ]);

        $this->add_control('rows', [
            'label' => esc_html__('Rows', 'sf-widget'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'row_icon' => ['value' => 'fas fa-check', 'library' => 'fa-solid'],
                    'row_title' => 'Real time data',
                    'row_desc' => 'Leverage real-time insights for well-informed decisions.',
                ],
                [
                    'row_icon' => ['value' => 'fas fa-star', 'library' => 'fa-solid'],
                    'row_title' => 'Real time data',
                    'row_desc' => 'Track key metrics based on data-driven analysis',
                ],
            ],
            'title_field' => '{{{ row_title }}}'
        ]);

        $this->end_controls_section();

        // === STYLE TAB: Layout ===
        $this->start_controls_section('layout_section', [
            'label' => esc_html__('Layout', 'sf-widget'),
            'tab' => Controls_Manager::TAB_STYLE
        ]);

        $this->add_responsive_control('image_column_width', [
            'label' => esc_html__('Image Column Width (%)', 'sf-widget'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['%'],
            'range' => ['%' => ['min' => 30, 'max' => 70]],
            'default' => ['size' => 50],
            'selectors' => [
                '{{WRAPPER}} .sf-image-column' => 'flex: 0 0 {{SIZE}}%; width: {{SIZE}}%;',
                '{{WRAPPER}} .sf-text-column' => 'flex: 0 0 calc(100% - {{SIZE}}%);',
            ],
        ]);

        $this->add_responsive_control('columns_gap', [
            'label'     => esc_html__('Columns Gap', 'sf-widget'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'range'     => ['px' => ['min' => 0, 'max' => 100]],
            'selectors' => ['{{WRAPPER}} .sf-dual-container' => 'gap: {{SIZE}}{{UNIT}};'],
        ]);

        $this->add_responsive_control('row_gap', [
            'label' => esc_html__('Row Gap', 'sf-widget'),
            'type' => Controls_Manager::SLIDER,
            'default' => ['size' => 24],
            'selectors' => [
                '{{WRAPPER}} .sf-row' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
            'separator' => 'before',
        ]);

        $this->add_control('flip_layout', [
            'label'        => esc_html__('Flip Layout', 'sf-widget'),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__('Image Left', 'sf-widget'),
            'label_off'    => esc_html__('Text Left', 'sf-widget'),
            'return_value' => 'yes',
            'default'      => 'no',
            'prefix_class' => 'sf-flip-layout-',
            'description'  => esc_html__('Enable to show Image on Left and Text on Right', 'sf-widget'),
            'separator'    => 'before',
        ]);

        $this->add_control('active_row_border_radius', [
            'label' => esc_html__('Active Row Border Radius', 'sf-widget'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => ['px' => ['min' => 0, 'max' => 50]],
            'default' => ['size' => 16],
            'selectors' => [
                '{{WRAPPER}} .sf-row.active' => 'border-radius: {{SIZE}}{{UNIT}};',
            ],
            'separator' => 'before',
        ]);

        $this->end_controls_section();

        // === STYLE TAB: Row Colors ===
        $this->start_controls_section('row_colors_section', [
            'label' => esc_html__('Row Colors', 'sf-widget'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('row_bg_color', [
            'label'     => esc_html__('Row Background', 'sf-widget'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .sf-row' => 'background-color: {{VALUE}};'],
        ]);

        $this->add_control('row_active_bg_color', [
            'label'     => esc_html__('Active Row Background', 'sf-widget'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}}:not(.sf-autoplay-yes) .sf-row.active' => 'background-color: {{VALUE}} !important;'],
            'description' => esc_html__('Used when Autoplay is OFF.', 'sf-widget'),
        ]);

        $this->add_control('row_active_text_color', [
            'label'     => esc_html__('Active Row Title Color', 'sf-widget'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .sf-row.active .sf-row-title' => 'color: {{VALUE}} !important;'],
        ]);

        $this->end_controls_section();

        $this->start_controls_section('icon_colors_section', [
            'label' => esc_html__('Icon Colors', 'sf-widget'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-row-icon' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'icon_active_color',
            [
                'label' => esc_html__('Active Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-row.active .sf-row-icon' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rows = $settings['rows'] ?? [];
        if (empty($rows)) return;

        $image_urls = $image_titles = [];
        foreach ($rows as $row) {
            $image_urls[] = $row['row_image']['url'] ?? '';
            $image_titles[] = $row['row_title'] ?? '';
        }

        $autoplay = $settings['enable_autoplay'] ?? 'no';
        $duration = ($autoplay === 'yes' && !empty($settings['progressbar_duration']['size']))
            ? $settings['progressbar_duration']['size']
            : 5000;
        $color = ($autoplay === 'yes' && !empty($settings['progressbar_color']))
            ? $settings['progressbar_color']
            : 'var(--e-global-color-primary)';
?>
        <div class="sf-dual-container"
            data-image-urls="<?php echo esc_attr(json_encode($image_urls)); ?>"
            data-image-titles="<?php echo esc_attr(json_encode($image_titles)); ?>"
            data-autoplay="<?php echo esc_attr($settings['enable_autoplay']); ?>"
            data-progress-color="<?php echo esc_attr($color); ?>">

            <div class="sf-text-column">
                <?php foreach ($rows as $index => $row):
                    $img_id = $row['row_image']['id'] ?? 0;
                    $img_url = $row['row_image']['url'] ?? '';
                    $mobile_src = $img_id ? wp_get_attachment_image_url($img_id, 'large') : $img_url;
                ?>
                    <div class="sf-row elementor-repeater-item-<?php echo esc_attr($row['_id']); ?>"
                        data-index="<?php echo esc_attr($index); ?>">

                        <?php if ($autoplay === 'yes'): ?>
                            <div class="sf-progress-wrapper" data-duration="<?php echo esc_attr($duration); ?>">
                                <div class="sf-progress-bar">
                                    <div class="sf-progress-fill" style="background: <?php echo esc_attr($color); ?>;"></div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="sf-row-content">
                            <div class="sf-title-wrapper">
                                <?php Icons_Manager::render_icon($row['row_icon'], ['class' => 'sf-row-icon']); ?>
                                <h4 class="sf-row-title"><?php echo esc_html($row['row_title']); ?></h4>
                            </div>

                            <?php if (!empty($row['row_desc_show']) && $row['row_desc_show'] === 'yes'): ?>
                                <div class="sf-row-desc"><?php echo wp_kses_post($row['row_desc']); ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if ($mobile_src): ?>
                            <img src="<?php echo esc_url($mobile_src); ?>" alt="<?php echo esc_attr($row['row_title']); ?>" class="sf-mobile-image" loading="lazy">
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="sf-image-column desktop-only">
                <?php
                $first_url = $rows[0]['row_image']['url'] ?? '';
                if ($first_url):
                ?>
                    <img src="<?php echo esc_url($first_url); ?>" alt="" class="sf-main-image" loading="lazy">
                <?php endif; ?>
            </div>
        </div>
<?php
    }
}
