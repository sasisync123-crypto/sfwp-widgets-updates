<?php
namespace SFWPStudio\Widgets;

if (!defined('ABSPATH')) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
 
// Group Controls
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
 
// Media & Icons
use Elementor\Icons_Manager;
use Elementor\Control_Media;
 
// Other Control Types
use Elementor\Control_Select2;
use Elementor\Control_Slider;
use Elementor\Control_Switcher;
use Elementor\Control_Heading;
use Elementor\Control_Textarea;
use Elementor\Control_Number;
use Elementor\Control_Dimensions;
use Elementor\Control_Color;
use Elementor\Control_Gallery;
use Elementor\Control_Date_Time;
use Elementor\Control_Code;
 
// Schemes
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
 
// Utilities & Core
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Core\Base\Document;
use Elementor\Core\Responsive\Responsive;
use Elementor\Core\Kits\Documents\Kit;
use Elementor\Core\Settings\Manager;
class Footer extends Widget_Base {
	use \ElementsKit_Lite\Widgets\Widget_Notice;
    use \SFWPStudio\Core\Helpers\Traits\ButtonTrait;
    use \SFWPStudio\Core\Helpers\Traits\ListTrait;
    use \SFWPStudio\Core\Helpers\Traits\ParaTrait;


	public function get_name() {
        return 'sf-footer';
    }
 
    public function get_title() {
        return __( 'SF Section Footer', 'my-elementor-widgets' );
    }
 
    public function get_icon() {
        return 'sync-widget-icon eicon-tabs';
    }

    public function get_keywords()
    {
        return ['sf' ,'footer'];
    }

   //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS

    protected function register_controls() {


        //SF List Control
        $this->register_list_controls( "no", "row");

        //SF Button Control
        $this->register_button_controls("One");

        // SF_PARA Content Section
        $this->register_para_controls();

        $this->update_responsive_control(
            'sf_list_spacing_margin',
            [
                'default' => [
                    'top'      => '',
                    'right'    => '',
                    'bottom'   => '',
                    'left'     => '',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->start_controls_section(
            'sf_outer_wrapper_layout',
            [
                'label' => __('Outer Wrapper Layout', 'plugin-name'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'sf_flex_direction',
            [
                'label' => esc_html__('Flex Direction', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'row' => 'Row',
                    'row-reverse' => 'Row Reverse',
                    'column' => 'Column',
                    'column-reverse' => 'Column Reverse',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-footer-wrapper' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

      $this->add_control(
            'sf_justify_content',
            [
                'label' => esc_html__('X-Axis Alignment', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'flex-start'    => 'Start',
                    'center'        => 'Center',
                    'flex-end'      => 'End',
                    'space-between' => 'Space Between',
                    'space-around'  => 'Space Around',
                    'space-evenly'  => 'Space Evenly',
                    'start'         => 'Start (LTR)',
                    'end'           => 'End (LTR)',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-footer-wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        
        $this->add_control(
            'sf_align_items',
            [
                'label' => esc_html__('Y-Axis Alignment', 'plugin-domain'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'flex-start' => 'Start',
                    'center' => 'Center',
                    'flex-end' => 'End',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-footer-wrapper' => 'align-items: {{VALUE}};',
                ],
            ]
        );

        /* ----- Row Gap (shown only when direction is row / row-reverse) ----- */
    $this->add_responsive_control(
        'sf_row_gap',
        [
            'label'      => esc_html__('Row Gap', 'plugin-name'),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', 'em', '%', 'rem'],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 200 ] ],
            'selectors'  => [
                '{{WRAPPER}} .sf-footer-wrapper' => 'column-gap: {{SIZE}}{{UNIT}};',
            ],
            'condition'  => [
                'sf_flex_direction' => [ 'row', 'row-reverse' ],
            ],
        ]
    );

    /* ----- Column Gap (shown only when direction is column / column-reverse) ----- */
    $this->add_responsive_control(
        'sf_column_gap',
        [
            'label'      => esc_html__('Column Gap', 'plugin-name'),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', 'em', '%', 'rem'],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 200 ] ],
            'selectors'  => [
                '{{WRAPPER}} .sf-footer-wrapper' => 'row-gap: {{SIZE}}{{UNIT}};',
            ],
            'condition'  => [
                'sf_flex_direction' => [ 'column', 'column-reverse' ],
            ],
        ]
    );
    $this->end_controls_section();

    $this->start_controls_section(
        'sf_order_section',
        [
            'label' => esc_html__('Order', 'elementskit-lite'),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'sf_button_position',
        [
            'label' => esc_html__('Button Position', 'elementskit-lite'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'before' => esc_html__('Before List', 'elementskit-lite'),
                'after'  => esc_html__('After List', 'elementskit-lite'),
                'afterpara'  => esc_html__('After Para', 'elementskit-lite'),
            ],
            'default' => 'after',
        ]
    );

    $this->end_controls_section();
	
    $this->insert_pro_message();
    }

    protected function render( ) {
        echo '<div class="ekit-wid-con" >';
			$this->render_raw();
        echo '</div>';
    }

    protected function render_raw( ) {

        $settings = $this->get_settings_for_display();
		extract($settings);

        echo '<div class="sf-footer-wrapper">';

        if ( $settings['sf_button_position'] === 'before' ) {
            $this->render_button("One");
        }
        
        $this->render_list();
       
        if ( $settings['sf_button_position'] === 'after') {
            $this->render_button("One");
        }
        
        echo '<div class="sf-paragraph-button-wrapper">';
        $this->render_para();
        echo '</div>'; 

        if ( $settings['sf_button_position'] === 'afterpara') {
            $this->render_button("One");
        }
	}
}