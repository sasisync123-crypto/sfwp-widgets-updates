#!/usr/bin/env node
import { Command } from 'commander';
import inquirer from 'inquirer';
import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import simpleGit from 'simple-git';
import chalk from 'chalk';

const program = new Command();
const PLUGIN_NAME = 'sf-wp-studio';

// 🔧 Helper: read last version from update.json
function getLastVersion(targetDir) {
  try {
    const jsonPath = path.join(targetDir, 'update.json');
    if (fs.existsSync(jsonPath)) {
      const data = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
      return data.version || null;
    }
  } catch {
    return null;
  }
  return null;
}

// 🔧 Helper: bump version (simple semver patch bump)
function bumpVersion(version) {
  const parts = version.split('.');
  parts[parts.length - 1] = String(Number(parts[parts.length - 1]) + 1);
  return parts.join('.');
}

function cleanBeforeZip() {
  const itemsToRemove = ['docs', '.gitignore', 'tests', 'readme.txt'];
  for (const item of itemsToRemove) {
    const fullPath = path.join(process.cwd(), item);
    if (fs.existsSync(fullPath)) {
      const stat = fs.statSync(fullPath);
      try {
        if (stat.isDirectory()) {
          fs.rmSync(fullPath, { recursive: true, force: true });
        } else {
          fs.unlinkSync(fullPath);
        }
      } catch (err) {
        // silently ignore errors
      }
    }
  }
  console.log(chalk.blue('🧼 Cleaned for production'));
}


async function zipSourceFolder(version, targetDir) {
  const zipPath = path.join(targetDir, `${PLUGIN_NAME}-${version}.zip`);
  const output = fs.createWriteStream(zipPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(process.cwd(), false);
    archive.finalize();
  });
}

function writeUpdateJson(version, description, targetDir, branch, baseUrl) {
  const jsonPath = path.join(targetDir, 'update.json');
  const jsonData = {
    name: 'Sasi widget',
    version,
    download_url: `${baseUrl}/${PLUGIN_NAME}-${version}.zip`,
    sections: { description }
  };
  fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2));
}

async function pushProductionFolder(version, targetDir, repoUrl, branch) {
  const git = simpleGit(targetDir);

  // ✅ Validation: repo URL must be SSH
  if (!repoUrl.startsWith('git@')) {
    console.log(chalk.red('❌ Repo URL must be SSH (git@...)'));
    process.exit(1);
  }

  // ✅ Validation: target directory exists
  if (!fs.existsSync(targetDir)) {
    console.log(chalk.red(`❌ Target directory does not exist: ${targetDir}`));
    process.exit(1);
  }

  // ✅ Validation: branch exists locally
  const branches = await git.branchLocal();
  if (!branches.all.includes(branch)) {
    console.log(chalk.yellow(`⚠️ Branch '${branch}' does not exist locally. It will be created on push.`));
  }

  const remotes = await git.getRemotes(true);
  if (!remotes.some(r => r.name === 'origin')) {
    await git.addRemote('origin', repoUrl);
  }

  await git.add(['*.zip', 'update.json']);
  await git.commit(`Deploy version ${version}`);
  await git.push('origin', branch);

  console.log(chalk.green(`✅ Deployed ${version} to ${repoUrl} on branch ${branch}`));
}

async function deploy() {
  // Ask for targetDir first so we can auto-bump version
  const { targetDir } = await inquirer.prompt([
    { type: 'input', name: 'targetDir', message: 'Enter target directory:', default: 'D:/Browser-Downloads/sfwp-widgets-updates' }
  ]);

  const lastVersion = getLastVersion(targetDir);
  const suggestedVersion = lastVersion ? bumpVersion(lastVersion) : '1.0.0';

  const answers = await inquirer.prompt([
    { type: 'input', name: 'version', message: 'Enter version number:', default: suggestedVersion },
    { type: 'input', name: 'description', message: 'Enter description:', default: 'Powerful widget from sfwp team' },
    { type: 'input', name: 'repoUrl', message: 'Enter repo URL (SSH):', default: 'git@github.com:sasisync123-crypto/sfwp-widgets-updates.git' },
    { type: 'input', name: 'branch', message: 'Enter branch name:', default: 'main' },
    { type: 'input', name: 'baseUrl', message: 'Enter zip file base URL:', default: 'https://github.com/sasisync123-crypto/sfwp-widgets-updates/raw/main' }
  ]);

  const { version, description, repoUrl, branch, baseUrl } = answers;

cleanBeforeZip();

  console.log(chalk.blue(`📦 Building ZIP for version ${version}...`));
  await zipSourceFolder(version, targetDir);

  console.log(chalk.blue('📝 Writing update.json...'));
  writeUpdateJson(version, description, targetDir, branch, baseUrl);

  console.log(chalk.blue('🚀 Pushing to GitHub...'));
  await pushProductionFolder(version, targetDir, repoUrl, branch);
}

program.command('deploy').description('Deploy plugin').action(deploy);
program.parse(process.argv);
