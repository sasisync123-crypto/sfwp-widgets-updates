(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf-heading.default', function ($scope) {
            Custom_Fancy_Animated_Text($scope);
        });
    });

    function Custom_Fancy_Animated_Text(t) {
        let $fancy = t.find('.ekit-fancy-text');
        if (!$fancy.length) {
            return;
        }
        
        let i = $fancy.data('animation-settings');
        if (!i || 'animated' !== i.animationStyle) {
            return;
        }
        if ('animated' === i.animationStyle) {
            let n = i.animationDelay,
                a = i.loadingBar,
                s = a - 3000,
                o = i.lettersDelay,
                l = i.typeLettersDelay,
                r = i.duration,
                d = r + 800,
                c = i.revealDuration,
                p = i.revealAnimationDelay;
            function f() {
                var i, o;
                t
                    .find('.ekit-fancy-text.letters')
                    .find('b')
                    .each(function () {
                        var t = $(this),
                            i = t.text().split(''),
                            n = t.hasClass('is-visible');
                        for (let e in i) {
                            if (' ' == i[e]) i[e] = '&nbsp;';
                            if (t.parents('.rotate-2').length > 0) i[e] = '<em>' + i[e] + '</em>';
                            i[e] = n ? '<i class="in">' + i[e] + '</i>' : '<i>' + i[e] + '</i>';
                        }
                        var a = i.join('');
                        t.html(a);
                    });
                i = t.find('.ekit-fancy-text');
                o = n;
                i.each(function () {
                    var t = $(this);
                    if (t.hasClass('bar-loading')) {
                        o = a;
                        setTimeout(function () {
                            t.find('.ekit-fancy-text-lists').addClass('is-loading');
                        }, s);
                    } else if (t.hasClass('clip')) {
                        var i = t.find('.ekit-fancy-text-lists'),
                            n = i.width() + 10;
                        i.css('width', n);
                    } else if (t.hasClass('rotate-1')) {
                        var l = t.find('.ekit-fancy-text-lists b'),
                            r = 0,
                            d = 0;
                        l.each(function () {
                            d = $(this).width();
                            if (d > r) r = d;
                        });
                        t.find('.ekit-fancy-text-lists').css('min-width', r);
                    } else if (!t.hasClass('type')) {
                        var l = t.find('.ekit-fancy-text-lists b'),
                            r = 0,
                            d = 0;
                        l.each(function () {
                            d = $(this).innerWidth();
                            if (d > r) r = d;
                        });
                        t.find('.ekit-fancy-text-lists').css('max-width', r);
                    }
                    setTimeout(function () {
                        u(t.find('.is-visible').eq(0));
                    }, o);
                });
            }
            function u(e) {
                var t = g(e);
                if (e.parents('.ekit-fancy-text').hasClass('type')) {
                    var i = e.parent('.ekit-fancy-text-lists');
                    i.addClass('selected').removeClass('waiting');
                    setTimeout(function () {
                        i.removeClass('selected');
                        e.removeClass('is-visible').addClass('is-hidden').children('i').removeClass('in').addClass('out');
                    }, r);
                    setTimeout(function () {
                        h(t, l);
                    }, d);
                } else if (e.parents('.ekit-fancy-text').hasClass('letters')) {
                    var p = e.children('i').length >= t.children('i').length;
                    v(e, t);
                    m(e.find('i').eq(0), e, p, o);
                    k(t.find('i').eq(0), t, p, o);
                } else if (e.parents('.ekit-fancy-text').hasClass('clip')) {
                    e.parents('.ekit-fancy-text-lists').animate({ width: '2px' }, c, function () {
                        v(e, t);
                        h(t);
                    });
                } else if (e.parents('.ekit-fancy-text').hasClass('bar-loading')) {
                    e.parents('.ekit-fancy-text-lists').removeClass('is-loading');
                    v(e, t);
                    setTimeout(function () {
                        u(t);
                    }, a);
                    setTimeout(function () {
                        e.parents('.ekit-fancy-text-lists').addClass('is-loading');
                    }, s);
                } else {
                    v(e, t);
                    setTimeout(function () {
                        u(t);
                    }, n);
                }
            }
            function h(e, t) {
                if (e.parents('.ekit-fancy-text').hasClass('type')) {
                    k(e.find('i').eq(0), e, !1, t);
                    e.addClass('is-visible').removeClass('is-hidden');
                } else if (e.parents('.ekit-fancy-text').hasClass('clip')) {
                    e.parents('.ekit-fancy-text-lists').animate({ width: e.outerWidth() + 0 }, c, function () {
                        setTimeout(function () {
                            u(e);
                        }, p);
                    });
                }
            }
            function m(t, i, a, s) {
                t.removeClass('in').addClass('out');
                if (t.is(':last-child')) {
                    if (a) {
                        setTimeout(function () {
                            u(g(i));
                        }, n);
                    }
                } else {
                    setTimeout(function () {
                        m(t.next(), i, a, s);
                    }, s);
                }
                if (t.is(':last-child') && $('html').hasClass('no-csstransitions')) {
                    var o = g(i);
                    v(i, o);
                }
            }
            function k(e, t, i, a) {
                e.addClass('in').removeClass('out');
                if (e.is(':last-child')) {
                    if (t.parents('.ekit-fancy-text').hasClass('type')) {
                        setTimeout(function () {
                            t.parents('.ekit-fancy-text-lists').addClass('waiting');
                        }, 200);
                    }
                    if (!i) {
                        setTimeout(function () {
                            u(t);
                        }, n);
                    }
                } else {
                    setTimeout(function () {
                        k(e.next(), t, i, a);
                    }, a);
                }
            }
            function g(e) {
                return e.is(':last-child') ? e.parent().children().eq(0) : e.next();
            }
            function v(e, t) {
                e.removeClass('is-visible').addClass('is-hidden');
                t.removeClass('is-hidden').addClass('is-visible');
            }
            f();
        }
    }
})(jQuery);