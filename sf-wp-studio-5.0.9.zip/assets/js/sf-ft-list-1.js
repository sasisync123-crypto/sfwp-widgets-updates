(function ($) {
    'use strict';

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/sf-ft-list-1.default',
            function ($scope) {
                const $container = $scope.find('.sf-dual-container');
                if (!$container.length) return;

                const imageUrls = JSON.parse($container.attr('data-image-urls') || '[]');
                const imageTitles = JSON.parse($container.attr('data-image-titles') || '[]');
                const $rows = $container.find('.sf-row');
                const $mainImage = $container.find('.sf-main-image');
                const isDesktop = window.innerWidth > 1023;
                const enableAutoplay = $container.data('autoplay') === 'yes';
                const progressColor = $container.data('progress-color') || '#10B981';

                let currentIndex = 0;
                let interval = null;
                let isAnimating = false;

                function preloadImage(url, callback) {
                    if (!url) return callback('');
                    const img = new Image();
                    img.onload = () => callback(img.src);
                    img.onerror = () => callback('');
                    img.src = url + '?v=' + Date.now();
                }

                function changeMainImage(index) {
                    if (!isDesktop || !imageUrls[index]) return;
                    preloadImage(imageUrls[index], (src) => {
                        if (src) {
                            $mainImage.css('opacity', 0);
                            setTimeout(() => {
                                $mainImage.attr('src', src)
                                          .attr('alt', imageTitles[index] || '')
                                          .css('opacity', 1);
                            }, 200);
                        }
                    });
                }

                function setActiveRow(index) {
                    $rows.removeClass('active').eq(index).addClass('active');
                    currentIndex = index;
                }

                function hideProgressBar($row, callback) {
                    const $wrapper = $row.find('.sf-progress-wrapper');
                    $wrapper.addClass('hide');
                    setTimeout(callback, 400);
                }

                function startProgress(index) {
                    if (isAnimating || !enableAutoplay) return;
                    isAnimating = true;

                    const $row = $rows.eq(index);
                    const $wrapper = $row.find('.sf-progress-wrapper');
                    if (!$wrapper.length) {
                        isAnimating = false;
                        return;
                    }

                    const duration = parseInt($wrapper.data('duration')) || 5000;
                    const $fill = $row.find('.sf-progress-fill');

                    // SHOW via opacity
                    $wrapper.removeClass('hide').addClass('active');

                    // RESET
                    $fill.css({
                        'transition': 'none',
                        'width': '0%',
                        'background': progressColor
                    });
                    void $fill[0].offsetWidth;

                    // FULL DURATION
                    $fill.css('transition', `width ${duration}ms linear`);

                    const startTime = Date.now();
                    interval = setInterval(() => {
                        const elapsed = Date.now() - startTime;
                        const percent = Math.min(100, (elapsed / duration) * 100);
                        $fill.css('width', percent + '%');

                        if (percent >= 100) {
                            clearInterval(interval);
                            $row.removeClass('active');
                            hideProgressBar($row, () => {
                                const nextIndex = (index + 1) % $rows.length;
                                setActiveRow(nextIndex);
                                changeMainImage(nextIndex);
                                setTimeout(() => {
                                    isAnimating = false;
                                    startProgress(nextIndex);
                                }, 300);
                            });
                        }
                    }, 16);
                }

                function handleRowClick(e) {
                    if (isAnimating) return;
                    const $row = $(e.currentTarget);
                    const index = $row.data('index');

                    if (interval) clearInterval(interval);
                    setActiveRow(index);
                    changeMainImage(index);

                    if (enableAutoplay && $row.find('.sf-progress-wrapper').length) {
                        setTimeout(() => startProgress(index), 600);
                    }
                }

                function reset() {
                    clearInterval(interval);
                    interval = null;
                    isAnimating = false;
                    $rows.removeClass('active');
                    $rows.find('.sf-progress-wrapper').removeClass('active hide');
                    $rows.find('.sf-progress-fill').css('width', '0%');
                }

                function init() {
                    reset();
                    setActiveRow(0);
                    changeMainImage(0);
                    $rows.off('click').on('click', handleRowClick);
                    if (enableAutoplay && $rows.eq(0).find('.sf-progress-wrapper').length) {
                        setTimeout(() => startProgress(0), 800);
                    }
                }

                init();

                let resizeTimer;
                $(window).on('resize', function () {
                    clearTimeout(resizeTimer);
                    resizeTimer = setTimeout(() => {
                        const nowDesktop = window.innerWidth > 1023;
                        if (nowDesktop !== isDesktop) {
                            location.reload();
                        } else {
                            init();
                        }
                    }, 300);
                });

                $scope.on('remove', reset);
            }
        );
    });
})(jQuery);