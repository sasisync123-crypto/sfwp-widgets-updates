(function ($) {
  $(window).on("elementor/frontend/init", function () {
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/sf-form.default",
      function ($scope) {
        elementorFrontend.hooks.doAction(
          "frontend/element_ready/form.default",
          $scope
        );
        elementorFrontend.hooks.doAction("frontend/element_ready/form", $scope);
      }
    );
  });
})(jQuery);
 