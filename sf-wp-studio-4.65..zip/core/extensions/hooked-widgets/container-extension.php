<?php

namespace SFWPStudio\Core\Extensions\HookedWidgets;

use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Container_Extension
{
    private static $instance = null;

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Inject our controls into the native Container panel.
        add_action(
            'elementor/element/container/section_layout/after_section_end',
            [$this, 'register_controls'],
            10,
            2
        );

        add_action(
            'elementor/element/container/section_layout_container/before_section_end',
            [$this, 'register_layout_controls'],
            10,
            2
        );

        add_action(
            'elementor/element/container/section_border/before_section_end',
            [$this, 'register_style_controls'],
            10,
            2
        );
    }

    public function register_layout_controls($element, $args)
    {

        $start = is_rtl() ? 'right' : 'left';
        $end = is_rtl() ? 'left' : 'right';

        $element->start_injection(
            array(
                'of' => 'min_height',
                'at' => 'after',
            )
        );

        $element->add_control(
            'sf-layout-switch',
            [
                'label' => esc_html__('Other Settings', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
                'separator' => 'before',
            ]
        );

        //Added For Width
        // Nested container width ratio type
        $element->add_control(
            'sync_con_width_ratio_type',
            [
                'label' => esc_html__('Layout Style', 'custom-container'),
                'type' => Controls_Manager::SELECT,
                'default' => 'single',
                'options' => [
                    'single' => esc_html__('Single', 'custom-container'),
                    'double' => esc_html__('Double', 'custom-container'),
                    'triple' => esc_html__('Triple', 'custom-container'),
                ],
                'selectors_dictionary' => [
                    'single' => '', // nothing to apply
                    'double' => '--flex-direction: row;',
                    'triple' => '--flex-direction: row;',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '{{VALUE}}',
                ],
                'condition' => [
                    // 'sync_orientation' => ['row', 'row-reverse'],
                    'sf-layout-switch' => 'yes'
                ],
                'render_type' => 'template',
            ]
        );

        $element->add_responsive_control(
            'sync_first_con_width',
            [
                'label' => esc_html__('First Container Width', 'custom-container'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'], // 👈 multiple units
                'default' => [
                    'size' => 50,
                    'unit' => '%',
                ],
                // 'range' => [
                //     '%' => [
                //         'min' => 10,
                //         'max' => 100,
                //     ],
                //     'px' => [
                //         'min' => 100,
                //         'max' => 1440,
                //     ],
                // ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-inner > .elementor-element:nth-last-child(2)' =>
                        'width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sync_con_width_ratio_type' => 'double',
                ],
            ]
        );


        // Second container width input (double layout)
        $element->add_responsive_control(
            'sync_second_con_width',
            [
                'label' => esc_html__('Second Container Width', 'custom-container'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'default' => [
                    'size' => 50,
                    'unit' => '%',
                ],
                // 'range' => [
                //     '%' => [ 'min' => 10, 'max' => 100 ],
                //     'px' => [ 'min' => 100, 'max' => 1440 ],
                // ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-inner > .elementor-element:nth-last-child(1)' =>
                        'width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sync_con_width_ratio_type' => 'double',
                    'sf-layout-switch' => 'yes',
                ],
            ]
        );

        // Triple layout: first container
        $element->add_responsive_control(
            'sync_third_first_con_width',
            [
                'label' => esc_html__('First Container Width', 'custom-container'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'default' => [
                    'size' => 33,
                    'unit' => '%',
                ],
                // 'range' => [
                //     '%' => [ 'min' => 10, 'max' => 100 ],
                //     'px' => [ 'min' => 100, 'max' => 1440 ],
                // ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-inner > .elementor-element:nth-last-child(3)' =>
                        'width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sync_con_width_ratio_type' => 'triple',
                    'sf-layout-switch' => 'yes',
                ],
            ]
        );

        // Triple layout: second container
        $element->add_responsive_control(
            'sync_third_second_con_width',
            [
                'label' => esc_html__('Second Container Width', 'custom-container'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'default' => [
                    'size' => 33,
                    'unit' => '%',
                ],
                // 'range' => [
                //     '%' => [ 'min' => 10, 'max' => 100 ],
                //     'px' => [ 'min' => 100, 'max' => 1440 ],
                // ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-inner > .elementor-element:nth-last-child(2)' =>
                        'width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sync_con_width_ratio_type' => 'triple',
                    'sf-layout-switch' => 'yes',
                ],
            ]
        );

        // Triple layout: third container
        $element->add_responsive_control(
            'sync_third_third_con_width',
            [
                'label' => esc_html__('Third Container Width', 'custom-container'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px',],
                'default' => [
                    'size' => 33,
                    'unit' => '%',
                ],
                // 'range' => [
                //     '%' => [ 'min' => 10, 'max' => 100 ],
                //     'px' => [ 'min' => 100, 'max' => 1440 ],
                // ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-inner > .elementor-element:nth-last-child(1)' =>
                        'width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sync_con_width_ratio_type' => 'triple',
                    'sf-layout-switch' => 'yes',
                ],
            ]
        );


        $element->add_responsive_control(
            'sync_con_gap',
            [
                'label' => esc_html__('Gap', 'custom-container'),
                'type' => \Elementor\Controls_Manager::GAPS,
                'size_units' => ['%', 'px',],
                'default' => [
                    'row' => 48,
                    'column' => 48,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}}' =>
                        '--gap: {{ROW}}{{UNIT}} {{COLUMN}}{{UNIT}};--row-gap: {{ROW}}{{UNIT}};--column-gap: {{COLUMN}}{{UNIT}};',
                ],
                'condition' => [
                    'sync_con_width_ratio_type' => ['triple', 'double'],
                    'sf-layout-switch' => 'yes',
                ],
            ]
        );


        $element->add_responsive_control(
            'sync_padding_mode',
            [
                'label' => esc_html__('Padding Style', 'sync-container-extras'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__('Default', 'sync-container-extras'),
                    'none' => esc_html__('No Padding', 'sync-container-extras'),
                    'inline' => esc_html__('Left & Right', 'sync-container-extras'),
                    'block' => esc_html__('Top & Bottom', 'sync-container-extras'),
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '{{VALUE}}',
                ],
                'selectors_dictionary' => [
                    'none' => '--padding-top: 0; --padding-right: 0; --padding-bottom: 0; --padding-left: 0;',
                    // 'none' => 'padding: 0;',
                ],
                'condition' => [
                    'sf-layout-switch' => 'yes',
                ],
            ]
        );

        // Inline padding (left/right only)
        $element->add_responsive_control(
            'sync_padding_inline',
            [
                'label' => esc_html__('Padding Value', 'custom-container'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}}' => '--padding-left: {{SIZE}}{{UNIT}}; --padding-right: {{SIZE}}{{UNIT}};--padding-top: 0; --padding-bottom: 0;',
                ],
                'condition' => [
                    'sf-layout-switch' => 'yes',
                    'sync_padding_mode' => 'inline',
                ],
            ]
        );

        // Block padding (top/bottom only)
        $element->add_responsive_control(
            'sync_padding_block',
            [
                'label' => esc_html__('Padding Value', 'custom-container'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}}' => '--padding-top: {{SIZE}}{{UNIT}}; --padding-bottom: {{SIZE}}{{UNIT}};--padding-right: 0; --padding-left: 0;',
                ],
                'condition' => [
                    'sf-layout-switch' => 'yes',
                    'sync_padding_mode' => 'block',
                ],
            ]
        );

        // All sides padding
        $element->add_responsive_control(
            'sync_padding_all',
            [
                'label' => esc_html__('Padding Value', 'custom-container'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}}' => '--padding-top: {{TOP}}{{UNIT}}; --padding-bottom: {{BOTTOM}}{{UNIT}}; --padding-left: {{LEFT}}{{UNIT}};--padding-right: {{RIGHT}}{{UNIT}};',
                ],
                'condition' => [
                    'sf-layout-switch' => 'yes',
                    'sync_padding_mode' => 'default',
                ],
            ]
        );

        $element->end_injection();
    }

    public function register_controls($element, $args)
    {

        $element->start_controls_section(
            'sync_container_extras',
            [
                'label' => esc_html__('Settings', 'sync-container-extras'),
                'tab' => Controls_Manager::TAB_LAYOUT,
            ]
        );



        $element->add_control(
            'sf_mode_toggle_',
            [
                'label' => esc_html__('Design Mode', 'my-plugin'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('On', 'my-plugin'),
                'label_off' => __('Off', 'my-plugin'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $element->add_control(
            'sf_design_style_type',
            [
                'label' => esc_html__('Sf Design Type', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'sf-widget'),
					'parent' => esc_html__('Parent', 'sf-widget'),
                    'style-1' => esc_html__('Style 1', 'sf-widget'),
                    'gradient' => esc_html__('Gradient', 'sf-widget'),
                ],
                'default' => 'none',
                'render_type' => 'template',
                'prefix_class' => 'sf-design-',
                'condition' => ['sf_mode_toggle_' => 'yes']// Adds class like custom-banner-bg-solidcolor
            ]
        );

        $element->add_control(
            'container-animation-on',
            [
                'label' => esc_html__('Container Animation', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'sf_mode_toggle_' => 'yes'
                ],
                'separator' => 'before',
            ]
        );

        $element->add_control(
            'container_animation',
            [
                'label'        => esc_html__('Animation', 'sf-widget'),
                'type'         => \Elementor\Controls_Manager::SELECT,
                'options'      => [
                    // Original Animations
                    'slide'     => esc_html__('Slide', 'sf-widget'),
                    'jump'      => esc_html__('Jump', 'sf-widget'),
                    'fall-off'  => esc_html__('Fall Off', 'sf-widget'),
                    'speed'     => esc_html__('Speed', 'sf-widget'),

                    // Fade Group
                    'fade-in'           => esc_html__('Fade In', 'sf-widget'),
                    'fade-in-up'        => esc_html__('Fade In Up', 'sf-widget'),
                    'fade-in-down'      => esc_html__('Fade In Down', 'sf-widget'),
                    'fade-in-left'      => esc_html__('Fade In Left', 'sf-widget'),
                    'fade-in-right'     => esc_html__('Fade In Right', 'sf-widget'),

                    // Slide Group
                    'slide-in'          => esc_html__('Slide In', 'sf-widget'),
                    'slide-in-up'       => esc_html__('Slide In Up', 'sf-widget'),
                    'slide-in-down'     => esc_html__('Slide In Down', 'sf-widget'),
                    'slide-in-left'     => esc_html__('Slide In Left', 'sf-widget'),
                    'slide-in-right'    => esc_html__('Slide In Right', 'sf-widget'),

                    // Zoom Group
                    'zoom-in'           => esc_html__('Zoom In', 'sf-widget'),
                    'zoom-in-up'        => esc_html__('Zoom In Up', 'sf-widget'),
                    'zoom-in-down'      => esc_html__('Zoom In Down', 'sf-widget'),
                    'zoom-in-left'      => esc_html__('Zoom In Left', 'sf-widget'),
                    'zoom-in-right'     => esc_html__('Zoom In Right', 'sf-widget'),

                    // Bounce Group
                    'bounce-in'         => esc_html__('Bounce In', 'sf-widget'),
                    'bounce-in-up'      => esc_html__('Bounce In Up', 'sf-widget'),
                    'bounce-in-down'    => esc_html__('Bounce In Down', 'sf-widget'),
                    'bounce-in-left'    => esc_html__('Bounce In Left', 'sf-widget'),
                    'bounce-in-right'   => esc_html__('Bounce In Right', 'sf-widget'),
                ],
                'default'      => 'slide',
                'prefix_class' => 'sf-animation-',
                'render_type'  => 'template',
                'condition'    => [
                    'container-animation-on' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'container_animation_options',
            [
                'label'        => esc_html__('Animation Duration', 'sf-widget'),
                'type'         => \Elementor\Controls_Manager::SELECT,
                'options'      => [
                    'slow'     => __('Slow', 'sf-widget'),
                    'default'      => __('Default', 'sf-widget'),
                    'fast'  => __('Fast', 'sf-widget'),
                ],
                'default'      => 'default',
                'prefix_class' => 'sf-animation-',
                'render_type'  => 'template',
                'condition'    => [
                    'container-animation-on' => 'yes',
                ]
            ]
        );

        $element->end_controls_section();
    }

    public function register_style_controls($element, $args)
    {

        $element->start_injection(
            array(
                'of' => 'border_radius',
                'at' => 'after',
            )
        );

        $element->add_responsive_control(
            'border_gradient_width',
            [
                'label' => esc_html__('Gradient Border Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '2',
                    'right' => '2',
                    'bottom' => '2',
                    'left' => '2',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-banner-border-gradient-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
            ]
        );

        // Border Radius
        $element->add_control(
            'border_gradient_radius',
            [
                'label' => esc_html__('Gradient Radius', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
            ]
        );

        $element->add_control(
            'border_gradient_direction',
            [
                'label' => esc_html__('Gradient Direction', 'my-elementor-extension'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'to top right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-grad-direction: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'border_gradient_color_one',
            [
                'label' => esc_html__('Gradient Border 1st Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-container-border-gradient-color-1: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'border_gradient_color_two',
            [
                'label' => esc_html__('Gradient Border 2nd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-container-border-gradient-color-2: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'border_gradient_color_three',
            [
                'label' => esc_html__('Gradient Border 3rd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-container-border-gradient-color-3: {{VALUE}};',
                ],
            ]
        );

        $element->end_injection();

        $element->start_injection(
            array(
                'of' => 'border_hover_transition',
                'at' => 'after',
            )
        );

        $element->add_responsive_control(
            'border_hover_gradient_width',
            [
                'label' => esc_html__('Gradient Border Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-hover-banner-border-gradient-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
            ]
        );

        // Border Radius
        $element->add_control(
            'border_hover_gradient_radius',
            [
                'label' => esc_html__('Gradient Radius', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-hover-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
            ]
        );

        $element->add_control(
            'border_hover_gradient_direction',
            [
                'label' => esc_html__('Gradient Direction', 'my-elementor-extension'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'to top right',
                'options' => [
                    'to left' => 'Left → Right',
                    'to right' => 'Right → Left',
                    'to top' => 'Bottom → Top',
                    'to bottom' => 'Top → Bottom',
                    'to top left' => 'Bottom-Right → Top-Left',
                    'to top right' => 'Bottom-Left → Top-Right',
                    'to bottom left' => 'Top-Right → Bottom-Left',
                    'to bottom right' => 'Top-Left → Bottom-Right',
                ],
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-hover-grad-direction: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'border_hover_gradient_color_one',
            [
                'label' => esc_html__('Gradient Border 1st Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-hover-container-border-gradient-color-1: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'border_hover_gradient_color_two',
            [
                'label' => esc_html__('Gradient Border 2nd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-hover-container-border-gradient-color-2: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'border_hover_gradient_color_three',
            [
                'label' => esc_html__('Gradient Border 3rd Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'condition' => [
                    'sf_mode_toggle_' => 'yes',
                    'sf_design_style_type' => 'style-1',
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--sfc-hover-container-border-gradient-color-3: {{VALUE}};',
                ],
            ]
        );

        $element->end_injection();
    }

}