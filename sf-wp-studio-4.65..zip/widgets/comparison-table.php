<?php
namespace SFWPStudio\Widgets;

if (!defined('ABSPATH'))
	exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

// Group Controls
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;

// Media & Icons
use Elementor\Icons_Manager;
use Elementor\Control_Media;

// Other Control Types
use Elementor\Control_Select2;
use Elementor\Control_Slider;
use Elementor\Control_Switcher;
use Elementor\Control_Heading;
use Elementor\Control_Textarea;
use Elementor\Control_Number;
use Elementor\Control_Dimensions;
use Elementor\Control_Color;
use Elementor\Control_Gallery;
use Elementor\Control_Date_Time;
use Elementor\Control_Code;

// Schemes
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;

// Utilities & Core
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Core\Base\Document;
use Elementor\Core\Responsive\Responsive;
use Elementor\Core\Kits\Documents\Kit;
use Elementor\Core\Settings\Manager;

class Comparison_Table extends Widget_Base
{

	public function get_name()
	{
		return 'sf-comparison-table';
	}

	public function get_title()
	{
		return __('SF Comparison Table', 'sf-widgets');
	}

	public function get_icon()
	{
		return 'sync-widget-icon eicon-tabs';
	}

	public function get_keywords()
	{
		return ['sf', 'comparison', 'table'];
	}

	//SFWP CODE STARTS
	public function get_categories()
	{
		return ['syncfusion-widgets'];
	}

	public function is_dynamic_content(): bool
	{
		return false;
	}
	//SFWP CODE ENDS

	protected function register_controls()
	{

		$this->start_controls_section(
			'ekit_cp_table_heading_content_section',
			[
				'label' => esc_html__('Table Heading', 'sf-widget'),
			]
		);
		$this->add_control(
			'ekit_cp_table_heading_show',
			[
				'label' => esc_html__('Show Table Heading', 'sf-widget'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'sf-widget'),
				'label_off' => esc_html__('Hide', 'sf-widget'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater_body = new Repeater();

		$repeater_body->add_control(
			'ekit_cp_heading_hide_on',
			[
				'label'   => __( 'Hide on', 'sf-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''        => __( 'Never', 'sf-widget' ),
					'mobile'  => __( 'Mobile', 'sf-widget' ),
					'tablet'  => __( 'Tablet', 'sf-widget' ),
					'desktop' => __( 'Desktop', 'sf-widget' ),
				],
			]
		);

		$repeater_body->add_responsive_control(
			'ekit_cp_table_heading_cell_width',
			[
				'label' => __('Cell Width', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'frontend_available' => true,
				'size_units' => ['%', 'px'],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'px' => [
						'min' => 0,
						'max' => 2000,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 50,
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_text',
			[
				'label' => esc_html__('Content', 'sf-widget'),
				'type' => Controls_Manager::WYSIWYG,
				'default' => esc_html__('Row', 'sf-widget'),
				'show_label' => false,
			]
		);

		// Description Switch
		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_description_show',
			[
				'label' => esc_html__('Show Description', 'sf-widget'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Yes', 'sf-widget'),
				'label_off' => esc_html__('No', 'sf-widget'),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_description',
			[
				'label' => esc_html__('Description', 'sf-widget'),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__('Enter description text', 'sf-widget'),
				'condition' => [
					'ekit_cp_table_heading_cell_description_show' => 'yes',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_url_show',
			[
				'label' => esc_html__('Add a url? ', 'sf-widget'),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__('Yes', 'sf-widget'),
				'label_off' => esc_html__('No', 'sf-widget'),
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_url',
			[
				'label' => esc_html__('URL', 'sf-widget'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_url('https://wpmet.com'),
				'condition' => [
					'ekit_cp_table_heading_cell_url_show' => 'yes'
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_icon_type',
			[
				'label' => esc_html__('Type', 'sf-widget'),
				'label_block' => false,
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'none' => [
						'title' => esc_html__('None', 'sf-widget'),
						'icon' => 'eicon-ban',
					],
					'icon' => [
						'title' => esc_html__('Icon', 'sf-widget'),
						'icon' => 'eicon-star',
					],
					'image' => [
						'title' => esc_html__('Image', 'sf-widget'),
						'icon' => 'eicon-image',
					],
				],
				'default' => 'none'
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_icons',
			[
				'label' => __('Icon', 'sf-widget'),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'body_cell_icon',
				'default' => [
					'value' => '',
				],
				'condition' => [
					'ekit_cp_table_heading_cell_icon_type' => 'icon',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_image',
			[
				'label' => esc_html__('Image', 'sf-widget'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
					'id' => -1
				],
				'condition' => [
					'ekit_cp_table_heading_cell_icon_type' => 'image',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_icon_color',   // <-- NEW
			[
				'label'     => __('Icon Color', 'sf-widget'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [   // will be overridden by PHP logic, but keeps the field in the UI
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell a:not(.sf-item-button), {{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell li' => 'color: {{VALUE}}',
				],
				'condition' => [
					'ekit_cp_table_heading_cell_icon_type' => 'icon',
				],
				'render_type' => 'template',
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_text_color',   // <--- NEW
			[
				'label'     => __( 'Text Color', 'sf-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} a:not(.sf-item-button),
					{{WRAPPER}} {{CURRENT_ITEM}} li' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} {{CURRENT_ITEM}} a:not(.sf-item-button) :is(i,svg),
					{{WRAPPER}} {{CURRENT_ITEM}} li :is(i,svg)' => 'color: {{VALUE}} !important; fill: {{VALUE}} !important;',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_cell_icon_position',
			[
				'label' => esc_html__('Position', 'sf-widget'),
				'type' => Controls_Manager::SELECT,
				'default' => 'before',
				'options' => [
					'before' => esc_html__('Before', 'sf-widget'),
					'after' => esc_html__('After', 'sf-widget'),
					'top' => esc_html__('Top', 'sf-widget'),
					'bottom' => esc_html__('Bottom', 'sf-widget'),
				],
			]
		);

		$repeater_body->add_responsive_control(
			'ekit_cp_table_heading_icon_spacing',
			[
				'label' => esc_html__('Icon/Text Spacing', 'elementskit'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors' => [
					// Before: icon then text
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.before a > i:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.before a > svg:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.before a > img:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.before li > i:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.before li > svg:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.before li > img:first-child' => 'margin-right: {{SIZE}}{{UNIT}};',

					// After: text then icon
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.after a > i:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.after a > svg:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.after a > img:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.after li > i:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.after li > svg:first-child,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.after li > img:first-child' => 'margin-left: {{SIZE}}{{UNIT}};',

					// Top/Bottom: block spacing
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.top a > i,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.top a > svg,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.top a > img,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.top li > i,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.top li > svg,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.top li > img' => 'margin-bottom: {{SIZE}}{{UNIT}}; display: block;',

					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom a > i,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom a > svg,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom a > img,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom li > i,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom li > i,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom li > svg,
					{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell.bottom li > img' => 'margin-top: {{SIZE}}{{UNIT}}; display: block;',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_heading_image_width',
			[
				'label' => esc_html__('Image Width', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 300,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell a > img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row {{CURRENT_ITEM}}.ekit-comparison-table-heading-cell li > img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_cp_table_heading_cell_icon_type' => 'image',
				],
			]
		);

		//Heading button start
			// Button Content Controls (inside repeater)
		$repeater_body->add_control(
			'show_button_sf_controls_head',
			[
				'label'        => esc_html__('Show Button', 'sf-widget'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__('Yes', 'sf-widget'),
				'label_off'    => esc_html__('No', 'sf-widget'),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

        $repeater_body->add_control(
            'ekit_icon_Icon_Width_Separator11_head', // Divider before button
            [
                'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_icon_box_button_heading_head', // Heading for button
            [
                'label' => esc_html__('Button', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );
        
        $repeater_body->add_control(
            'ekit_btn_text_head',
            [
                'label' => esc_html__('Label', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn more', 'sf-widget'),
                'placeholder' => esc_html__('Learn more', 'sf-widget'),
                'dynamic' => [
                    'active' => true,
                ],
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_url_head',
            [
                'label' => esc_html__('URL', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_url('https://wpmet.com'),
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => '#',
                ],
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_section_settings_head',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_icons__switch_head',
            [
                'label' => esc_html__('Add icon?', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_icons_head',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_btn_icon',
                'label_block' => true,
                'default' => [
                    'value' => '',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
					'show_button_sf_controls_head' => 'yes',
                ]
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_icon_align_head',
            [
                'label' => esc_html__('Icon Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => esc_html__('Before', 'sf-widget'),
                    'right' => esc_html__('After', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
					'show_button_sf_controls_head' => 'yes',
                ]
            ]
        );

        $repeater_body->add_control(
            'ekit_btn_class_head',
            [
                'label' => esc_html__('Class', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('Class Name', 'sf-widget'),
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );

        $repeater_body->add_control(
            'ekit_btn_id_head',
            [
                'label' => esc_html__('ID', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('ID', 'sf-widget'),
				'condition' => [
					'show_button_sf_controls_head' => 'yes',
				],
            ]
        );

		do_action('sf_comparision_button_variant_options',$repeater_body);
		//Heading button end

		$repeater_body->add_control(
			'ekit_cp_table_heading_align',
			[
				'label' => esc_html__('Alignment', 'sf-widget'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__('Left', 'sf-widget'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'sf-widget'),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => esc_html__('Right', 'sf-widget'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} a, {{WRAPPER}} {{CURRENT_ITEM}} li' => 'align-items: {{VALUE}}; justify-content: flex-{{VALUE}}; justify-content: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbody-head' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .ekit-comparison-heading-description' => 'display: flex; justify-content: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .sf-item-button-wraper' => 'justify-content: {{VALUE}};',  // NEW: Target button wrapper for alignment
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_heading_content',
			[
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'ekit_cp_table_heading_element' => 'cell',
						'ekit_cp_table_heading_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_heading_element' => 'cell',
						'ekit_cp_table_heading_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_heading_element' => 'cell',
						'ekit_cp_table_heading_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_heading_element' => 'cell',
						'ekit_cp_table_heading_cell_text' => esc_html__('Column', 'sf-widget'),
					],
				],
				'fields' => $repeater_body->get_controls(),
				'title_field' => ' {{{ ekit_cp_table_heading_cell_text }}}',
			]
		);

		$this->end_controls_section();

		// table body cell 
		$this->start_controls_section(
			'ekit_cp_table_content_section',
			[
				'label' => esc_html__('Table Body', 'sf-widget'),
			]
		);

		$repeater_body = new Repeater();

		$repeater_body->add_control(
			'ekit_cp_table_row',
			[
				'label' => esc_html__('New Row', 'sf-widget'),
				'type' => Controls_Manager::SWITCHER,
				'label_off' => esc_html__('No', 'sf-widget'),
				'label_on' => esc_html__('Yes', 'sf-widget'),
				'return_value' => esc_html__('Row', 'sf-widget'),
			]
		);

		$repeater_body->add_control(
			'ekit_cp_body_hide_on',
			[
				'label'   => __( 'Hide on', 'sf-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''        => __( 'Never', 'sf-widget' ),
					'mobile'  => __( 'Mobile', 'sf-widget' ),
					'tablet'  => __( 'Tablet', 'sf-widget' ),
					'desktop' => __( 'Desktop', 'sf-widget' ),
				],
			]
		);
		
		$repeater_body->add_responsive_control(
			'ekit_cp_table_column_width',
			[
				'label' => __('Column Width', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'frontend_available' => true,
				'size_units' => ['%', 'px'],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'px' => [
						'min' => 0,
						'max' => 2000,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 100,
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_cell_text',
			[
				'label' => esc_html__('Content', 'sf-widget'),
				'type' => Controls_Manager::WYSIWYG,
				'default' => esc_html__('Column', 'sf-widget'),
				'show_label' => false,
			]
		);

		// Body Cell Description
		$repeater_body->add_control(
			'ekit_cp_table_body_cell_description_show',
			[
				'label' => esc_html__('Show Description', 'sf-widget'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Yes', 'sf-widget'),
				'label_off' => esc_html__('No', 'sf-widget'),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_description',
			[
				'label' => esc_html__('Description', 'sf-widget'),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__('Enter description text', 'sf-widget'),
				'condition' => [
					'ekit_cp_table_body_cell_description_show' => 'yes',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_url_show',
			[
				'label' => esc_html__('Add a url? ', 'sf-widget'),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => esc_html__('Yes', 'sf-widget'),
				'label_off' => esc_html__('No', 'sf-widget'),
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_url',
			[
				'label' => esc_html__('URL', 'sf-widget'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_url('https://wpmet.com'),
				'condition' => [
					'ekit_cp_table_body_cell_url_show' => 'yes'
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_icon_type',
			[
				'label' => esc_html__('Type', 'sf-widget'),
				'label_block' => false,
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'none' => [
						'title' => esc_html__('None', 'sf-widget'),
						'icon' => 'eicon-ban',
					],
					'icon' => [
						'title' => esc_html__('Icon', 'sf-widget'),
						'icon' => 'eicon-star',
					],
					'image' => [
						'title' => esc_html__('Image', 'sf-widget'),
						'icon' => 'eicon-image',
					],
				],
				'default' => 'none',
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_icons',
			[
				'label' => __('Icon', 'sf-widget'),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'body_cell_icon',
				'default' => [
					'value' => '',
				],
				'condition' => [
					'ekit_cp_table_body_cell_icon_type' => 'icon',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_icon_image',
			[
				'label' => esc_html__('Image', 'sf-widget'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
					'id' => -1
				],
				'condition' => [
					'ekit_cp_table_body_cell_icon_type' => 'image',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_icon_color',      // <-- NEW
			[
				'label'     => __('Icon Color', 'sf-widget'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a:not(.sf-item-button)' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell li' => 'color: {{VALUE}}',
				],
				'condition' => [
					'ekit_cp_table_body_cell_icon_type' => 'icon',
				],
				'render_type' => 'template',
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_cell_icon_position',
			[
				'label' => esc_html__('Icon Position', 'sf-widget'),
				'type' => Controls_Manager::SELECT,
				'default' => 'before',
				'options' => [
					'before' => esc_html__('Before', 'sf-widget'),
					'after' => esc_html__('After', 'sf-widget'),
					'top' => esc_html__('Top', 'sf-widget'),
					'bottom' => esc_html__('Bottom', 'sf-widget'),
				],
			]
		);

		$repeater_body->add_responsive_control(
			'ekit_cp_table_body_icon_spacing',
			[
				'label' => esc_html__('Icon/Text Spacing', 'elementskit'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors' => [
					// Before
					'{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.before a > i:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.before a > svg:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.before a > img:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.before li > i:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.before li > svg:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.before li > img:first-child' => 'margin-right: {{SIZE}}{{UNIT}};',

					// After
					'{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.after a > i:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.after a > svg:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.after a > img:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.after li > i:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.after li > svg:first-child,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.after li > img:first-child' => 'margin-left: {{SIZE}}{{UNIT}};',

					// Top
					'{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.top a > i,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.top a > svg,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.top a > img,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.top li > i,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.top li > svg,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.top li > img' => 'margin-bottom: {{SIZE}}{{UNIT}}; display: block;',

					// Bottom
					'{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.bottom a > i,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.bottom a > svg,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.bottom a > img,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.bottom li > i,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.bottom li > svg,
					{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell.bottom li > img' => 'margin-top: {{SIZE}}{{UNIT}}; display: block;',
				],
			]
		);

		$repeater_body->add_control(
			'ekit_cp_table_body_image_width',
			[
				'label' => esc_html__('Image Width', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 300,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell a > img' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} {{CURRENT_ITEM}}.ekit-comparison-table-cell li > img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_cp_table_body_cell_icon_type' => 'image',
				],
			]
		);

		//body button start
		// Button Content Controls (inside repeater)
        $repeater_body->add_control(
            'ekit_icon_Icon_Width_Separator11', // Divider before button
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
		$repeater_body->add_control(
            'show_button_sf_controls',
            [
                'label' => esc_html__('Show Button', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $repeater_body->add_control(
            'ekit_icon_box_button_heading', // Heading for button
            [
                'label' => esc_html__('Button', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );
        
        $repeater_body->add_control(
            'ekit_btn_text',
            [
                'label' => esc_html__('Label', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn more', 'sf-widget'),
                'placeholder' => esc_html__('Learn more', 'sf-widget'),
                'dynamic' => [
                    'active' => true,
                ],
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_url',
            [
                'label' => esc_html__('URL', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_url('https://wpmet.com'),
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => '#',
                ],
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_section_settings',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_icons__switch',
            [
                'label' => esc_html__('Add icon?', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_icons',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_btn_icon',
                'label_block' => true,
                'default' => [
                    'value' => '',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
					'show_button_sf_controls' => 'yes',
                ]
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_icon_align',
            [
                'label' => esc_html__('Icon Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => esc_html__('Before', 'sf-widget'),
                    'right' => esc_html__('After', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
					'show_button_sf_controls' => 'yes',
                ]
            ]
        );
        
        $repeater_body->add_control(
            'ekit_btn_class',
            [
                'label' => esc_html__('Class', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('Class Name', 'sf-widget'),
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );
        $repeater_body->add_control(
            'ekit_btn_id',
            [
                'label' => esc_html__('ID', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('ID', 'sf-widget'),
				'condition' => [
					'show_button_sf_controls' => 'yes',
				],
            ]
        );

		do_action('sf_comparision_button_variant_options_body',$repeater_body);
		//body button end

		$repeater_body->add_control(
			'ekit_cp_table_cell_btn_align',
			[
				'label' => esc_html__('Alignment', 'sf-widget'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__('Left', 'sf-widget'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'sf-widget'),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => esc_html__('Right', 'sf-widget'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} a, {{WRAPPER}} {{CURRENT_ITEM}} li' => 'align-items: {{VALUE}}; text-align: {{VALUE}}; justify-content: flex-{{VALUE}}; justify-content: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .ekit-comparison-body-description' => 'display: flex; justify-content: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbody-button' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .sf-item-button-wraper' => 'justify-content: {{VALUE}};',  // NEW: Target button wrapper for alignment
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_body_content',
			[
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'ekit_cp_table_body_element' => 'cell',
						'cell_text' => esc_html__('Row', 'sf-widget'),
						'ekit_cp_table_row' => 'Row',
					],
					[
						'ekit_cp_table_body_element' => 'cell',
						'ekit_cp_table_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_body_element' => 'cell',
						'ekit_cp_table_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_body_element' => 'cell',
						'ekit_cp_table_cell_text' => esc_html__('Column', 'sf-widget'),
					],

					[
						'ekit_cp_table_body_element' => 'cell',
						'cell_text' => esc_html__('Row', 'sf-widget'),
						'ekit_cp_table_row' => 'Row',
					],
					[
						'ekit_cp_table_body_element' => 'cell',
						'ekit_cp_table_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_body_element' => 'cell',
						'ekit_cp_table_cell_text' => esc_html__('Column', 'sf-widget'),
					],
					[
						'ekit_cp_table_body_element' => 'cell',
						'ekit_cp_table_cell_text' => esc_html__('Column', 'sf-widget'),
					],
				],
				'fields' => $repeater_body->get_controls(),
				'title_field' => '{{{ ekit_cp_table_row }}}: {{{ ekit_cp_table_cell_text }}}',
			]
		);

		$this->end_controls_section();

		// table button repeater section
		$this->start_controls_section(
			'ekit_cp_table_button_section',
			[
				'label' => esc_html__('Table Button', 'sf-widget'),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'ekit_cp_table_btn_title',
			[
				'label' => esc_html__('Title', 'sf-widget'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Buy Now', 'sf-widget'),
				'placeholder' => esc_html__('Comparison Table', 'sf-widget'),
			]
		);

		$repeater->add_control(
			'ekit_cp_table_btn_link',
			[
				'label' => esc_html__('Link', 'sf-widget'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https:wpmet.com', 'sf-widget'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_button_list',
			[
				'label' => esc_html__('Buttons', 'sf-widget'),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [],
				'title_field' => '{{{ ekit_cp_table_btn_title }}}',
				'prevent_empty' => false,
			]
		);

		$this->end_controls_section();

		//Table Compare Section
		$this->start_controls_section(
			'ekit_cp_table_compare_button_section',
			[
				'label' => esc_html__('Compare Button', 'sf-widget'),
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_button_switch',
			[
				'label' => esc_html__('Button Style', 'sf-widget'),
				'type' => Controls_Manager::SELECT,
				'default' => 'inline',
				'options' => [
					'inline' => esc_html__('Inline Style', 'sf-widget'),
					'tab' => esc_html__('Tab Style', 'sf-widget'),
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_full_button_text',
			[
				'label' => esc_html__('Full Button', 'sf-widget'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Full', 'sf-widget'),
				'placeholder' => esc_html__('Type your title here', 'sf-widget'),
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_button_text',
			[
				'label' => esc_html__('Difference Button', 'sf-widget'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('', 'sf-widget'),
				'placeholder' => esc_html__('Type your title here', 'sf-widget'),
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_button_position',
			[
				'label' => esc_html__('Position', 'sf-widget'),
				'type' => Controls_Manager::SELECT,
				'default' => 'bottom',
				'options' => [
					'top' => esc_html__('Top', 'sf-widget'),
					'bottom' => esc_html__('Bottom', 'sf-widget'),
				],
				'condition' => [
					'ekit_cp_table_compare_button_text!' => '',
					'ekit_cp_table_compare_full_button_text!' => '',
				],
			]
		);

		$this->end_controls_section();

		//Table wrapper Style Section
		$this->start_controls_section(
			'ekit_cp_table_wrapper_style',
			[
				'label' => esc_html__('Wrapper', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_height',
			[
				'label' => esc_html__('Max Height', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'em', 'rem', 'vh'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'em' => [
						'min' => 0,
						'max' => 100,
					],
					'rem' => [
						'min' => 0,
						'max' => 100,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-wrapper' => 'max-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'ekit_cp_table_wrapper_tabs'
		);

		$this->start_controls_tab(
			'ekit_cp_table_wrapper_normal_tab',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_wrapper_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-comparison-table-content',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_wrapper_shadow',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-content',

			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_wrapper_border',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-content',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_wrapper_hv_tab',
			[
				'label' => esc_html__('Hover', 'sf-widget'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_wrapper_hv_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-comparison-table-content:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_wrapper_hv_shadow',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-content:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_wrapper_hv_border',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-content:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'ekit_cp_table_wrapper_border_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_wrapper_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_wrapper_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		//Table wrapper Style Section
		$this->start_controls_section(
			'ekit_cp_table_content_style',
			[
				'label' => esc_html__('Table Content', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ekit_cp_first_column_width',
			[
				'label' => esc_html__('First Column Width', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					// Width + min-width for every first cell in a row
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-row > *:nth-child(1)' =>
						'width: {{SIZE}}{{UNIT}} !important; min-width: {{SIZE}}{{UNIT}} !important;',

					// Force table to respect the defined column widths
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table' =>
						'table-layout: fixed; width: 100%;',
				],
			]
		);
		
		$this->add_control(
			'ekit_cp_first_column_text_color',
			[
				'label'     => esc_html__('First Column Color', 'sf-widget'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',               // red – matches your CSS example
				'selectors' => [
                    // Heading – first cell
                    '{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li p,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li h1,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li h2,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li h3,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li h4,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li h5,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li h6,
                    {{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell:first-child li' => 'color: {{VALUE}};',
                   
                    // Body – every first cell of every row
                    '{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li p,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li h1,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li h2,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li h3,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li h4,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li h5,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li h6,
                    {{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell:first-child li' => 'color: {{VALUE}};',
                ],
			]
		);

		$this->start_controls_tabs(
			'ekit_cp_table_content_tabs'
		);

		$this->start_controls_tab(
			'ekit_cp_table_content_normal_tab',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_content_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-comparison-table-wrapper',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_content_shadow',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-wrapper',

			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_content_border',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-wrapper',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_content_hv_tab',
			[
				'label' => esc_html__('Hover', 'sf-widget'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_content_hv_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-comparison-table-wrapper:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_content_hv_shadow',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-wrapper:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_content_hv_border',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-wrapper:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'ekit_cp_table_content_border_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_content_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_content_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Description Style Section
		$this->start_controls_section(
			'ekit_cp_table_description_style',
			[
				'label' => esc_html__('Description Text', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// Heading Description
		$this->add_control(
			'ekit_cp_table_heading_description_heading',
			[
				'label' => esc_html__('Heading Cell Description', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_heading_description_typography',
				'selector' => '{{WRAPPER}} .ekit-comparison-heading-description',
			]
		);

		$this->add_control(
			'ekit_cp_table_heading_description_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-heading-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_description_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-heading-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_description_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-heading-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Body Description
		$this->add_control(
			'ekit_cp_table_body_description_heading',
			[
				'label' => esc_html__('Body Cell Description', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_body_description_typography',
				'selector' => '{{WRAPPER}} .ekit-comparison-body-description',
			]
		);

		$this->add_control(
			'ekit_cp_table_body_description_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-body-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_description_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-body-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_description_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-body-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		//Table Heading Style Section
		$this->start_controls_section(
			'ekit_cp_table_heading_style',
			[
				'label' => esc_html__('Table Heading', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ekit_cp_table_heading_text_size',
			[
				'label'       => esc_html__('Text Gap', 'sf-widget'),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => ['px'],
				'separator'   => 'after',
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'     => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors'   => [
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li h1' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li h5' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading .ekit-comparison-table-heading-cell li h6' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'ekit_cp_table_heading_icon',
			[
				'label' => esc_html__('Icon', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'ekit_cp_table_heading_icon_size',
			[
				'label' => esc_html__('Font Size', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'separator' => 'after',
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-heading-cell a > :is( i, svg )' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading-cell li :is( i, svg )' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_image_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-heading-cell a > img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_icon_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px'],
				'separator' => 'before',
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-heading-cell a > :is( i, svg )' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading-cell a > img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading-cell li > :is( i, svg )' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-heading-cell li > img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_heading_typography',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell a, {{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell li',
			]
		);

		$this->start_controls_tabs(
			'ekit_cp_table_heading_tabs'
		);

		$this->start_controls_tab(
			'ekit_cp_table_heading_normal_tab',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
			]
		);

		$this->add_control(
			'ekit_cp_table_heading_color',
			[
				'label' => esc_html__('Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					// Apply to <a> and <li> in heading cell, BUT NOT the button
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell a:not(.sf-item-button), {{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell li' => 'color: {{VALUE}}',

					// Icons inside non-button links and list items
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell a:not(.sf-item-button) :is(i, svg), {{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell li :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_heading_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-wrapper .ekit-comparison-table-heading',
				'default' => '',
				'exclude' => ['image'],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_heading_border',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_heading_hv_tab',
			[
				'label' => esc_html__('hover', 'sf-widget'),
			]
		);

		$this->add_control(
			'ekit_cp_table_heading_hv_color',
			[
				'label' => esc_html__('Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell:hover a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell:hover li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell a:hover :is( i, svg ), {{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell li:hover :is( i, svg )' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_heading_hv_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell:hover',
				'exclude' => ['image']
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_heading_hv_border',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'ekit_cp_table_heading_cell_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
					'unit' => '',
				],
				'isLinked' => false,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_cell_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading-cell' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_style_heading',
			[
				'label' => esc_html__('Table Heading Wrapper', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_heading_shadow',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_headin_border',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading',
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_border_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'isLinked' => false,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_heading_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		//Table Body  Style Section
		$this->start_controls_section(
			'ekit_cp_table_body_style',
			[
				'label' => esc_html__('Table Body', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'ekit_cp_table_body_text_size',
			[
				'label'       => esc_html__('Text Gap', 'sf-widget'),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => ['px'],
				'separator'   => 'after',
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'     => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors'   => [
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li h1' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li h5' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-body .ekit-comparison-row .ekit-comparison-table-cell li h6' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_body_icon',
			[
				'label' => esc_html__('Icon', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'ekit_cp_table_body_icon_size',
			[
				'label' => esc_html__('Font Size', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'separator' => 'after',
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-cell li :is( i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ekit-comparison-table-cell a :is( i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_icon_size_image_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-cell a > img, .ekit-comparison-table-cell li > img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_icon_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a > :is( i, svg), .ekit-comparison-table-cell li > :is( i, svg)' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a > img, .ekit-wid-con .ekit-comparison-table-cell li > img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_body_typography',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a, {{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell li',
				'separator' => 'after',
			]
		);

		$this->start_controls_tabs(
			'ekit_cp_table_body_tabs'
		);

		$this->start_controls_tab(
			'ekit_cp_table_body_normal_tab',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
			]
		);

		$this->add_control(
			'ekit_cp_table_body_color',
			[
				'label' => esc_html__('Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					// Apply to <a> and <li> inside cell, BUT NOT the button
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a:not(.sf-item-button)' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell li' => 'color: {{VALUE}}',

					// Icons inside non-button links and list items
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell li :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a:not(.sf-item-button) :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_body_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row',
				'exclude' => ['image']
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_body_box_shadow',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row',
			]
		);

		$this->add_control(
            'ekit_cp_table_odd_bg_heading',
            [
                'label' => esc_html__('Alternative Row Background', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
 
        $this->add_control(
            'ekit_cp_table_odd_pattern',
            [
                'label'   => esc_html__( 'Odd Row Pattern', 'your-textdomain' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'Alternative',                   
                'options' => [
                    'odd'    => esc_html__( 'Odd row', 'your-textdomain' ),
                    'Alternative'   => esc_html__( 'Alternative row', 'your-textdomain' ),
                ],
            ]
        );
 
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_cp_table_odd_bg',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row:nth-child(odd) .ekit-comparison-table-cell',
                'exclude' => ['image'],
                'condition'=> [ 'ekit_cp_table_odd_pattern' => 'odd' ],
            ]
        );
 
		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_cp_table_odd_bg2',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row:nth-child(3n+2)',
                'exclude' => ['image'],
                'condition'=> [ 'ekit_cp_table_odd_pattern' => 'Alternative' ],
            ]
        );

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_body_border',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell',
				'separator' => 'before',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_body_hv_tab',
			[
				'label' => esc_html__('hover', 'sf-widget'),
			]
		);

		$this->add_control(
			'ekit_cp_table_body_hv_color',
			[
				'label' => esc_html__('Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell:hover a, .ekit-wid-con .ekit-comparison-table-cell:hover li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell li:hover :is( i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell a:hover :is( i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_body_hv_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row:hover',
				'exclude' => ['image']
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_body_hv_box_shadow',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row:hover',
			]
		);

		$this->add_control(
			'ekit_cp_table_odd_bg_hv_heading',
			[
				'label' => esc_html__('Odd Row Background', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ekit_cp_table_odd_hv_bg',
				'types' => ['classic', 'gradient',],
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row:nth-child(odd):hover',
				'exclude' => ['image'],
				'default' => '',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_body_hv_border',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell:hover',
				'separator' => 'before',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'ekit_cp_table_body_last_cell_border',
			[
				'label' => esc_html__('Last Cell Border', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => ['px'],
				'isLinked' => false,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell:last-child' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
					'unit' => 'px',
				],
				'isLinked' => false,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-cell' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_style_body_row',
			[
				'label' => esc_html__('Table Body Row', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_body_row_shadow',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row',
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_row_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_row_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'isLinked' => false,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_body_row_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-body .ekit-comparison-row' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		
		//Table Button Style Section
		$this->start_controls_section(
			'ekit_cp_table_button_style',
			[
				'label' => esc_html__('Table Button', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_button_typography',
				'label' => esc_html__('Typography', 'sf-widget'),
				'selector' => '{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button',
			]
		);

		$this->start_controls_tabs('ekit_cp_table_button_tabs_style');

		$this->start_controls_tab(
			'ekit_cp_table_button_tab_normal',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_button_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_button_bg_color',
			[
				'label' => esc_html__('Background Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_button_shadow',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_button_border',
				'label' => esc_html__('Border', 'sf-widget'),
				'selector' => '{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_button_hover',
			[
				'label' => esc_html__('Hover', 'sf-widget'),
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_button_h_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_button_h_bg_color',
			[
				'label' => esc_html__('Background Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_button_h_shadow',
				'selector' => '{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_button_h_border',
				'label' => esc_html__('Border', 'sf-widget'),
				'selector' => '{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'ekit_cp_table_button_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => ['px', '%'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_button_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '',
					'left' => '',
					'unit' => 'px',
				],
				'isLinked' => false,
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_button_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-comparison-table-button .ekit-cp-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_button_align',
			[
				'label' => esc_html__('Alignment', 'sf-widget'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__('Left', 'sf-widget'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'sf-widget'),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => esc_html__('Right', 'sf-widget'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-comparison-table-button' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',
			]
		);

		$this->end_controls_section();

		//Compare Button Style Section
		$this->start_controls_section(
			'ekit_cp_table_compare_button',
			[
				'label' => esc_html__('Compare Button', 'sf-widget'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ekit_cp_table_compare_button_text!' => '',
					'ekit_cp_table_compare_full_button_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_compare_button_typography',
				'label' => esc_html__('Typography', 'sf-widget'),
				'selector' => '{{WRAPPER}} .compare-button-wrap .compare-button, {{WRAPPER}} .ekit-wid-con .ekit-diff-on',
			]
		);

		$this->start_controls_tabs('ekit_cp_table_compare_button_tabs_style');

		$this->start_controls_tab(
			'ekit_cp_table_compare_button_tab_normal',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap .compare-button' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-on' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_bg_color',
			[
				'label' => esc_html__('Background Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap .compare-button' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-on' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_compare_button_shadow',
				'selector' => '{{WRAPPER}} .compare-button-wrap .compare-button, {{WRAPPER}} .ekit-wid-con .ekit-diff-on',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_compare_button_border',
				'label' => esc_html__('Border', 'sf-widget'),
				'selector' => '{{WRAPPER}} .compare-button-wrap .compare-button, {{WRAPPER}} .ekit-wid-con .ekit-diff-on',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_compare_button_hover',
			[
				'label' => esc_html__('Hover', 'sf-widget'),
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_h_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap .compare-button:hover, {{WRAPPER}} .ekit-wid-con .ekit-diff-on:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_h_bg_color',
			[
				'label' => esc_html__('Background Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap .compare-button:hover, {{WRAPPER}} .ekit-wid-con .ekit-diff-on:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_compare_button_h_shadow',
				'selector' => '{{WRAPPER}} .compare-button-wrap .compare-button:hover, {{WRAPPER}} .ekit-wid-con .ekit-diff-on:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_compare_button_h_border',
				'label' => esc_html__('Border', 'sf-widget'),
				'selector' => '{{WRAPPER}} .compare-button-wrap .compare-button:hover, {{WRAPPER}} .ekit-wid-con .ekit-diff-on:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_border_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap .compare-button, {{WRAPPER}} .ekit-wid-con .ekit-diff-on' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_button_heading',
			[
				'label' => esc_html__('Full Compaire Button', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_cfull_button_typography',
				'label' => esc_html__('Typography', 'sf-widget'),
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-diff-off',
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->start_controls_tabs('ekit_cp_table_cfull_button_tabs_style');

		$this->start_controls_tab(
			'ekit_cp_table_cfull_button_tab_normal',
			[
				'label' => esc_html__('Normal', 'sf-widget'),
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_cfull_button_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_cfull_button_bg_color',
			[
				'label' => esc_html__('Background Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_cfull_button_shadow',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-diff-off',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_cfull_button_border',
				'label' => esc_html__('Border', 'sf-widget'),
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-diff-off',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'ekit_cp_table_cfull_button_hover',
			[
				'label' => esc_html__('Hover', 'sf-widget'),
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_cfull_button_h_color',
			[
				'label' => esc_html__('Text Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_cfull_button_h_bg_color',
			[
				'label' => esc_html__('Background Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ekit_cp_table_cfull_button_h_shadow',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-diff-off:hover',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'ekit_cp_table_cfull_button_h_border',
				'label' => esc_html__('Border', 'sf-widget'),
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-diff-off:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'ekit_cp_table_cfull_button_border_radius',
			[
				'label' => esc_html__('Border Radius', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_padding',
			[
				'label' => esc_html__('Padding', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => ['px'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap .compare-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-on' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_button_margin',
			[
				'label' => esc_html__('Margin', 'sf-widget'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px'],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .compare-button-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_toggle_style',
			[
				'label' => esc_html__('Compare Toggle Button', 'sf-widget'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ekit_cp_table_compare_toggle_typography',
				'selector' => '{{WRAPPER}} .ekit-wid-con .ekit-diff-off::after',
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_toggle_color',
			[
				'label' => esc_html__('Color', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off::after' => 'color: {{VALUE}}',
				],
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_toggle_bg',
			[
				'label' => esc_html__('Background', 'sf-widget'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off::after' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_toggle_width',
			[
				'label' => esc_html__('Width', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off::after' => 'width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_toggle_transformx',
			[
				'label' => esc_html__('Transform ( X )', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => -200,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => -5,
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off::after' => 'transform: translateX({{SIZE}}{{UNIT}}) ;',
				],
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_responsive_control(
			'ekit_cp_table_compare_toggle_transformy',
			[
				'label' => esc_html__('Transform ( Y )', 'sf-widget'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => -200,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 86,
				],
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .ekit-diff-off::after' => 'top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ekit_cp_table_compare_button_switch' => 'tab',
				],
			]
		);

		$this->add_control(
			'ekit_cp_table_compare_button_align',
			[
				'label' => esc_html__('Alignment', 'sf-widget'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'sf-widget'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'sf-widget'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', 'sf-widget'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .ekit-wid-con .compare-button-wrap' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		// New/Updated Button Style Section (Main Style Tab)
        $this->start_controls_section(
            'sf_item_button_style', // New section name to avoid conflict
            [
                'label' => esc_html__('Button', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                // No condition—shows if widget has buttons; user can style globally
            ]
        );

        // Size (global, applies to all)
        $this->add_control(
            '_button_size',
            [
                'label' => esc_html__('Button Size', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'sm',
                'options' => [
                    'sm' => esc_html__('Small', 'sf-widget'),
                    'md' => esc_html__('Medium', 'sf-widget'),
                    'lg' => esc_html__('Lg', 'sf-widget'),
                    'xl' => esc_html__('Xl', 'sf-widget'),
                ],
                'selectors_dictionary' => [
                    'sm' => 'font-size: 12px; padding: 8px 16px;',
                    'md' => 'font-size: 14px; padding: 12px 24px;',
                    'lg' => 'font-size: 16px; padding: 16px 32px;',
                    'xl' => 'font-size: 18px; padding: 20px 40px;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => '{{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'width',
            [
                'label' => esc_html__('Width (%)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'width: {{SIZE}}%;',
                ]
            ]
        );

        // Padding (responsive, global)
        $this->add_responsive_control(
            '_ekit_btn_text_padding_1',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Typography, Shadow (global)
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_btn_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .sf-item-button',
            ]
        );
        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'ekit_btn_shadow',
                'selector' => '{{WRAPPER}} .sf-item-button',
            ]
        );

        // Background Tabs (for Default/Flat/Outline/Stacked)
        $this->start_controls_tabs('sf_button_bg_tabs');
        $this->start_controls_tab('sf_button_normal_tab', ['label' => esc_html__('Normal', 'sf-widget')]);
        $this->add_control(
            'ekit_btn_text_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Stacked'], // Per-item, but style global
                    'ekit_icon_box_button_style__body' => ['Stacked'], // Per-item, but style global
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_normal',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .sf-item-button',
                'fields_options' => [
                    'gradient_type' => ['default' => 'linear'],
                    'gradient_angle' => ['default' => ['unit' => 'deg', 'size' => 250]],
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Default', 'Flat'],
                    'ekit_icon_box_button_style__body' => ['Default', 'Flat'],
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab('sf_button_hover_tab', ['label' => esc_html__('Hover', 'sf-widget')]);
        $this->add_control(
            'ekit_btn_hover_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_hover',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .sf-item-button:hover',
                'fields_options' => [
                    'gradient_type' => ['default' => 'linear'],
                    'gradient_angle' => ['default' => ['unit' => 'deg', 'size' => 90]],
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Border (for Flat/Outline)
        $this->add_control(
            'ekit_btn_border_style_tabs',
            [
                'label' => esc_html__('Border', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                    'ekit_icon_box_button_style__body' => ['Flat', 'Outline'],
                ],
            ]
        );
        $this->add_responsive_control(
            'ekit_btn_border_style2',
            [
                'label' => esc_html_x('Border Type', 'Border Control', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'sf-widget'),
                    'solid' => esc_html_x('Solid', 'Border Control', 'sf-widget'),
                    // ... (add other options as in provided code)
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                    'ekit_icon_box_button_style__body' => ['Flat', 'Outline'],
                ],
            ]
        );
        // Add other border controls (width, color, radius, hover) similarly...
        $this->add_responsive_control(
            'ekit_btn_border_radius_normal',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                    'ekit_icon_box_button_style__body' => ['Flat', 'Outline'],
                ],
            ]
        );

        // Shadow
        $this->add_control(
            'ekit_btn_box_shadow_style',
            [
                'label' => esc_html__('Shadow', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_btn_box_shadow_group',
                'selector' => '{{WRAPPER}} .sf-item-button',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_btn_hover_box_shadow_group',
                'label' => esc_html__('Hover Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .sf-item-button:hover',
            ]
        );

        // Icon Styles (global, for all buttons)
        $this->add_control(
            'ekit_btn_iconw_style',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );
        $this->add_responsive_control(
            'ekit_btn_normal_icon_font_size',
            [
                'label' => esc_html__('Font Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button > :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_btn_normal_icon_padding_left',
            [
                'label' => esc_html__('Add space after icon', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '.rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, .rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: 0;',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
                    'ekit_btn_icon_align' => 'left',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_btn_normal_icon_padding_right',
            [
                'label' => esc_html__('Add space before icon', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '.rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, .rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-left: 0; margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
                    'ekit_btn_icon_align' => 'right',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_btn_normal_icon_vertical_align',
            [
                'label' => esc_html__('Move icon Vertically', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => -20,
                        'max' => 20,
                    ],
                    'em' => [
                        'min' => -5,
                        'max' => 5,
                    ],
                    'rem' => [
                        'min' => -5,
                        'max' => 5,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn i, {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn svg' => '-webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}})',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();
	}

	protected function render()
	{
		echo '<div class="ekit-wid-con" >';
		$this->render_raw();
		echo '</div>';
	}

	protected function render_raw()
	{
		$settings = $this->get_settings_for_display();
		extract($settings);
		$row_open = '<div class="ekit-comparison-row">';
		$row_close = '</div>';
		$count = 0;
		?>
		<?php if ($ekit_cp_table_compare_button_position === 'top'): ?>
			<div class="compare-button-wrap">
				<?php if ($ekit_cp_table_compare_button_switch === 'inline'): ?>
					<button id="buttonId"
						class="compare-button"><?php echo esc_html_e($ekit_cp_table_compare_button_text, 'elementskit'); ?></button>
				<?php endif;

				if ($ekit_cp_table_compare_button_switch === 'tab'): ?>
					<div class="ekit-diff-toggle on" id="buttonId">
						<span class="ekit-diff-off"><?php esc_html_e($ekit_cp_table_compare_full_button_text, 'elementskit'); ?></span>
						<span class="ekit-diff-on"><?php esc_html_e($ekit_cp_table_compare_button_text, 'elementskit'); ?></span>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="ekit-comparison-table-content">
			<div class="ekit-comparison-table-wrapper">
				<?php if ($settings['ekit_cp_table_heading_show'] === 'yes'): ?>
					<div class="ekit-comparison-table-heading">
						<div class="ekit-comparison-row">
							<?php foreach ($settings['ekit_cp_table_heading_content'] as $index => $item):
								!empty($item['ekit_cp_table_heading_cell_url']['url']) && $this->add_link_attributes('ekit_cp_table_heading_cell_url' . $item['_id'], $item['ekit_cp_table_heading_cell_url']);

								$hide_heading = $item['ekit_cp_heading_hide_on'] ?? '';
								$heading_classes = 'ekit-comparison-table-heading-cell elementor-repeater-item-' . $item['_id'] .
												' ' . $item['ekit_cp_table_heading_cell_icon_position'];
								if ( $hide_heading ) {
									$heading_classes .= ' hide-on-' . $hide_heading;
								}
								?>
								<div class="<?php echo esc_attr( $heading_classes ); ?>">
									<?php if (empty($item['ekit_cp_table_heading_cell_url']['url'])): ?>
										<li>
											<?php if ( ! empty( $item['ekit_cp_table_heading_cell_icons']['value'] ) ) : ?>
												<?php
											
												$user_color = $item['ekit_cp_table_heading_cell_icon_color'] ?? '';

												// ----- 2. Detect special icons
												$icon_value = $item['ekit_cp_table_heading_cell_icons']['value'];
												$icon_library = $item['ekit_cp_table_heading_cell_icons']['library'] ?? 'fa-solid';

												$auto_color = '';
												if ( strpos( $icon_value, 'fa-check' ) !== false
													|| strpos( $icon_value, 'icon-tick' ) !== false
													|| strpos( $icon_value, 'icon-check' ) !== false ) {
													$auto_color = 'var(--e-global-color-primary)';               // green
												} elseif ( 
													strpos( $icon_value, 'icon-cross' ) !== false || 
													strpos( $icon_value, 'icon-cancel' ) !== false ) {
													$auto_color = 'red';               // red
												}

												// ----- 3. Final colour (user > auto > default)
												$final_color = $user_color ? $user_color : ( $auto_color ?: 'inherit' );

												// ----- 4. Render with inline style
												$icon_args = [
													'aria-hidden' => 'true',
													'style'       => "color:{$final_color}; fill:{$final_color};",
												];
												\Elementor\Icons_Manager::render_icon( $item['ekit_cp_table_heading_cell_icons'], $icon_args );
												?>
											<?php endif; ?>

											<?php if (!empty($item['ekit_cp_table_heading_cell_text'])): ?>
												<?php echo wp_kses($item['ekit_cp_table_heading_cell_text'], \ElementsKit_Lite\Utils::get_kses_array()); ?>
											<?php endif; ?>

											<?php if (!empty($item['ekit_cp_table_heading_cell_image']['url'])): ?>
												<img src="<?php echo esc_url($item['ekit_cp_table_heading_cell_image']['url']); ?>" alt="">
											<?php endif; ?>
										</li>
									<?php else: ?>
										<a <?php $this->print_render_attribute_string('ekit_cp_table_heading_cell_url' . $item['_id']); ?>>
											<?php if ( ! empty( $item['ekit_cp_table_heading_cell_icons']['value'] ) ) : ?>
												<?php
												// ----- 1. Get the chosen colour (or empty)
												$user_color = $item['ekit_cp_table_heading_cell_icon_color'] ?? '';

												// ----- 2. Detect special icons
												$icon_value = $item['ekit_cp_table_heading_cell_icons']['value'];
												$icon_library = $item['ekit_cp_table_heading_cell_icons']['library'] ?? 'fa-solid';

												$auto_color = '';
												if ( strpos( $icon_value, 'fa-check' ) !== false
													|| strpos( $icon_value, 'icon-tick' ) !== false
													|| strpos( $icon_value, 'icon-check' ) !== false ) {
													$auto_color = 'var(--e-global-color-primary)';               // green
												}elseif ( 
													strpos( $icon_value, 'icon-cross' ) !== false || 
													strpos( $icon_value, 'icon-cancel' ) !== false ) {
													$auto_color = 'red';               // red
												}

												// ----- 3. Final colour (user > auto > default)
												$final_color = $user_color ? $user_color : ( $auto_color ?: 'inherit' );

												// ----- 4. Render with inline style
												$icon_args = [
													'aria-hidden' => 'true',
													'style'       => "color:{$final_color}; fill:{$final_color};",
												];
												\Elementor\Icons_Manager::render_icon( $item['ekit_cp_table_heading_cell_icons'], $icon_args );
												?>
											<?php endif; ?>

											<?php if (!empty($item['ekit_cp_table_heading_cell_text'])): ?>
												<?php echo wp_kses($item['ekit_cp_table_heading_cell_text'], \ElementsKit_Lite\Utils::get_kses_array()); ?>
											<?php endif; ?>

											<?php if (!empty($item['ekit_cp_table_heading_cell_image']['url'])): ?>
												<img src="<?php echo esc_url($item['ekit_cp_table_heading_cell_image']['url']); ?>" alt="">
											<?php endif; ?>
										</a>
									<?php endif; ?>

									<!-- Head button code cut -->
									
									<?php if ($item['show_button_sf_controls_head'] === 'yes'): ?>
											<div class="tbody-head">
											<?php
											// Generate classes from item settings
											$btn_text = $item['ekit_btn_text_head'];
											$btn_class = !empty($item['ekit_btn_class_head']) ? esc_attr($item['ekit_btn_class_head']) : '';
											$btn_id    = !empty($item['ekit_btn_id_head'])    ? esc_attr($item['ekit_btn_id_head'])    : '';

											$icon_align = $item['ekit_btn_icon_align_head'] ?? 'left';

											// Variant classes
											$style = $item['ekit_icon_box_button_style_'] ?? 'Default';
											$variant_class = '';
											if ($style === 'Default') {
												$variant_class = ' default-btn';
											} elseif ($style === 'Flat') {
												$button_variant = $item['button_variant'] ?? 'primary';
												$variant_class = ' flat-' . $button_variant;
											} elseif ($style === 'Outline') {
												$outline_variant = $item['outline_variant'] ?? 'primary';
												$variant_class = ' outline-' . $outline_variant;
												if ($item['outline_hover_effect'] !== 'yes') {
													$btn_class .= ' no-hover-fill';
												}
											} elseif ($style === 'Stacked') {
												$stacked_variant = $item['ekit_icon_box_stacked_'] ?? 'primary';
												$variant_class = ' stacked-' . $stacked_variant;
												$btn_class .= ' sf-widget-link-underline keydesign-underline';
											}
											$btn_class .= $variant_class . ' whitespace--normal';

											if ($style === 'Stacked') {
												$btn_class .= ' sf-widget-link-underline keydesign-underline';
											}

											// Size class (global from settings, but per-item ok)
											$size = $settings['_button_size'] ?? 'sm'; // Use global size
											$size_class = ' size-' . $size;

											$all_btn_classes = trim('elementskit-btn sf-item-button ' . $btn_class . $size_class); // Add sf-item-button for styles

											$this->add_render_attribute('sf_item_button_' . $index, [
												'class' => $all_btn_classes,
												'id' => $btn_id
											]);


											// Add link attributes (do this BEFORE rendering the <a> tag)
											if (!empty($item['ekit_btn_url_head']['url'])) {
												$this->add_link_attributes('sf_item_button_link_' . $index, $item['ekit_btn_url_head']);
											}
											?>
											<div class="sf-item-button-wraper ekit-btn-inner">
												<a <?php echo $this->get_render_attribute_string('sf_item_button_' . $index); ?> 	<?php echo $this->get_render_attribute_string('sf_item_button_link_' . $index); ?>>
													<?php if ($item['ekit_btn_icons__switch_head'] === 'yes' && !empty($item['ekit_btn_icons_head']['value'])): ?>
														<?php if ($icon_align == 'right'): ?>
															<?php echo esc_html($btn_text); ?>
															<?php Icons_Manager::render_icon($item['ekit_btn_icons_head'], ['aria-hidden' => 'true', 'class' => 'icon-after']); ?>
														<?php else: ?>
															<?php Icons_Manager::render_icon($item['ekit_btn_icons_head'], ['aria-hidden' => 'true', 'class' => 'icon-before']); ?>
															<?php echo esc_html($btn_text); ?>
														<?php endif; ?>
													<?php else: ?>
														<?php echo esc_html($btn_text); ?>
													<?php endif; ?>
												</a>
											</div>
										</div>
									<?php endif; ?>
									
									<?php if ($item['ekit_cp_table_heading_cell_description_show'] === 'yes' && !empty($item['ekit_cp_table_heading_cell_description'])): ?>
										<div class="ekit-comparison-heading-description">
											<?php echo wp_kses($item['ekit_cp_table_heading_cell_description'], \ElementsKit_Lite\Utils::get_kses_array()); ?>
										</div>
									<?php endif; ?>

								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
				<div class="ekit-comparison-table-body">
					<?php foreach ($ekit_cp_table_body_content as $index => $item):

						!empty($item['ekit_cp_table_body_cell_url']['url']) && $this->add_link_attributes('ekit_cp_table_body_cell_url' . $item['_id'], $item['ekit_cp_table_body_cell_url']);

						if ($item['ekit_cp_table_row'] == 'Row') {
							if ($count == 0) {
								echo wp_kses($row_open, \ElementsKit_Lite\Utils::get_kses_array());
							} elseif ($count > 0) {
								echo wp_kses($row_close, \ElementsKit_Lite\Utils::get_kses_array());
								echo wp_kses($row_open, \ElementsKit_Lite\Utils::get_kses_array());
							}
							$count++;
						}

						?>
						<?php 
						$hide_body = $item['ekit_cp_body_hide_on'] ?? '';
						$body_classes = 'ekit-comparison-table-cell elementor-repeater-item-' . $item['_id'] .
										' ' . $item['ekit_cp_table_body_cell_icon_position'];
						if ( $hide_body ) {
							$body_classes .= ' hide-on-' . $hide_body;
						}
						?>
						<div class="<?php echo esc_attr( $body_classes ); ?>">

							<?php if (empty($item['ekit_cp_table_body_cell_url']['url'])): ?>
								<li>
									<?php if ( ! empty( $item['ekit_cp_table_body_cell_icons']['value'] ) ) : ?>
										<?php
										$user_color = $item['ekit_cp_table_body_cell_icon_color'] ?? '';
										$icon_value = $item['ekit_cp_table_body_cell_icons']['value'];

										$auto_color = '';
										if ( strpos( $icon_value, 'fa-check' ) !== false
											|| strpos( $icon_value, 'icon-tick' ) !== false
											|| strpos( $icon_value, 'icon-check' ) !== false ) {
											$auto_color = 'var(--e-global-color-primary)';
										}elseif ( 
													strpos( $icon_value, 'icon-cross' ) !== false || 
													strpos( $icon_value, 'icon-cancel' ) !== false ) {
											$auto_color = 'red';
										}

										$final_color = $user_color ? $user_color : ( $auto_color ?: 'inherit' );

										$icon_args = [
											'aria-hidden' => 'true',
											'style'       => "color:{$final_color}; fill:{$final_color};",
										];
										\Elementor\Icons_Manager::render_icon( $item['ekit_cp_table_body_cell_icons'], $icon_args );
										?>
									<?php endif; ?>

									<?php if (!empty($item['ekit_cp_table_cell_text'])): ?>
										<?php echo wp_kses($item['ekit_cp_table_cell_text'], \ElementsKit_Lite\Utils::get_kses_array()); ?>
									<?php endif; ?>

									<?php if (!empty($item['ekit_cp_table_body_cell_icon_image']['url'])): ?>
										<img src="<?php echo esc_url($item['ekit_cp_table_body_cell_icon_image']['url']); ?>" alt="">
									<?php endif; ?>
								</li>
							<?php else: ?>
								<a <?php $this->print_render_attribute_string('ekit_cp_table_body_cell_url' . $item['_id']); ?>>
									<?php if ( ! empty( $item['ekit_cp_table_body_cell_icons']['value'] ) ) : ?>
										<?php
										$user_color = $item['ekit_cp_table_body_cell_icon_color'] ?? '';
										$icon_value = $item['ekit_cp_table_body_cell_icons']['value'];

										$auto_color = '';
										if ( strpos( $icon_value, 'fa-check' ) !== false
											|| strpos( $icon_value, 'icon-tick' ) !== false
											|| strpos( $icon_value, 'icon-check' ) !== false ) {
											$auto_color = 'var(--e-global-color-primary)';
										} elseif ( 
													strpos( $icon_value, 'icon-cross' ) !== false || 
													strpos( $icon_value, 'icon-cancel' ) !== false ) {
											$auto_color = 'red';
										}

										$final_color = $user_color ? $user_color : ( $auto_color ?: 'inherit' );

										$icon_args = [
											'aria-hidden' => 'true',
											'style'       => "color:{$final_color}; fill:{$final_color};",
										];
										\Elementor\Icons_Manager::render_icon( $item['ekit_cp_table_body_cell_icons'], $icon_args );
										?>
									<?php endif; ?>

									<?php if (!empty($item['ekit_cp_table_cell_text'])): ?>
										<?php echo wp_kses($item['ekit_cp_table_cell_text'], \ElementsKit_Lite\Utils::get_kses_array()); ?>
									<?php endif; ?>

									<?php if (!empty($item['ekit_cp_table_body_cell_icon_image']['url'])): ?>
										<img src="<?php echo esc_url($item['ekit_cp_table_body_cell_icon_image']['url']); ?>" alt="">
									<?php endif; ?>
								</a>
							<?php endif; ?>

							<!-- body button Code Cut -->
							 

							
							<?php if ($item['show_button_sf_controls'] === 'yes'): ?>
								<div class="tbody-button">
								<?php
								// Generate classes from item settings
								$btn_text = $item['ekit_btn_text'];
								$btn_class = !empty($item['ekit_btn_class']) ? esc_attr($item['ekit_btn_class']) : '';
								$btn_id    = !empty($item['ekit_btn_id'])    ? esc_attr($item['ekit_btn_id'])    : '';

								$icon_align = $item['ekit_btn_icon_align'] ?? 'left';

								// Variant classes
								$style = $item['ekit_icon_box_button_style__body'] ?? 'Default';
								$variant_class = '';
								if ($style === 'Default') {
									$variant_class = ' default-btn';
								} elseif ($style === 'Flat') {
									$button_variant = $item['button_variant_body'] ?? 'primary';
									$variant_class = ' flat-' . $button_variant;
								} elseif ($style === 'Outline') {
									$outline_variant = $item['outline_variant_body'] ?? 'primary';
									$variant_class = ' outline-' . $outline_variant;
									if ($item['outline_hover_effect_body'] !== 'yes') {
										$btn_class .= ' no-hover-fill';
									}
								} elseif ($style === 'Stacked') {
									$stacked_variant = $item['ekit_icon_box_stacked__body'] ?? 'primary';
									$variant_class = ' stacked-' . $stacked_variant;
									$btn_class .= ' sf-widget-link-underline keydesign-underline';
								}
								$btn_class .= $variant_class . ' whitespace--normal';

								if ($style === 'Stacked') {
									$btn_class .= ' sf-widget-link-underline keydesign-underline';
								}

								// Size class (global from settings, but per-item ok)
								$size = $settings['_button_size'] ?? 'sm'; // Use global size
								$size_class = ' size-' . $size;

								$all_btn_classes = trim('elementskit-btn sf-item-button ' . $btn_class . $size_class); // Add sf-item-button for styles
				
								$this->add_render_attribute('sf_item_button_' . $index, [
									'class' => $all_btn_classes,
									'id' => $btn_id
								]);


								// Add link attributes (do this BEFORE rendering the <a> tag)
								if (!empty($item['ekit_btn_url']['url'])) {
									$this->add_link_attributes('sf_item_button_link_' . $index, $item['ekit_btn_url']);
								}
								?>
								<div class="sf-item-button-wraper ekit-btn-inner">
									<a <?php echo $this->get_render_attribute_string('sf_item_button_' . $index); ?>
									<?php echo $this->get_render_attribute_string('sf_item_button_link_' . $index); ?>>
										<?php if ($item['ekit_btn_icons__switch'] === 'yes' && !empty($item['ekit_btn_icons']['value'])): ?>
												<?php if ($icon_align == 'right'): ?>
														<?php echo esc_html($btn_text); ?>
														<?php Icons_Manager::render_icon($item['ekit_btn_icons'], ['aria-hidden' => 'true', 'class' => 'icon-after']); ?>
												<?php else: ?>
														<?php Icons_Manager::render_icon($item['ekit_btn_icons'], ['aria-hidden' => 'true', 'class' => 'icon-before']); ?>
														<?php echo esc_html($btn_text); ?>
												<?php endif; ?>
										<?php else: ?>
												<?php echo esc_html($btn_text); ?>
										<?php endif; ?>
									</a>
								</div>		
					       		</div>  
							<?php endif; ?>	
							
								<?php if ($item['ekit_cp_table_body_cell_description_show'] === 'yes' && !empty($item['ekit_cp_table_body_cell_description'])): ?>
									<div class="ekit-comparison-body-description">
										<?php echo wp_kses($item['ekit_cp_table_body_cell_description'], \ElementsKit_Lite\Utils::get_kses_array()); ?>
									</div>
										<?php endif; ?>
									</div>
									<?php
									if ($index == count($ekit_cp_table_body_content) - 1) {
										echo wp_kses($row_close, \ElementsKit_Lite\Utils::get_kses_array());
									}
								endforeach; ?>
				</div>
			</div>
			<div class="ekit-comparison-table-button">
				<?php foreach ($ekit_cp_table_button_list as $index => $item):
					?>
					<a class="ekit-cp-button elementor-repeater-item-<?php echo esc_attr($item['_id']); ?>"
						href="<?php echo esc_url($item['ekit_cp_table_btn_link']['url']) ?>"><?php echo esc_html($item['ekit_cp_table_btn_title']); ?></a>
					<?php
				endforeach; ?>
			</div>
		</div>

		<?php if ($ekit_cp_table_compare_button_position === 'bottom'): ?>
			<div class="compare-button-wrap">
				<?php if ($ekit_cp_table_compare_button_switch === 'inline'): ?>
					<button id="buttonId"
						class="compare-button"><?php esc_html_e($ekit_cp_table_compare_button_text, 'elementskit'); ?></button>
				<?php endif;

				if ($ekit_cp_table_compare_button_switch === 'tab'): ?>
					<div class="ekit-diff-toggle on" id="buttonId">
						<span class="ekit-diff-off"><?php esc_html_e($ekit_cp_table_compare_full_button_text, 'elementskit'); ?></span>
						<span class="ekit-diff-on"><?php esc_html_e($ekit_cp_table_compare_button_text, 'elementskit'); ?></span>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	<?php

	}
}