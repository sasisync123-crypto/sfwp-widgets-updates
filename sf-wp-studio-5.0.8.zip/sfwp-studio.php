<?php
/* 
 * Plugin Name: SF Widget Suite
 * Description: Modular Elementor widget suite with dark mode, and multilingual support.
 * Version: 1.0.0
 * Author: Syncfusion, Inc
 * Text Domain: sfwp-studio
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define the plugin root path constant.
define( 'SFWP_DIR', plugin_dir_path( __FILE__ ) );

// Check Elementor is active
function sfwp_studio_check_elementor() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p>SFWP Studio requires Elementor to be installed and activated.</p></div>';
        });
        return;
    }

    // Load plugin core
    require_once plugin_dir_path( __FILE__ ) . 'includes/loader.php';
}
add_action( 'plugins_loaded', 'sfwp_studio_check_elementor' );

// Load translations
function sfwp_studio_load_textdomain() {
    load_plugin_textdomain( 'sfwp-studio', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'init', 'sfwp_studio_load_textdomain' );


add_action( 'elementor_pro/forms/validation', function( $record, $handler ) {
    $form_name = $record->get_form_settings( 'form_name' );
 
    if ( 'contact form' === $form_name ) {
        $fields = $record->get( 'fields' );
 
        // Name: required, min length
        $name = $fields['name']['value'] ?? '';
        if ( empty( $name ) || strlen( $name ) < 2 ) {
            $handler->add_error( 'name', 'Please enter your full name.' );
        }
 
        // Email: required, valid format
        $email = $fields['email']['value'] ?? '';
        if ( empty( $email ) || ! is_email( $email ) ) {
            $handler->add_error( 'email', 'Please enter a valid email address.' );
        }
 
        // Phone: required, digits only, 10–15 length
        $phone = $fields['phone']['value'] ?? '';
        if ( empty( $phone ) || ! preg_match( '/^[0-9]{10,15}$/', $phone ) ) {
            $handler->add_error( 'phone', 'Please enter a valid phone number (10–15 digits).' );
        }
 
        // Subject: required
        $subject = $fields['subject']['value'] ?? '';
        if ( empty( $subject ) ) {
            $handler->add_error( 'subject', 'Subject is required.' );
        }
 
        // Help/Description: required, min length
        $help = $fields['help']['value'] ?? '';
        if ( empty( $help ) || strlen( $help ) < 10 ) {
            $handler->add_error( 'help', 'Please describe your issue (at least 10 characters).' );
        }
    }
}, 10, 2 );
 
 
 
add_action('elementor_pro/forms/new_record', function ($record, $handler) {
    $form_name = $record->get_form_settings('form_name');
 
    if ('contact form' === $form_name) {
        $fields = [];
        foreach ($record->get('fields') as $id => $field) {
            $fields[$id] = $field['value'];
        }
 
 
        $payload = [
            "brandId" => 15,
            "subject" => $fields['subject'] ?? '',
            "description" => $fields['help'] ?? '',
            "priorityId" => 3,
            "categoryId" => 10,
            "typeId" => 1,
            "contactPhoneNo" => $fields['phone'] ?? '',
            "requesterName" => $fields['name'] ?? '',
            "isVisibleInCustomerPortal" => true,
            "requesterEmailId" => $fields['email'] ?? '',
        ];
 
        $response = wp_remote_post(BOLDSALE_API_URL, [
            'headers' => [
                'Content-Type' => 'application/json',
                'x-api-key' => BOLDSALE_API_KEY
            ],
            'body' => wp_json_encode($payload),
        ]);
 
        if (is_wp_error($response)) {
            $handler->add_error_message('There was a problem submitting your request. Please try again.');
            error_log( 'Webhook error: ' . $response->get_error_message() );
        } else {
            $body = wp_remote_retrieve_body($response);
            $decoded = json_decode($body, true);
error_log( 'Webhook response: ' . wp_remote_retrieve_body( $response ) );
            if (isset($decoded['error'])) {
                $handler->add_error_message('API Error: ' . $decoded['error']);
            }
        }
    }
}, 10, 2);
 