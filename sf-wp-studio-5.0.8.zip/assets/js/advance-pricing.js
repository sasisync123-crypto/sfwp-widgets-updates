(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf-advance-pricing-table.default', function ($scope) {
            pricing($scope);
        });
    });

    function pricing($scope) {

    }
})(jQuery);