<?php
namespace SFWPStudio\Core\Helpers\Traits;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH')) exit;

trait DescriptionTrait
{
    protected function register_description_controls()
    {
        // DESCRIPTION SECTION
        $this->start_controls_section(
            'description_section',
            [
                'label' => __('Description', 'elementor-avatar-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'description_text',
            [
                'label' => __('Description', 'elementor-avatar-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Building strong teams and fostering a positive workplace culture.', 'elementor-avatar-widget'),
                'placeholder' => __('Enter description here', 'elementor-avatar-widget'),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'description_tag',
            [
                'label' => __('Description Tag', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'p',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'p',
                    'div' => 'div',
                    'span' => 'span',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'show_description',
            [
                'label' => __('Show Description', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-avatar-widget'),
                'label_off' => __('No', 'elementor-avatar-widget'),
                'return_value' => 'yes',
                'default' => 'No',
            ]
        );

        $this->add_control(
            'description_position',
            [
                'label' => __('Description Position', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'above' => __('Above Avatar', 'elementor-avatar-widget'),
                    'below' => __('Below Avatar', 'elementor-avatar-widget'),
                    'before' => __('Left Avatar', 'elementor-avatar-widget'),
                    'after' => __('Right Avatar', 'elementor-avatar-widget'),
                ],
                'default' => 'above',
            ]
        );

        $this->end_controls_section();
    }

    protected function render_description($settings, $position = null)
    {
        $text = $settings['description_text'];
        $tag = $settings['description_tag'];
        $description_position = $position ?? ($settings['description_position'] ?? 'below');

        if ($settings['show_description'] === 'yes' && !empty($text)) {
            // Render only if position matches or no specific position provided
            if ($position === null || $description_position === $position) {
                echo '<' . esc_attr($tag) . ' class="avatar-description">' . esc_html($text) . '</' . esc_attr($tag) . '>';
            }
        }
    }

    protected function register_description_style_controls()
    {
        // DESCRIPTION STYLE SECTION
        $this->start_controls_section(
            'section_description_style',
            [
                'label' => __('Description', 'elementor-avatar-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_description' => 'yes', // Show this section only if show_title is 'yes'
                ],
            ]
        );

        $this->add_control(
            'description_text_color',
            [
                'label' => __('Text Color', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'var(--color-text);',
                'selectors' => [
                    '{{WRAPPER}} .avatar-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'description_hover_color',
            [
                'label' => __('Hover Color', 'elementor-avatar-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .avatar-description:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __('Description Typography', 'elementor-avatar-widget'),
                'selector' => '{{WRAPPER}} .avatar-description',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'description_text_shadow',
                'label' => __('Text Shadow', 'elementor-avatar-widget'),
                'selector' => '{{WRAPPER}} .avatar-description',
            ]
        );

        $this->add_responsive_control(
            'description_text_align',
            [
                'label' => __('Text Alignment', 'elementor-avatar-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-description' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_padding',
            [
                'label' => __('Padding', 'elementor-avatar-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'default' => [
                    'top' => 10,
                    'right' => 0,
                    'bottom' => 10,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_margin',
            [
                'label' => __('Margin', 'elementor-avatar-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'Description_width',
            [
                'label' => __('Width', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 0.1,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-description' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }
}
