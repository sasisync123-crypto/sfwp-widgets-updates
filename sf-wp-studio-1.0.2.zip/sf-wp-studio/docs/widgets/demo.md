RAW JSON:
{
  "widget name" : "Notication banner", //given
  "summary": "",
  "free_features": [
    {
      "name": "",
      "description": ""
    },
    {
      "name": "",
      "description": ""
    }
  ],
  "pro_features": [
    {
      "name": "",
      "description": ""
    },
    {
      "name": "",
      "description": ""
    }
  ],
  "background_motivation": {
    "limitations": "",
    "motivation": ""
  },
  "architecture": {
  "type": "custom", // "custom", "extended", or "forked"
  "base": "Elementor", // "Elementor" or "ElementsKit"
  "extends": "", // if "extended", name the original widget
  "forked_from": "", // if "forked", name the copied widget
  "traits": ["ButtonTrait"],
  "is_separate_style_sheet":"yes", //yes/no,
  "is_JS_Used":"yes" //yes/no
},
  "impact": [
    "",
    "",
    "",
    ""
  ],
  "next": {
    "features": [
      "",
      ""
    ],
    "refactor": ""
  },
  "usage_context": {
    "used_in": [" ", "", ""],
    "compatible_with": ["", "", ""]
  }
}


Exmaple Using JSON (Notification banner)

{
  "widget name" : "Notication banner", //given
  "summary": "so this widget is used as a CTA banner and also used as a alert banner so it can attract user and hide when closed",
  "free_features": [
    {
      "name": "auto hide",
      "description": "so this is used to make the banner to ato hide and also can set the timer for the hide"
    },
    {
      "name": "hide banner",
      "description": "provided this responsive control so they can use it hide the banner when they move to small devices"
    },
    {
      "name": "icon/avatart",
      "description": "given a option to set the icon or avatart based on the design"
    },
    {
      "name": "button",
      "description": "given a option to set the button for the banner sdo user click and sales will increase"
    },
    {
      "name": "link",
      "description": "given a option to add a link to the banner itself so when user hiver and click the banner it navigate to sales page"
    },
    {
      "name": "content orientation",
      "description": "Given controls for the content orientation like row ans column and spacing between the el;emnts"
    },
  ],
  "pro_features": [
    {
      "name": "style 1 varient",
      "description": "in this style we have givwen a solid background color with the gradient border "
    },
    {
      "name": "style 2 varient",
      "description": "in this style we have givwen a gradient background color with the solid border"
    }
    {
      "name": "style 3 varient",
      "description": "in this style we have givwen a image background with the gradient border"
    }
  ],
  "background_motivation": {
    "limitations": "",
    "motivation": ""
  },
  "architecture": {
  "type": "forked", // "custom", "extended", or "forked"
  "base": "elementskit", // "Elementor" or "ElementsKit"
  "extends": "", // if "extended", name the original widget
  "forked_from": "heading", // if "forked", name the copied widget
  "traits": ["ButtonTrait"],
  "is_separate_style_sheet":"no", //yes/no,
  "is_JS_Used":"yes" //yes/no
},
  "impact": [
    "so using this widget we can create a cta banner with easy manner",
    "u itself write any imapct  ",
    "",
    ""
  ],
  "next": {
    "features": [
      {
      "name": "image overlay",
      "description": "so we provided the image styel aslo and planning to goive the overlay for the image so we can see the great ux there"
    }
    ],
    "refactor": "sf widgets text domain update"
  },
  "usage_context": {
    "used_in": ["CTA section", "header navbar", "hero section"],
    "compatible_with": ["seirra", "sf frmaework", "other themes"]
  }
}


Using the following JSON input, generate a well-structured widget documentation in markdown format.
IMPORTANT : Generate the document in a way that it is fully understandle and make a professional document and follow the standard document creation rulue, make all sentance starting as capital case

Maintain this structure and formatting:

## 🧩 Widget Documentation Template

### 📝 Widget Summary  
Write a 2-line summary describing what the widget does and how it enhances the user experience. Use `"widget name"` and `"summary"` fields.

---

### 🆓 Free Features  
List all features from `"free_features"` using this format:
- **{{ name }}** – {{ description }}

---

### 💎 Pro Features  
List all features from `"pro_features"` using this format:
- **{{ name }}** – {{ description }}

---

### 🔍 Background & Motivation  
**Existing Limitations**  
Use `"background_motivation.limitations"`

**Why We Developed This**  
Use `"background_motivation.motivation"`

---

### 🏗️ Architecture  
Generate this section dynamically based on `"architecture"` values:

- **Base Widget**:  
  - If `"type"` is `"custom"` → `"Built from scratch using {{ base }} base classes."`  
  - If `"type"` is `"extended"` → `"Extended from {{ extends }} using {{ base }}."`  
  - If `"type"` is `"forked"` → `"Forked from {{ forked_from }} in {{ base }} and customized independently."`

- **Trait Used**: List `"traits"`  
- **Used separate style sheet**: `"Yes"` if `"is_separate_style_sheet"` is `"yes"`  
- **Used JS file**: `"Yes"` if `"is_JS_Used"` is `"yes"`

---

### 📈 What’s Next  
-Formate -  **{{ name }}** – {{ description }}
- **Planned Feature 1** – Use `"next.features[0]" `  
- **Planned Feature 2** – Use `"next.features[1]"`  
- **Refactor Plan** – Use `"next.refactor"`

---

### 🗂️ Usage Context  
**Used In**: List `"usage_context.used_in"`  
**Compatible With**: List `"usage_context.compatible_with"`





OUTPUT GOT FROM AI:

## 🧩 Widget Documentation Template

### 📝 Widget Summary  
The **Notification Banner** widget serves as both a call-to-action (CTA) and alert banner. It is designed to attract user attention and can be dismissed with a close action, enhancing user engagement and interface clarity.

---

### 🆓 Free Features  
- **Auto Hide** – Enables the banner to automatically hide after a set timer.  
- **Hide Banner** – Provides responsive controls to hide the banner on smaller devices.  
- **Icon/Avatar** – Offers options to set an icon or avatar based on design preferences.  
- **Button** – Allows adding a clickable button to boost user interaction and conversions.  
- **Link** – Supports embedding a link within the banner for navigation to sales or target pages.  
- **Content Orientation** – Includes controls for layout orientation (row/column) and spacing between elements.

---

### 💎 Pro Features  
- **Style 1 Variant** – Features a solid background color with a gradient border.  
- **Style 2 Variant** – Features a gradient background color with a solid border.  
- **Style 3 Variant** – Features an image background with a gradient border.

---

### 🔍 Background & Motivation  
**Existing Limitations**  
No limitations were explicitly documented.

**Why We Developed This**  
No specific motivation was provided, but the widget aims to simplify CTA and alert banner creation with flexible design and responsive behavior.

---

### 🏗️ Architecture  
- **Base Widget**:  
  Built from scratch using Elementor base classes.

- **Trait Used**:  
  ButtonTrait

- **Used Separate Style Sheet**:  
  Yes

- **Used JS File**:  
  Yes

---

### 📈 What’s Next  
- **Image Overlay** – We plan to introduce image overlay options to enhance visual UX when using image backgrounds.  
- **Refactor Plan** – SF widgets text domain update.

---

### 🗂️ Usage Context  
**Used In**:  
CTA Section, Header Navbar, Hero Section

**Compatible With**:  
Seirra, SF Framework, Other Themes



OUTPUT 2: (with elmentskit frok)
## 🧩 Widget Documentation Template

### 📝 Widget Summary  
The **Notification Banner** widget is designed to serve as both a call-to-action (CTA) and an alert banner. It helps attract user attention and can be dismissed with a close action, enhancing user engagement and interface clarity.

---

### 🆓 Free Features  
- **Auto Hide** – Enables the banner to automatically hide after a set timer.  
- **Hide Banner** – Provides responsive controls to hide the banner on smaller devices.  
- **Icon/Avatar** – Offers options to set an icon or avatar based on design needs.  
- **Button** – Allows adding a clickable button to boost user interaction and drive conversions.  
- **Link** – Supports embedding a link within the banner so users can navigate to a sales page on hover and click.  
- **Content Orientation** – Includes controls for arranging content in rows or columns with adjustable spacing.

---

### 💎 Pro Features  
- **Style 1 Variant** – Features a solid background color with a gradient border.  
- **Style 2 Variant** – Features a gradient background color with a solid border.  
- **Style 3 Variant** – Features an image background with a gradient border.

---

### 🔍 Background & Motivation  
**Existing Limitations**  
None specified.

**Why We Developed This**  
None specified.

---

### 🏗️ Architecture  
- **Base Widget**:  
  Forked from **heading** in **ElementsKit** and customized independently.

- **Trait Used**:  
  ButtonTrait

- **Used Separate Style Sheet**:  
  No

- **Used JS File**:  
  Yes

---

### 📈 What’s Next  
- **Image Overlay** – We plan to introduce image overlay support to enhance visual UX when using image backgrounds.  
- **Refactor Plan** – SF widgets text domain update.

---

### 🗂️ Usage Context  
**Used In**:  
CTA Section, Header Navbar, Hero Section

**Compatible With**:  
Seirra, SF Framework, Other Themes

---

Would you like help drafting a changelog entry or release note for this widget update?
