<?php
namespace SFWPStudio\Core\Helpers\Traits;

if (!defined('ABSPATH')) {
    exit;
}
use Elementor\Controls_Manager;

trait FancyAnimatedTextTrait
{
    protected function fancy_text_register_controls()
    {
        // Settings options section
        $this->start_controls_section(
            'ekit_section_fancy_text',
            [
                'label' => esc_html__('Fancy Text', 'sf-widget'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_fancy_text',
            [
                'label' => esc_html__('Show Fancy Text', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
                'default' => 'no',
            ]
        );

        // fancy heading animated start
        $this->add_control(
            'fancy_text_animation',
            [
                'label' => esc_html__('Animation', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_animation_type',
            [
                'label' => esc_html__('Animation Type', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'clip',
                'options' => [
                    'clip' => esc_html__('Clip', 'sf-widget'),
                    'rotate-1' => esc_html__('Flip Rotate', 'sf-widget'),
                    'rotate-2' => esc_html__('Letter FadeIn', 'sf-widget'),
                    'rotate-3' => esc_html__('Letter Rotate', 'sf-widget'),
                    'type' => esc_html__('Typing Letter', 'sf-widget'),
                    'bar-loading' => esc_html__('Bar Loading', 'sf-widget'),
                    'slide' => esc_html__('Slide Top', 'sf-widget'),
                    'zoom-out' => esc_html__('Zoom Out', 'sf-widget'),
                    'scale' => esc_html__('Scale In', 'sf-widget'),
                    'push' => esc_html__('Push Left', 'sf-widget'),
                    'color-effect' => esc_html__('Color Effect', 'sf-widget'),
                    'bouncing' => esc_html__('Bouncing Effect', 'sf-widget'),
                ],
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_animation_delay',
            [
                'label' => esc_html__('Animation Delay (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 2500,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['rotate-1', 'rotate-2', 'rotate-3', 'slide', 'zoom-out', 'scale', 'push', 'color-effect', 'bouncing'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_loading_bar',
            [
                'label' => esc_html__('Animation Delay (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3800,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['bar-loading'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_letters_delay',
            [
                'label' => esc_html__('Letters Delay (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 50,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['rotate-2', 'rotate-3', 'scale', 'bouncing'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_letters_delay_bar',
            [
                'label' => esc_html__('Letters Delay (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 300,
                'min' => 200,
                'max' => 1000,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['bar-loading'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .ekit-fancy-text.bar-loading .ekit-fancy-text-lists b.is-visible' => 'transition: {{VALUE}}ms ease-in-out;',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_type_letters_delay',
            [
                'label' => esc_html__('Type Letters Delay (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 150,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['type'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_selection_duration',
            [
                'label' => esc_html__('Selection Duration (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 500,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['type'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_reveal_duration',
            [
                'label' => esc_html__('Reveal Duration (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 600,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['clip'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_reveal_animation_delay',
            [
                'label' => esc_html__('Reveal Animation Delay (ms)', 'sf-widget'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1500,
                'min' => 1,
                'condition' => [
                    'show_fancy_text' => 'yes',
                    'ekit_fancy_animation_type' => ['clip'],
                ],
            ]
        );

        // Heading Content start
        $this->add_control(
            'fancy_text_content',
            [
                'label' => esc_html__('Content', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_prefix_text',
            [
                'label' => esc_html__('Prefix Text', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Elementskit is ', 'sf-widget'),
                'description' => esc_html__('Text before fancy text', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ekit_fancy_text',
            [
                'label' => esc_html__('Fancy Text', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Addon', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'ekit_fancy_text_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists .ekit-fancy-text{{CURRENT_ITEM}}' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'ekit_fancy_text_background_color',
            [
                'label' => esc_html__('Background Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists .ekit-fancy-text{{CURRENT_ITEM}}' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_text_lists',
            [
                'label' => esc_html__('Fancy Lists', 'sf-widget'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'ekit_fancy_text' => esc_html__('Most', 'sf-widget'),
                    ],
                    [
                        'ekit_fancy_text' => esc_html__('Popular', 'sf-widget'),
                    ],
                    [
                        'ekit_fancy_text' => esc_html__('Addon', 'sf-widget'),
                    ],
                ],
                'title_field' => '{{{ ekit_fancy_text }}}',
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_suffix_text',
            [
                'label' => esc_html__('Suffix Text', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Text after fancy text', 'sf-widget'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_text_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h2',
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_text_link',
            [
                'label' => esc_html__('Link (Optional)', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'placeholder' => esc_html__('https://your-link.com', 'sf-widget'),
                'autocomplete' => false,
                'options' => ['is_external', 'nofollow', 'custom_attributes'],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function fancy_text_register_style_controls()
    {
        // heading style section
        $this->start_controls_section(
            'ekit_fancy_heading_style_section',
            [
                'label' => esc_html__('Fancy Text', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_fancy_container_padding',
            [
                'label' => esc_html__('Fancy Container Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .fancy-text-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_fancy_container_margin',
            [
                'label' => esc_html__('Fancy Container Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .fancy-text-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_fancy_heading_typography',
                'selector' => '{{WRAPPER}} .ekit-fancy-text, {{WRAPPER}} .ekit-fancy-text a',
                'condition' => [
                    'show_fancy_text' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_heading_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text, {{WRAPPER}} .ekit-fancy-text a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_heading_color_hover',
            [
                'label' => esc_html__('Hover Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text:hover, {{WRAPPER}} .ekit-fancy-text:hover a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'ekit_fancy_heading_shadow',
                'selector' => '{{WRAPPER}} .ekit-fancy-text',
            ]
        );

        // heading fancy lists style section
        $this->add_control(
            'ekit_fancy_lists_style_section',
            [
                'label' => esc_html__('Fancy Text Lists', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'ekit_fancy_lists_typography_alignment',
            [
                'type' => Controls_Manager::CHOOSE,
                'label' => esc_html__('Alignment', 'sf-widget'),
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'condition' => [
                    'ekit_fancy_animation_type' => ['rotate-1'],
                ],
                'default' => '',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .ekit-fancy-text-lists' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_fancy_lists_typography',
                'selector' => '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists b',
            ]
        );

        $this->add_control(
            'ekit_fancy_lists_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists b' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_lists_color_effect_color',
            [
                'label' => esc_html__('Text Gradient Color', 'sf-widget'),
                'type' => Controls_Manager::POPOVER_TOGGLE,
                'return_value' => 'yes',
                'condition' => [
                    'ekit_fancy_animation_type' => ['color-effect'],
                ],
            ]
        );

        $this->start_popover();

        $gradient_color = '{{WRAPPER}} .ekit-fancy-text.color-effect .ekit-fancy-text-lists .ekit-fancy-text';
        $this->add_control(
            'gradient_color_01',
            [
                'label' => esc_html__('Color One', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
            ]
        );

        $this->add_control(
            'gradient_color_02',
            [
                'label' => esc_html__('Color Two', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $gradient_color => 'background-image: linear-gradient(-120deg, {{gradient_color_01.VALUE}} 0%, {{gradient_color_02.VALUE}} 100%)!important',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_03',
            [
                'label' => esc_html__('Color Three', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $gradient_color => 'background-image: linear-gradient(-120deg, {{gradient_color_01.VALUE}} 0%, {{gradient_color_02.VALUE}} 50%, {{gradient_color_03.VALUE}} 100%)!important',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_04',
            [
                'label' => esc_html__('Color Four', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $gradient_color => 'background-image: linear-gradient(-120deg, {{gradient_color_01.VALUE}} 0%, {{gradient_color_02.VALUE}} 29%, {{gradient_color_03.VALUE}} 67%, {{gradient_color_04.VALUE}} 100%)!important',
                ],
            ]
        );

        $this->end_popover();

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'ekit_fancy_lists_background_color',
                'label' => esc_html__('Background Color', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_fancy_lists_padding',
            [
                'label' => esc_html__('Fancy List Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists b' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_fancy_lists_margin',
            [
                'label' => esc_html__('Fancy List Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'allowed_dimensions' => ['right', 'left'],
                'placeholder' => [
                    'top' => 'auto',
                    'right' => '',
                    'bottom' => 'auto',
                    'left' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'ekit_fancy_lists_border',
                'label' => esc_html__('Border', 'sf-widget'),
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .ekit-fancy-text .ekit-fancy-text-lists',
            ]
        );

        // Heading fancy cursor style section
        $this->add_control(
            'ekit_fancy_cursor_style_section',
            [
                'label' => esc_html__('Fancy Cursor', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ekit_fancy_animation_type' => ['clip', 'bar-loading', 'type'],
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_cursor_color',
            [
                'label' => esc_html__('Cursor Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text.clip .ekit-fancy-text-lists::after' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .ekit-fancy-text.type .ekit-fancy-text-lists::after' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .ekit-fancy-text.bar-loading .ekit-fancy-text-lists::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_cursor_width',
            [
                'label' => esc_html__('Cursor Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 2,
                ],
                'condition' => [
                    'ekit_fancy_animation_type' => ['clip', 'type'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text.clip .ekit-fancy-text-lists::after' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .ekit-fancy-text.type .ekit-fancy-text-lists::after' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_cursor_height',
            [
                'label' => esc_html__('Cursor Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'condition' => [
                    'ekit_fancy_animation_type' => ['clip', 'type'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text.clip .ekit-fancy-text-lists::after' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .ekit-fancy-text.type .ekit-fancy-text-lists::after' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'ekit_fancy_loading_bar_height',
            [
                'label' => esc_html__('Loading Bar Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 15,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 2,
                ],
                'condition' => [
                    'ekit_fancy_animation_type' => ['bar-loading'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-fancy-text.bar-loading .ekit-fancy-text-lists::after' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function get_fancy_text_kses_array()
    {
        return array(
            'a' => array(
                'class' => array(),
                'href' => array(),
                'rel' => array(),
                'title' => array(),
                'target' => array(),
                'style' => array(),
            ),
            'b' => array(
                'class' => array(),
            ),
            'span' => array(
                'class' => array(),
                'title' => array(),
                'style' => array(),
            ),
        );
    }

    public function fancy_text_esc_options($str, $options = array(), $default = '')
    {
        if (!in_array($str, $options)) {
            return $default;
        }
        return $str;
    }

    protected function get_fancy_content($settings)
    {
        extract($settings);
        ob_start();

        if (!empty($ekit_fancy_prefix_text)): ?>
            <span
                class="ekit-fancy-prefix-text"><?php echo wp_kses($ekit_fancy_prefix_text, $this->get_fancy_text_kses_array()); ?></span>
        <?php endif;

        if (!empty($ekit_fancy_text_lists)): ?>
            <span class="ekit-fancy-text-lists <?php echo esc_attr($ekit_fancy_animation_type == 'type' ? 'waiting' : ''); ?>">
                <?php foreach ($ekit_fancy_text_lists as $key => $ekit_fancy_text_list): ?>
                    <b
                        class="ekit-fancy-text elementor-repeater-item-<?php echo esc_attr($ekit_fancy_text_list['_id']); ?> <?php echo esc_attr($key == 0 ? 'is-visible' : ''); ?>"><?php echo esc_html($ekit_fancy_text_list['ekit_fancy_text']); ?></b>
                <?php endforeach; ?>
            </span>
        <?php endif;

        if (!empty($ekit_fancy_suffix_text)): ?>
            <span
                class="ekit-fancy-suffix-text"><?php echo wp_kses($ekit_fancy_suffix_text, $this->get_fancy_text_kses_array()); ?></span>
        <?php endif;

        return ob_get_clean();
    }

    protected function fancy_text_render()
    {
        $settings = $this->get_settings_for_display();
        extract($settings);

        $animation_types = [
            'clip' => 'clip is-full-width',
            'rotate-1' => 'rotate-1',
            'rotate-2' => 'letters rotate-2',
            'rotate-3' => 'letters rotate-3',
            'type' => 'letters type',
            'bar-loading' => 'bar-loading',
            'slide' => 'slide',
            'zoom-out' => 'zoom-out',
            'scale' => 'letters scale',
            'push' => 'push',
            'color-effect' => 'color-effect',
            'bouncing' => 'letters bouncing',
        ];

        $fancy_animation_type_class = isset($animation_types[$ekit_fancy_animation_type]) ? $animation_types[$ekit_fancy_animation_type] : 'clip is-full-width';

        $options_ekit_text_title_tag = array_keys([
            'h1' => 'H1',
            'h2' => 'H2',
            'h3' => 'H3',
            'h4' => 'H4',
            'h5' => 'H5',
            'h6' => 'H6',
            'div' => 'div',
            'span' => 'span',
            'p' => 'p',
        ]);

        $title_tag = $this->fancy_text_esc_options($ekit_fancy_text_title_tag, $options_ekit_text_title_tag, 'h2');

        $fancy_animation_settings = [
            'animationStyle' => 'animated',
            'animationDelay' => !empty($ekit_fancy_animation_delay) ? (int) $ekit_fancy_animation_delay : 2500,
            'loadingBar' => !empty($ekit_fancy_loading_bar) ? (int) $ekit_fancy_loading_bar : 3800,
            'lettersDelay' => !empty($ekit_fancy_letters_delay) ? (int) $ekit_fancy_letters_delay : 50,
            'typeLettersDelay' => !empty($ekit_fancy_type_letters_delay) ? (int) $ekit_fancy_type_letters_delay : 150,
            'duration' => !empty($ekit_fancy_selection_duration) ? (int) $ekit_fancy_selection_duration : 500,
            'revealDuration' => !empty($ekit_fancy_reveal_duration) ? (int) $ekit_fancy_reveal_duration : 600,
            'revealAnimationDelay' => !empty($ekit_fancy_reveal_animation_delay) ? (int) $ekit_fancy_reveal_animation_delay : 1500,
        ];

        $this->add_render_attribute('fancy-text-wrap', [
            'class' => ['ekit-fancy-text fancy-text-wrap', esc_attr($fancy_animation_type_class)],
            'data-id' => $this->get_id(),
            'data-animation-settings' => wp_json_encode($fancy_animation_settings),
        ]);

       if ( ! empty( $settings['show_fancy_text'] ) && 'yes' === $settings['show_fancy_text'] ) {
            $fancy_content = $this->get_fancy_content( $settings );

            if ( ! empty( $ekit_fancy_text_link['url'] ) ) {
                $this->add_link_attributes( 'link', $ekit_fancy_text_link );
                $fancy_content = sprintf(
                    '<a %1$s>%2$s</a>',
                    $this->get_render_attribute_string( 'link' ),
                    $fancy_content
                );
            }
            ?>
            <<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'fancy-text-wrap' ); ?>>
                <?php echo wp_kses( $fancy_content, $this->get_fancy_text_kses_array() ); ?>
            </<?php echo esc_attr( $title_tag ); ?>>
            <?php
        }
    }
}
?>