<?php
namespace SFWPStudio\Core\Helpers\Traits;
 
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
 
trait ListTrait {
 
    protected function register_list_controls( $enable_list = "yes",  $default_layout = "column" ) {
       
        //SF List
        $this->start_controls_section(
            'ekit_heading_section_extra_list',
            [
                'label' => esc_html__( 'SF List', 'sf-widget' ),
            ]
        );
        $this->add_control(
 
            'ekit_heading_section_extra_list_show',
            [
                'label' => esc_html__( 'Enable SF List', 'sf-widget' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => $enable_list,
                'label_on' => esc_html__( 'Show', 'sf-widget' ),
                'label_off' => esc_html__( 'Hide', 'sf-widget' ),
            ]
        );
 
       $this->add_responsive_control(
            'sf_list_display_style',
            [
                'label' => esc_html__( 'List Layout', 'sf-widget' ),
                'type' => Controls_Manager::SELECT,
                'default' => $default_layout,
                'options' => [
                    'row' => esc_html__( 'Row', 'sf-widget' ),
                    'column' => esc_html__( 'Column', 'sf-widget' ),
                ],
                'tablet_default' => 'column',
                'mobile_default' => 'column',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'flex-direction: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );
 
        $this->add_control(
            'sf_list_style',
            [
                'label' => __( 'List Style', 'sf-widget' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'bullet' => __( 'Bullet', 'sf-widget' ),
                    'number' => __( 'Numbered', 'sf-widget' ),
                    'icon'   => __( 'Icon/SVG', 'sf-widget' ),
                ],
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );
 
        $this->add_control(
            'sf_common_icon',
            [
                'label' => __( 'List Icon/SVG', 'sf-widget' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-check',
                    'library' => 'fa-solid',
                ],
                'condition' => [
                    'sf_list_style' => 'icon',
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );
 
        $repeater = new Repeater();
 
        $repeater->add_control(
            'sf_list_text',
            [
                'label' => __( 'Text', 'sf-widget' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Add your SF list item here', 'sf-widget' ),
                'dynamic' => ['active' => true],
            ]
        );
 
        $this->add_control(
            'sf_list_items',
            [
                'label' => __( 'List Items', 'sf-widget' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [ 'sf_list_text' => 'First SF item' ],
                ],
                'title_field' => '{{{ sf_list_text }}}',
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();
 
        // Style Section: SF List Style
        $this->start_controls_section(
            'ekit_heading_section_extra_list_style',
            [
                'label' => esc_html__( 'SF List', 'sf-widget' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'sf_list_flex_wrap',
            [
                'label' => esc_html__( 'Wrap Items', 'sf-widget' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'nowrap',
                'options' => [
                    'nowrap' => esc_html__( 'No Wrap', 'sf-widget' ),
                    'wrap' => esc_html__( 'Wrap', 'sf-widget' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'flex-wrap: {{VALUE}};',
                ],
                'condition' => [
                    'sf_list_display_style' => 'row',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_width',
            [
                'label' => esc_html__( 'Width', 'sf-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_gap',
            [
                'label' => esc_html__( 'Item Gap', 'sf-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_spacing_padding',
            [
                'label' => esc_html__( 'Padding', 'sf-widget' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_spacing_margin',
            [
                'label' => esc_html__( 'Margin', 'sf-widget' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_marker_spacing',
            [
                'label' => esc_html__( 'Marker Spacing', 'sf-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-list-marker' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
 
        // Icon Style
        $this->add_control(
            'sf_icon_styles_heading',
            [
                'label' => esc_html__( 'Icon/SVG Styles', 'sf-widget' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_icon_align',
            [
                'label' => esc_html__( 'Icon Vertical Alignment', 'sf-widget' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Top', 'sf-widget' ),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'sf-widget' ),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Bottom', 'sf-widget' ),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'align-self: {{VALUE}};',
                ],
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );
 
        $this->add_control(
            'sf_icon_inset_block_start',
            [
                'label' => esc_html__('Icon Inset Block Start', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'position: relative; inset-block-start: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );
 
        // Icon Normal and Hover Tabs
        $this->start_controls_tabs(
            'sf_icon_style_tabs',
            [
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );
 
        $this->start_controls_tab(
            'sf_icon_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'sf-widget' ),
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_icon_font_size',
            [
                'label' => esc_html__( 'Icon Size', 'sf-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'font-size: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper > :is(i, svg)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'sf-widget' ),
                'type' => Controls_Manager::COLOR,
                'default'=> '',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper > :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
 
        $this->end_controls_tab();
 
        $this->start_controls_tab(
            'sf_icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'sf-widget' ),
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_icon_scale_hover',
            [
                'label' => esc_html__( 'Icon Hover Scale', 'sf-widget' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0.5, 'max' => 2, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li:hover > .sf-icon-wrapper > :is(i, svg)' => 'transform: scale({{SIZE}});',
                ],
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_icon_color_hover',
            [
                'label' => esc_html__( 'Icon Hover Color', 'sf-widget' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li:hover > .sf-icon-wrapper > :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
 
        $this->end_controls_tab();
        $this->end_controls_tabs();
 
        // Text Styles
        $this->add_control(
            'sf_text_styles_heading',
            [
                'label' => esc_html__( 'Text Styles', 'sf-widget' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_text_align',
            [
                'label' => esc_html__( 'Text Vertical Alignment', 'sf-widget' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Top', 'sf-widget' ),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'sf-widget' ),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Bottom', 'sf-widget' ),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li p' => 'align-self: {{VALUE}};',
                ],
            ]
        );
 
        // Text Normal and Hover Tabs
        $this->start_controls_tabs('sf_text_style_tabs');
 
        $this->start_controls_tab(
            'sf_text_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'sf-widget' ),
            ]
        );
 
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sf_list_typography',
                'selector' => '{{WRAPPER}} .sf-custom-list li p',
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_color',
            [
                'label' => esc_html__( 'Text Color', 'sf-widget' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li p' => 'color: {{VALUE}};',
                ],
				'default' => '',
            ]
        );
 
        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'sf_list_text_shadow',
                'selector' => '{{WRAPPER}} .sf-custom-list li p',
            ]
        );
 
        $this->end_controls_tab();
 
        $this->start_controls_tab(
            'sf_text_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'sf-widget' ),
            ]
        );
 
        $this->add_responsive_control(
            'sf_list_color_hover',
            [
                'label' => esc_html__( 'Text Hover Color', 'sf-widget' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li:hover p' => 'color: {{VALUE}};',
                ],
            ]
        );
 
        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'sf_list_text_shadow_hover',
                'selector' => '{{WRAPPER}} .sf-custom-list li:hover p',
            ]
        );
 
        $this->end_controls_tab();
        $this->end_controls_tabs();
 
        $this->end_controls_section();
        //SF List Style Control End
 
    }
 
    protected function render_list() {
        $settings = $this->get_settings_for_display();
        if ( $settings['ekit_heading_section_extra_list_show'] === 'yes' && !empty($settings['sf_list_items']) && is_array($settings['sf_list_items'])) : ?>
            <ul class="sf-custom-list" style="display: flex; list-style-type: none;">
                <?php foreach ($settings['sf_list_items'] as $index => $item) : ?>
                    <li style="display: flex;">
                        <?php
                        switch ($settings['sf_list_style']) {
                            case 'number':
                                echo '<span class="sf-list-marker">' . ($index + 1) . '. </span>';
                                break;
                            case 'bullet':
                                echo '<span class="sf-list-marker">• </span>';
                                break;
                            case 'icon':
                                if (!empty($settings['sf_common_icon']['value'])) {
                                    ?>
                                    <span class="sf-icon-wrapper" style="display: flex;">
                                        <?php Icons_Manager::render_icon($settings['sf_common_icon'], ['aria-hidden' => 'true']); ?>
                                    </span>
                                    <?php
                                }
                                break;
                        }
                        ?>
                        <p class="sf-list-text" style="margin: 0;"><?php echo wp_kses($item['sf_list_text'], array('a' => array('class' => array(), 'href' => array(), 'rel' => array(), 'title' => array(), 'target' => array(), 'style' => array()))); ?></p>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif;
    }
}