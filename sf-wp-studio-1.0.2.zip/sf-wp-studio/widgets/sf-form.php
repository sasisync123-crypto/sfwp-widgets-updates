<?php
// silence  is more powerful