<?php
namespace SFWPStudio\Widgets;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if (!defined('ABSPATH')) exit;

class Sf_Toc extends Widget_Base {

    public function get_name() {
        return 'sf-toc';
    }

    public function get_title() {
        return __('Arun 2 Toc', 'sf-widgets');
    }

    public function get_icon() {
        return 'sync-widget-icon eicon-table-of-contents';
    }

    public function get_keywords() {
        return ['sf', 'SF Toc'];
    }

    public function get_style_depends() {
    return [ 'sf-toc' ];
}
    public function get_script_depends() {
    return [ 'sf-toc' ];
}

    public function get_categories() {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool {
        return false;
    }

    protected function register_controls() {
        /* ---------- 1. TABLE OF CONTENTS ---------- */
        $this->start_controls_section(
            'table_of_contents',
            [ 'label' => esc_html__( 'Table of Contents', 'sf-widget' ) ]
        );

        $this->add_control(
            'show_title',
            [
                'label'     => esc_html__( 'Show Title', 'sf-widget' ),
                'type'      => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'   => 'yes'
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__( 'Title', 'sf-widget' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [ 'active' => true ],
                'label_block' => true,
                'default'     => esc_html__( 'Table of Contents', 'sf-widget' ),
                'condition' => ['show_title' => 'yes']
            ]
        );

        $this->add_control(
            'show_title_icon',
            [
                'label'     => esc_html__( 'Add Title Icon?', 'sf-widget' ),
                'type'      => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'   => 'yes',
                'condition' => ['show_title' => 'yes']
            ]
        );

        $this->add_control(
            'title_icon',
            [
                'label'     => __( 'Title Icon', 'sf-widget' ),
                'type'      => Controls_Manager::ICONS,
                'default'   => [
                    'value'   => 'fas fa-list',
                    'library' => 'fa-solid',
                ],
                'condition' => [ 'show_title_icon' => 'yes', 'show_title' => 'yes' ],
            ]
        );

        $this->add_control(
            'html_tag',
            [
                'label'   => esc_html__( 'HTML Tag', 'sf-widget' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'h2'  => 'H2',
                    'h3'  => 'H3',
                    'h4'  => 'H4',
                    'h5'  => 'H5',
                    'h6'  => 'H6',
                    'div' => 'div',
                ],
                'default' => 'h6',
                'condition' => ['show_title' => 'yes']
            ]
        );

        /* ----- Include / Exclude tabs ----- */
        $this->start_controls_tabs( 'include_exclude_tags', [ 'separator' => 'before' ] );
        $this->start_controls_tab( 'include', [ 'label' => esc_html__( 'Include', 'sf-widget' ) ] );
        $this->add_control(
            'headings_by_tags',
            [
                'label'       => esc_html__( 'Anchors By Tags', 'sf-widget' ),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'default'     => [ 'h2', 'h3', 'h4', 'h5', 'h6' ],
                'options'     => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                ],
                'label_block' => true,
                'frontend_available' => true,
            ]
        );
        $this->add_control(
            'container',
            [
                'label'       => esc_html__( 'Container', 'sf-widget' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'description' => esc_html__( 'Confine TOC to headings under this container (CSS selector)', 'sf-widget' ),
                'frontend_available' => true,
            ]
        );
        $this->end_controls_tab(); // include
        $this->start_controls_tab( 'exclude', [ 'label' => esc_html__( 'Exclude', 'sf-widget' ) ] );
        $this->add_control(
            'exclude_headings_by_selector',
            [
                'label'       => esc_html__( 'Anchors By Selector', 'sf-widget' ),
                'type'        => Controls_Manager::TEXT,
                'description' => esc_html__( 'CSS selectors, in a comma-separated list', 'sf-widget' ),
                'label_block' => true,
                'frontend_available' => true,
            ]
        );
        $this->end_controls_tab(); // exclude
        $this->end_controls_tabs(); // include_exclude_tags

        /* ----- Marker view ----- */
        $this->add_control(
            'marker_view',
            [
                'label'   => esc_html__( 'Marker View', 'sf-widget' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'numbers',
                'options' => [
                    'none'    => esc_html__( 'None', 'sf-widget' ),
                    'numbers' => esc_html__( 'Numbers', 'sf-widget' ),
                    'bullets' => esc_html__( 'Bullets', 'sf-widget' ),
                ],
                'separator' => 'before',
                'frontend_available' => true,
            ]
        );
        $this->add_control(
            'icon',
            [
                'label'   => esc_html__( 'Icon', 'sf-widget' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'fas fa-circle',
                    'library' => 'fa-solid',
                ],
                'condition' => [ 'marker_view' => 'bullets' ],
                'skin'      => 'inline',
                'label_block' => false,
                'exclude_inline_options' => [ 'svg' ],
                'frontend_available' => true,
            ]
        );
        $this->add_control(
            'custom_marker_text',
            [
                'label'       => esc_html__( 'Custom Marker Text', 'sf-widget' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => '',
                'description' => esc_html__( 'Override bullets/numbers with custom text (e.g., "right arrow"). Leave empty for default.', 'sf-widget' ),
                'frontend_available' => true,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'no_headings_message',
            [
                'label'       => esc_html__( 'No Headings Found Message', 'sf-widget' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'No headings were found on this page.', 'sf-widget' ),
                'dynamic'     => [ 'active' => true ],
                'label_block' => true,
                'separator'   => 'before',
                'frontend_available' => true,
            ]
        );
        $this->end_controls_section(); // table_of_contents

        /* ---------- 2. ADDITIONAL OPTIONS ---------- */
        $this->start_controls_section(
            'additional_options',
            [ 'label' => esc_html__( 'Additional Options', 'sf-widget' ) ]
        );
        $this->add_control(
            'word_wrap',
            [
                'label'        => esc_html__( 'Word Wrap', 'sf-widget' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'return_value' => 'ellipsis',
                'prefix_class' => 'elementor-toc--content-',
            ]
        );
        $this->add_control(
            'minimize_box',
            [
                'label'   => esc_html__( 'Minimize Box', 'sf-widget' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'frontend_available' => true,
                'separator' => 'before',
                'condition' => [ 'show_title' => 'yes' ],
            ]
        );
        $this->add_control(
            'expand_icon',
            [
                'label'   => esc_html__( 'Expand Icon', 'sf-widget' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'fas fa-chevron-down',
                    'library' => 'fa-solid',
                ],
                'condition' => [ 'show_title' => 'yes', 'minimize_box' => 'yes', ],
            ]
        );
        $this->add_control(
            'collapse_icon',
            [
                'label'   => esc_html__( 'Collapse Icon', 'sf-widget' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'fas fa-chevron-up',
                    'library' => 'fa-solid',
                ],
                'condition' => [ 'show_title' => 'yes', 'minimize_box' => 'yes', ],
            ]
        );
        $this->add_control(
            'hierarchical_view',
            [
                'label'   => esc_html__( 'Hierarchical View', 'sf-widget' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'frontend_available' => true,
                'separator' => 'before',
            ]
        );
        $this->end_controls_section(); // additional_options

        /* ---------- 3. STYLE – Box ---------- */
        $this->start_controls_section(
            'box_style',
            [ 'label' => esc_html__( 'Box', 'sf-widget' ), 'tab' => Controls_Manager::TAB_STYLE ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'background',
                'label'    => esc_html__( 'Background', 'sf-widget' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .sf-toc-widget-container',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'border',
                'label'    => esc_html__( 'Border', 'sf-widget' ),
                'selector' => '{{WRAPPER}} .sf-toc-widget-container',
            ]
        );
        $this->add_responsive_control(
            'border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc-widget-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [ 'border_border!' => '' ],
            ]
        );
        $this->add_responsive_control(
            'header_separator_width',
            [
                'label'     => esc_html__( 'Separator Spacing', 'sf-widget' ),
                'type'      => Controls_Manager::SLIDER,
                'size_units'=> [ 'px','%', 'em', 'rem', 'custom' ],
                'selectors' => [ '{{WRAPPER}} .sf-toc-widget-container .sf-toc__body' => 'margin-top: {{SIZE}}{{UNIT}};'],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_padding',
            [
                'label'      => __( 'Padding', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc-widget-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_margin',
            [
                'label'      => __( 'Margin', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc-widget-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'width',
            [
                'label'      => esc_html__( 'Width', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'em', 'rem', 'vh', 'custom' ],
                'range'      => [ 'px' => [ 'max' => 1460 ] ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc-widget-container' => 'width: {{SIZE}}{{UNIT}};'],
                'frontend_available' => true,
            ]
        );
        $this->add_responsive_control(
            'sf_toc_height',
            [
                'label'      => esc_html__( 'Height', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'em', 'rem', 'vh', 'custom' ],
                'range'      => [ 'px' => [ 'max' => 1000 ] ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc-widget-container .sf-toc__body' => 'height: {{SIZE}}{{UNIT}};'],
                'frontend_available' => true,
            ]
        );
        $this->add_responsive_control(
            'sf_toc_min_height',
            [
                'label'      => esc_html__( 'Min Height', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'em', 'rem', 'vh', 'custom' ],
                'range'      => [ 'px' => [ 'max' => 1000 ] ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc-widget-container .sf-toc__body' => 'min-height: {{SIZE}}{{UNIT}};'],
                'frontend_available' => true,
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'box_shadow', 'selector' => '{{WRAPPER}} .sf-toc-widget-container' ]
        );
        $this->end_controls_section(); // box_style

        /* ---------- 4. STYLE – Header ---------- */
        $this->start_controls_section(
            'header_style',
            [ 'label' => esc_html__( 'Header', 'sf-widget' ), 'tab' => Controls_Manager::TAB_STYLE,
            'condition' => ['show_title' => 'yes']
            ]
        );
        $logical_start = is_rtl() ? 'right' : 'left';
        $logical_end   = is_rtl() ? 'left'  : 'right';
        $this->add_responsive_control(
            'header_text_align',
            [
                'label'   => esc_html__( 'Text Align', 'sf-widget' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'start'  => [ 'title' => esc_html__( 'Start', 'sf-widget' ), 'icon' => "eicon-text-align-$logical_start" ],
                    'center' => [ 'title' => esc_html__( 'Center', 'sf-widget' ), 'icon' => 'eicon-text-align-center' ],
                    'end'    => [ 'title' => esc_html__( 'End', 'sf-widget' ),   'icon' => "eicon-text-align-$logical_end" ],
                ],
                'default'   => 'start',
                'selectors' => [ '{{WRAPPER}} .sf-toc__header-title' => 'justify-content: {{VALUE}};'],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_header_padding',
            [
                'label'      => __( 'Padding', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_header_margin',
            [
                'label'      => __( 'Margin', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'header_background_color',
                'label'    => esc_html__( 'Background', 'sf-widget' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .sf-toc__header',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'header_border',
                'label'    => esc_html__( 'Border', 'sf-widget' ),
                'selector' => '{{WRAPPER}} .sf-toc__header',
            ]
        );
        $this->add_responsive_control(
            'header_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc__header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [ 'header_border_border!' => '' ],
            ]
        );
        $this->add_control(
            'header_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'sf-widget' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .sf-toc__header-title' => 'color: {{VALUE}};'],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'header_typography',
                'selector' => '{{WRAPPER}} .sf-toc__header, {{WRAPPER}} .sf-toc__header-title',
            ]
        );
        $this->add_responsive_control(
            'heading_title_gap',
            [
                'label'      => esc_html__( 'Gap', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'vw', 'custom' ],
                'range'      => [ 'px' => [ 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__header-title' => 'column-gap: {{SIZE}}{{UNIT}};'],
            ]
        );
        $this->add_control(
            'header_icon_unique_style_enable',
            [
                'label'     => esc_html__( 'Heading Icon Style', 'sf-widget' ),
                'type'      => Controls_Manager::SWITCHER,
                'condition' => [ 'show_title_icon' => 'yes' ],
            ]
        );
        $this->add_control(
            'header_icon_color',
            [
                'label'     => esc_html__( 'Icon Color', 'sf-widget' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'header_icon_unique_style_enable' => 'yes', 'show_title_icon' => 'yes' ],
                'selectors' => [ '{{WRAPPER}} .sf-toc__header-title > :is(i, svg)' => 'color: {{VALUE}};'],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'header_icon_typography',
                'selector'  => '{{WRAPPER}} .sf-toc__header-title > :is(i, svg)',
                'condition' => [ 'header_icon_unique_style_enable' => 'yes', 'show_title_icon' => 'yes' ],
            ]
        );
        $this->add_control(
            'header_toggle_button_style',
            [
                'label'     => esc_html__( 'Expand/Collapse Icon Style', 'sf-widget' ),
                'type'      => Controls_Manager::HEADING,
                'condition' => [ 'show_title' => 'yes', 'minimize_box' => 'yes', ],
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'toggle_button_color',
            [
                'label'     => esc_html__( 'Icon Color', 'sf-widget' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [ 'show_title' => 'yes', 'minimize_box' => 'yes', ],
                'selectors' => [ '{{WRAPPER}} .sf-toc__toggle-button' => 'color: {{VALUE}};'],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'expand_collapse_typography',
                'selector'  => '{{WRAPPER}} .sf-toc__toggle-button > :is(i, svg)',
                'condition' => [ 'show_title' => 'yes', 'minimize_box' => 'yes', ],
            ]
        );
        $this->add_responsive_control(
            'toggle_button_position',
            [
                'label'   => esc_html__( 'Icon Position', 'sf-widget' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'row-reverse' => [ 'title' => esc_html__( 'Start', 'sf-widget' ), 'icon' => "eicon-h-align-$logical_start" ],
                    'row'         => [ 'title' => esc_html__( 'End', 'sf-widget' ),   'icon' => "eicon-h-align-$logical_end" ],
                ],
                'default'   => 'row',
                'toggle'    => false,
                'selectors' => [ '{{WRAPPER}} .sf-toc__header' => 'flex-direction: {{VALUE}};'],
                'condition' => [ 'show_title' => 'yes', 'minimize_box' => 'yes', ],
            ]
        );
        $this->add_responsive_control(
            'heading_gap',
            [
                'label'      => esc_html__( 'Gap', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'vw', 'custom' ],
                'range'      => [ 'px' => [ 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__header' => 'column-gap: {{SIZE}}{{UNIT}};'],
                'condition'  => [  'show_title' => 'yes', 'minimize_box' => 'yes', 'toggle_button_position' => 'row-reverse', ],
            ]
        );
        $this->end_controls_section(); // header_style

        /* ---------- 5. STYLE – Body / List ---------- */
        $this->start_controls_section(
            'list_style',
            [ 'label' => esc_html__( 'Body', 'sf-widget' ), 'tab' => Controls_Manager::TAB_STYLE ]
        );
        $this->add_responsive_control(
            'toc_wrapper_list_container_padding',
            [
                'label'      => __( 'List Container Padding', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_list_container_margin',
            [
                'label'      => __( 'List Container Margin', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__body' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'body_background_color',
                'label'    => esc_html__( 'Background', 'sf-widget' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .sf-toc__body',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'body_border',
                'label'    => esc_html__( 'Border', 'sf-widget' ),
                'selector' => '{{WRAPPER}} .sf-toc__body',
            ]
        );
        $this->add_responsive_control(
            'body_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc__body' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [ 'body_border_border!' => '' ],
            ]
        );
        $this->add_control(
            'list_item_styles',
            [
                'label'     => esc_html__( 'List Style', 'sf-widget' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'list_typography',
                'selector' => '{{WRAPPER}} .sf-toc__list-item',
            ]
        );
        $this->add_responsive_control(
            'list_indent',
            [
                'label'      => esc_html__( 'Indent', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'custom' ],
                'default'    => [ 'unit' => 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-list-indent: {{SIZE}}{{UNIT}};'],
                'condition'  => [ 'hierarchical_view' => 'yes' ],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_list_item_padding',
            [
                'label'      => __( 'Padding', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );
        $this->add_responsive_control(
            'toc_wrapper_list_item_margin',
            [
                'label'      => __( 'Margin', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__list-item > a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        /* ----- Item text (normal / hover / active) ----- */
        $this->start_controls_tabs( 'item_text_style' );
        $this->start_controls_tab( 'normal', [ 'label' => esc_html__( 'Normal', 'sf-widget' ) ] );
        $this->add_control(
            'item_text_color_normal',
            [
                'label'     => esc_html__( 'Text Color', 'sf-widget' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .sf-toc__list-item > a' => 'color: {{VALUE}};'],
            ]
        );
        $this->add_control(
            'item_text_underline_normal',
            [
                'label'     => esc_html__( 'Underline', 'sf-widget' ),
                'type'      => Controls_Manager::SWITCHER,
                'selectors' => [ '{{WRAPPER}} .sf-toc__list-item > a' => 'text-decoration: underline;'],
            ]
        );
        $this->end_controls_tab(); // normal

        $this->start_controls_tab( 'hover', [ 'label' => esc_html__( 'Hover', 'sf-widget' ) ] );
        $this->add_control(
            'item_text_color_hover',
            [
                'label'     => esc_html__( 'Text Color', 'sf-widget' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .sf-toc__list-item > a:hover' => 'color: {{VALUE}};'],
            ]
        );
        $this->add_control(
            'item_text_underline_hover',
            [
                'label'     => esc_html__( 'Underline', 'sf-widget' ),
                'type'      => Controls_Manager::SWITCHER,
                'selectors' => [ '{{WRAPPER}} .sf-toc__list-item > a:hover' => 'text-decoration: underline;'],
            ]
        );
        $this->add_control(
            'item_text_hover_transition_duration',
            [
                'label'      => esc_html__( 'Transition Duration', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 's', 'ms', 'custom' ],
                'default'    => [ 'unit' => 'ms' ],
                'selectors'  => [ '{{WRAPPER}}' => '--item-text-transition-duration: {{SIZE}}{{UNIT}};'],
            ]
        );
        $this->end_controls_tab(); // hover

        $this->start_controls_tab( 'active', [ 'label' => esc_html__( 'Active', 'sf-widget' ) ] );
        $this->add_control(
            'list_item_active_bg_style',
            [
                'label'     => esc_html__( 'Background Style', 'sf-widget' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'item_bg_color_active',
                'label'    => esc_html__( 'Background', 'sf-widget' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .sf-toc__list-item .sf-toc__link--active',
            ]
        );
        $this->add_control(
            'item_text_color_active',
            [
                'label'     => esc_html__( 'Text Color', 'sf-widget' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .sf-toc__list-item .sf-toc__link--active' => 'color: {{VALUE}};'],
            ]
            );
            $this->add_control(
                'item_active_border_type',
                [
                    'label'   => esc_html__( 'Border Type', 'sf-widget' ),
                    'type'    => Controls_Manager::SELECT,
                    'options' => [
                        'normal'  => 'Normal',
                        'gradient'  => 'Gradient',
                    ],
                    'default' => 'gradient',
                    'prefix_class' => 'sf-toc__active-border-'
                ]
                );

                $this->add_group_control(
                    Group_Control_Border::get_type(),
                    [
                        'name'     => 'item_active_normal_border',
                        'label'    => esc_html__( 'Border', 'sf-widget' ),
                        'selector' => '{{WRAPPER}} .sf-toc__list-item .sf-toc__link--active',
                        'condition' => ['item_active_border_type' => 'normal']
                    ]
                );

                $this->add_responsive_control(
                    'item_active_gradient_border_width',
                    [
                        'label'      => esc_html__( 'Gradient Border Width', 'sf-widget' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', 'em', 'rem', 'custom' ],
                        'range'      => [
                            'px' => [
                                'min'  => 0,
                                'max'  => 5,
                                'step' => 1, // Optional: makes it snap to whole numbers
                            ],
                        ],
                        'selectors'  => [
                            '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-active-grad-padding: {{SIZE}}{{UNIT}};',
                        ],
                        'condition' => ['item_active_border_type' => 'gradient']
                    ]
                    );

            $this->add_control(
                'item_active_gradient_direction',
                [
                    'label'   => __( 'Gradient Direction', 'sf-widget' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'to top right',
                    'options' => [
                        'to left'            => 'Left → Right',
                        'to right'           => 'Right → Left',
                        'to top'             => 'Bottom → Top',
                        'to bottom'          => 'Top → Bottom',
                        'to top left'        => 'Bottom-Right → Top-Left',
                        'to top right'       => 'Bottom-Left → Top-Right',
                        'to bottom left'     => 'Top-Right → Bottom-Left',
                        'to bottom right'    => 'Top-Left → Bottom-Right',
                    ],
                    'condition' => ['item_active_border_type' => 'gradient'],
                    'selectors' => [
                        '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-active-grad-direction: {{VALUE}};',
                    ],
                ]
            );
         
            $this->add_control(
                'item_active_gradient_color_1',
                [
                    'label'     => __( 'Gradient Color 1', 'sf-widget' ),
                    'type'      => Controls_Manager::COLOR,
                    // 'default'   => 'var(--color-border-glow)',
                    'condition' => ['item_active_border_type' => 'gradient'],
                    'selectors' => [
                        '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-active-grad-color-1: {{VALUE}};',
                    ],
                ]
            );
         
            $this->add_control(
                'item_active_gradient_color_2',
                [
                    'label'     => __( 'Gradient Color 2', 'sf-widget' ),
                    'type'      => Controls_Manager::COLOR,
                    // 'default'   => 'var(--color-border-soft)',
                    'condition' => ['item_active_border_type' => 'gradient'],
                    'selectors' => [
                        '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-active-grad-color-2: {{VALUE}};',
                    ],
                ]
            );
           
            $this->add_control(
                'item_active_gradient_color_3',
                [
                    'label'     => __( 'Gradient Color 3', 'sf-widget' ),
                    'type'      => Controls_Manager::COLOR,
                    // 'default'   => 'var(--color-border-glow)',
                    'condition' => ['item_active_border_type' => 'gradient'],
                    'selectors' => [
                        '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-active-grad-color-3: {{VALUE}};',
                    ],
                ]
            );

        $this->add_responsive_control(
            'toc_wrapper_list_item_border_radius',
            [
                'label'      => __( 'Border Radius', 'sf-widget' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc-widget-container' => '--sf-toc-active-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab(); // active
        $this->end_controls_tabs(); // item_text_style

        $this->add_control(
            'heading_marker',
            [
                'label'     => esc_html__( 'Marker', 'sf-widget' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'marker_view!' => 'none' ],
            ]
        );
        $this->add_responsive_control(
            'marker_size',
            [
                'label'      => esc_html__( 'Size', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'custom' ],
                'selectors'  => [
                    '{{WRAPPER}} .sf-toc__marker' => 'font-size: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sf-toc__marker > :is(i, svg)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [ 'marker_view!' => 'none' ],
            ]
        );
        $this->add_responsive_control(
            'marker_spacing',
            [
                'label'      => esc_html__( 'Marker Spacing', 'sf-widget' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem' ],
                'range'      => [ 'px' => [ 'min' => 1, 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .sf-toc__list-item > a' => 'gap: {{SIZE}}{{UNIT}};'],
                'condition' => [ 'marker_view!' => 'none' ],
            ]
        );
        $this->add_responsive_control(
            'marker_align',
            [
                'label'   => esc_html__( 'Vertical Alignment', 'sf-widget' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [ 'title' => esc_html__( 'Top', 'sf-widget' ),    'icon' => 'eicon-v-align-top' ],
                    'center'     => [ 'title' => esc_html__( 'Center', 'sf-widget' ),'icon' => 'eicon-v-align-middle' ],
                    'flex-end'   => [ 'title' => esc_html__( 'Bottom', 'sf-widget' ),'icon' => 'eicon-v-align-bottom' ],
                ],
                'default'   => 'center',
                'selectors' => [ '{{WRAPPER}} .sf-toc__marker' => 'align-self: {{VALUE}};'],
                'condition' => [ 'marker_view!' => 'none' ],
            ]
        );
        $this->end_controls_section(); // list_style
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $toc_id   = 'sf-toc__' . $this->get_id();

        $this->add_render_attribute( 'header', 'class', 'sf-toc__header' );
        $this->add_render_attribute( 'body', [
            'id'   => $toc_id,
            'class'=> 'sf-toc__body',
            'data-settings' => wp_json_encode( [
                'headings_by_tags'            => $settings['headings_by_tags'],
                'exclude_headings_by_selector'=> $settings['exclude_headings_by_selector'],
                'container'                   => $settings['container'] ?: 'body',
                'hierarchical_view'           => $settings['hierarchical_view'],
                'marker_view'                 => $settings['marker_view'],
                'custom_marker_text'          => $settings['custom_marker_text'],
                'icon'                        => $settings['icon']['value'] ?? '',
                'no_headings_message'         => $settings['no_headings_message'],
                'minimize_box'                => $settings['minimize_box'],
                'expand_icon'                 => $settings['expand_icon'],
                'collapse_icon'               => $settings['collapse_icon'],
            ] ),
        ] );

        if ( 'yes' === $settings['hierarchical_view'] ) {
            $this->add_render_attribute( 'body', 'class', 'sf-toc--hierarchical' );
        }

        $html_tag = Utils::validate_html_tag( $settings['html_tag'] );
        ?>
        <div class="sf-toc-widget-container">
            <?php if ( $settings['show_title'] === 'yes') : ?>
                <div <?php echo $this->get_render_attribute_string( 'header' ); ?>>
                    <<?php echo $html_tag; ?> class="sf-toc__header-title">
                        <?php if ( $settings['show_title_icon'] === 'yes' ) : ?>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['title_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        <?php endif; ?>
                        <?php echo esc_html( $settings['title'] ); ?>
                    </<?php echo $html_tag; ?>>
                    <?php if ( 'yes' === $settings['minimize_box'] ) : ?>
                        <div class="sf-toc__toggle-button sf-toc__toggle-button--expand" role="button" tabindex="0"
                            aria-controls="<?php echo esc_attr( $toc_id ); ?>" aria-expanded="true"
                            aria-label="<?php esc_attr_e( 'Open table of contents', 'sf-widget' ); ?>">
                            <?php Icons_Manager::render_icon( $settings['expand_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </div>
                        <div class="sf-toc__toggle-button sf-toc__toggle-button--collapse" role="button" tabindex="0"
                            aria-controls="<?php echo esc_attr( $toc_id ); ?>" aria-expanded="true"
                            aria-label="<?php esc_attr_e( 'Close table of contents', 'sf-widget' ); ?>">
                            <?php Icons_Manager::render_icon( $settings['collapse_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div <?php echo $this->get_render_attribute_string( 'body' ); ?>>
                <ul class="sf-toc__list"></ul>
            </div>
        </div>
        <?php
    }
}
