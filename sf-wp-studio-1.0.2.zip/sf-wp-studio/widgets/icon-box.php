<?php
namespace SFWPStudio\Widgets;

if (!defined('ABSPATH'))
    exit;

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Control_Media;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;

class Icon_Box extends Widget_Base
{
    use \ElementsKit_Lite\Widgets\Widget_Notice;

    //start
    public function get_name()
    {
        return 'sf-icon-box';
    }

    public function get_title()
    {
        return __('SF Icon Box', 'sf-widgets');
    }

    public function get_icon()
    {
        return 'sync-widget-icon eicon-tabs';
    }

    public function get_keywords()
    {
        return ['sf', 'icon', 'box'];
    }

    public function get_script_depends()
    {
        return ['icon-box'];
    }

    //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS
    protected function register_controls()
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Division', 'sf-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'global_item_width',
            [
                'label' => esc_html__('Box Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'em', 'rem'],
                'range' => [
                    '%' => ['min' => 10, 'max' => 100],
                    'px' => ['min' => 50, 'max' => 1000],
                ],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container > div' => 'width: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'global_item_height',
            [
                'label' => esc_html__('Box Height', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh', 'auto'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 1000],
                    '%' => ['min' => 10, 'max' => 100],
                    'vh' => ['min' => 10, 'max' => 100],
                    // 'auto' doesn't need range — it's a keyword
                ],
                'default' => [
                    'unit' => 'auto',  // This makes "Auto" the default
                ],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-item > div' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box_text_align_responsive',
            [
                'label' => esc_html__('Content Alignment', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'toggle' => true,
                'separator' => 'before',
                'default' => 'left',
            ]
        );

        $this->add_control(
            'ekit_icon_Icon_Width_Separator20',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'ekit_icon_Icon_Width_',
            [
                'label' => esc_html__('Division Controls ', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'custom_icon_background_1',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],          // color + gradient
                'selector' => '{{WRAPPER}} .my-flex-container',
                'condition' => [
                    'background_style' => 'custom',
                ],
                // ---- ADD IMAGE SUPPORT ----
                'fields_options' => [
                    // Enable the image tab
                    'background' => [
                        'frontend_available' => true,
                    ],
                    // (Optional) Default image, size, position, etc.
                    'image' => [
                        'label' => esc_html__('Background Image', 'sf-widget'),
                    ],
                    'size' => [
                        'label' => esc_html__('Size', 'sf-widget'),
                    ],
                    'position' => [
                        'label' => esc_html__('Position', 'sf-widget'),
                    ],
                    'attachment' => [
                        'label' => esc_html__('Attachment', 'sf-widget'),
                    ],
                    'repeat' => [
                        'label' => esc_html__('Repeat', 'sf-widget'),
                    ],
                ],
            ]
        );

        // Flex Direction
        $this->add_responsive_control(
            'flex_direction',
            [
                'label' => __('Flex Direction', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'row',
                'tablet_default' => 'row',
                'mobile_default' => 'column',
                'options' => [
                    'row' => __('Row', 'sf-widget'),
                    'row-reverse' => __('Row Reverse', 'sf-widget'),
                    'column' => __('Column', 'sf-widget'),
                    'column-reverse' => __('Column Reverse', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

        // Justify Content (for row directions)
        $this->add_responsive_control(
            'justify_content',
            [
                'label' => __('Justify Content', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'center',
                'options' => [
                    'flex-start' => __('Start', 'sf-widget'),
                    'center' => __('Center', 'sf-widget'),
                    'flex-end' => __('End', 'sf-widget'),
                    'space-between' => __('Space Between', 'sf-widget'),
                    'space-around' => __('Space Around', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
                    'flex_direction' => ['row', 'row-reverse'],
                ],
            ]
        );

        // Align Items (for column directions)
        $this->add_responsive_control(
            'align_items',
            [
                'label' => __('Align Items', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'center',
                'options' => [
                    'flex-start' => __('Start', 'sf-widget'),
                    'center' => __('Center', 'sf-widget'),
                    'flex-end' => __('End', 'sf-widget'),
                    'stretch' => __('Stretch', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container' => 'align-items: {{VALUE}};',
                ],
                'condition' => [
                    'flex_direction' => ['column', 'column-reverse'],
                ],
            ]
        );

        // Gap
        $this->add_responsive_control(
            'flex_gap',
            [
                'label' => __('Gap', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                ],
                'default' => [
                    'size' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'flex_padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'flex_margin',
            [
                'label' => __('Margin', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .my-flex-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        //SF Icon Box Settings

        $this->start_controls_section(
            'sf_icon_box_section',
            [
                'label' => esc_html__('Icon Boxes', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_Icon_title_',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'ekit_icon_box_enable_title_show',
            [
                'label' => esc_html__('Enable Title', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'ekit_icon_box_enable_description_show',
            [
                'label' => esc_html__('Enable Description', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_button_sf_controls',
            [
                'label' => esc_html__('Show Button', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'ekit_icon_box_enable_icon_show',
            [
                'label' => esc_html__('Enable Icon', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'ekit_icon_box_icon_position',
            [
                'label' => esc_html__('Icon Layout ', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => esc_html__('Horizontal', 'sf-widget'),
                    'left' => esc_html__('Float Left', 'sf-widget'),
                    // 'right' => esc_html__( 'Right', 'sf-widget' ),
                ],
                'condition' => [
                    'ekit_icon_box_enable_icon_show' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_padding_value',
            [
                'label' => esc_html__('Icon Gap', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .left-section' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_enable_icon_show' => 'yes',
                    'ekit_icon_box_icon_position' => ['left'],
                ],
            ]
        );
        
        $this->add_control(
            'box_footer_margin_top',
            [
                'type' => \Elementor\Controls_Manager::HIDDEN,
                'default' => '15px',
                'selectors' => [
                    '{{WRAPPER}} .box-footer' => 'margin-top: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_Icon_Width_Separator3',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'ekit_icon_sf_list_title',
            [
                'label' => esc_html__('List', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );
        //Enable List
        $this->add_control(
            'ekit_heading_section_extra_list_show',
            [
                'label' => esc_html__('Enable List', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
            ]
        );

        $this->add_control(
            'sf_list_display_style',
            [
                'label' => esc_html__('List Layout', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'sf-widget'),
                    'column' => esc_html__('Column', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'flex-direction: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'sf_list_style',
            [
                'label' => __('List Style', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'bullet' => __('Bullet', 'sf-widget'),
                    'number' => __('Numbered', 'sf-widget'),
                    'icon' => __('Icon/SVG', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'sf_common_icon',
            [
                'label' => __('List Icon/SVG', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-check',
                    'library' => 'fa-solid',
                ],
                'condition' => [
                    'sf_list_style' => 'icon',
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );
        do_action('sf_svg',$this);
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ekit_icon_box-add-icon',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );


        $repeater->add_control(
            'ekit_icon_box_enable_header_icon',
            [
                'label' => esc_html__('Icon Type', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options' => [
                    'none' => [
                        'title' => esc_html__('None', 'sf-widget'),
                        'icon' => 'fa fa-ban',
                    ],
                    'icon' => [
                        'title' => esc_html__('Icon', 'sf-widget'),
                        'icon' => 'fa fa-paint-brush',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'sf-widget'),
                        'icon' => 'fa fa-image',
                    ],
                ],
                'default' => 'icon',
            ]
        );

        $repeater->add_control(
            'ekit_icon_box_header_icons',
            [
                'label' => esc_html__('Header Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_icon_box_header_icon',
                'default' => [
                    'value' => 'icon icon-review',
                    'library' => 'ekiticons',
                ],
                'label_block' => true,
                'condition' => [
                    'ekit_icon_box_enable_header_icon' => 'icon',
                ]
            ]
        );

        $repeater->add_control(
            'ekit_icon_box_header_image',
            [
                'label' => esc_html__('Choose Image', 'sf-widget'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                    'id' => -1
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'ekit_icon_box_enable_header_icon' => 'image',
                ]
            ]
        );

        $repeater->add_control(
            'ekit_icon_Icon_Width_Separator8',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $repeater->add_control(
            'ekit_icon_box-edit-text',
            [
                'label' => esc_html__('Edit Text', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $repeater->add_control(
            'ekit_icon_box_title_text',
            [
                'label' => esc_html__('Title ', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => esc_html__('Strategy and  Planning', 'sf-widget'),
                'placeholder' => esc_html__('Enter your title', 'sf-widget'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'ekit_icon_box_description_text',
            [
                'label' => esc_html__('Content', 'sf-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => esc_html__('We bring the right people together to challenge established thinking and drive transform in 2020', 'sf-widget'),
                'placeholder' => esc_html__('Enter your description', 'sf-widget'),
                'rows' => 10,
                'show_label' => false,
            ]
        );
        //SF List Text

        $repeater->add_control(
            'sf_list_text1',
            [
                'label' => __('List Item 1', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => __('First SF item', 'sf-widget'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'sf_list_text2',
            [
                'label' => __('List Item 2', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Second exciting item', 'sf-widget'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'sf_list_text3',
            [
                'label' => __('List Item 3', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Third awesome item', 'sf-widget'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'ekit_icon_Icon_Width_Separator10',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $repeater->add_control(
            'ekit_icon_box-badget',
            [
                'label' => esc_html__('Badge', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $repeater->add_control(
            'ekit_icon_box_badge_control',
            [
                'label' => esc_html__('Show Badge', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'sf-widget'),
                'label_off' => esc_html__('Hide', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $repeater->add_control(
            'ekit_icon_box_badge_title',
            [
                'label' => esc_html__('Title', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => esc_html__('EXCLUSIVE', 'sf-widget'),
                'placeholder' => esc_html__('Type your title here', 'sf-widget'),
                'condition' => [
                    'ekit_icon_box_badge_control' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'ekit_icon_box_badge_position',
            [
                'label' => esc_html__('Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top_center',
                'options' => [
                    'top_left' => esc_html__('Top Left', 'sf-widget'),
                    'top_center' => esc_html__('Top Center', 'sf-widget'),
                    'top_right' => esc_html__('Top Right', 'sf-widget'),
                    'center_left' => esc_html__('Center Left', 'sf-widget'),
                    'center_right' => esc_html__('Center Right', 'sf-widget'),
                    'bottom_left' => esc_html__('Bottom Left', 'sf-widget'),
                    'bottom_center' => esc_html__('Bottom Center', 'sf-widget'),
                    'bottom_right' => esc_html__('Bottom Right', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_icon_box_badge_control' => 'yes'
                ],
            ]
        );

        $repeater->add_responsive_control(
            'badge_arrow_horizontal_position',
            [
                'label' => esc_html__('Horizontal Position', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'desktop_default' => [
                    'size' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .ekit-icon-box-badge' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_badge_control' => 'yes'
                ],            
            ]
        );

        $repeater->add_responsive_control(
            'badge_arrow_horizontal_position_vertial',
            [
                'label' => esc_html__('Vertical Position', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'desktop_default' => [
                    'size' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .ekit-icon-box-badge' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_badge_control' => 'yes'
                ],
            ]
        );

        // Button Content Controls (inside repeater)
        $repeater->add_control(
            'ekit_icon_Icon_Width_Separator11', // Divider before button
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $repeater->add_control(
            'ekit_icon_box_button_heading', // Heading for button
            [
                'label' => esc_html__('Button', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );
        
        $repeater->add_control(
            'ekit_btn_text',
            [
                'label' => esc_html__('Label', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn more', 'sf-widget'),
                'placeholder' => esc_html__('Learn more', 'sf-widget'),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'ekit_btn_url',
            [
                'label' => esc_html__('URL', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_url('https://wpmet.com'),
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => '#',
                ],
            ]
        );
        $repeater->add_control(
            'ekit_btn_section_settings',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'ekit_btn_icons__switch',
            [
                'label' => esc_html__('Add icon?', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
            ]
        );
        $repeater->add_control(
            'ekit_btn_icons',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'ekit_btn_icon',
                'label_block' => true,
                'default' => [
                    'value' => '',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'ekit_btn_icon_align',
            [
                'label' => esc_html__('Icon Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => esc_html__('Before', 'sf-widget'),
                    'right' => esc_html__('After', 'sf-widget'),
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );
        
        $repeater->add_control(
            'ekit_btn_class',
            [
                'label' => esc_html__('Class', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('Class Name', 'sf-widget'),
            ]
        );
        $repeater->add_control(
            'ekit_btn_id',
            [
                'label' => esc_html__('ID', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('ID', 'sf-widget'),
            ]
        );
        // SF Button Type Section (in repeater for content/rendering)
        do_action('sf_icon_button_variant_options',$repeater);

        $this->add_control(
            'ekit_icon_Icon_Width_Separator5',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'icon_boxes',
            [
                'label' => esc_html__('Icon Boxes List', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'ekit_icon_box_title_text' => esc_html__('Strategy and Planning', 'sf-widget'),
                    ],
                ],
                'title_field' => '{{{ ekit_icon_box_title_text }}}',
            ]
        );

        $this->end_controls_section();
            $this->start_controls_section(
            'sf_icon_box_custom_section',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        do_action('sf_iconbox_style_options', $this);

        // Master Enable Switch
        $this->add_control(
            'sf_icon_box_enable',
            [
                'label' => esc_html__('Enable Custom Settings', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'default' => 'yes',
            ]
        );

        //Icon Font SIZE
        $this->add_control(
            'ekit_icon_Icon_Width_Separator13',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_Icon-sf-style',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                ],
            ]
        );

        //Start Icon Control
        $this->add_control(
            'ekit_icon_box_icon_style',
            [
                'label' => esc_html__('Icon Style', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'Stacked',
                'options' => [
                    'Flat' => esc_html__('Flat', 'sf-widget'),
                    'Outline' => esc_html__('Outline', 'sf-widget'),
                    'Stacked' => esc_html__('Stacked', 'sf-widget'),
                ],
                'selectors_dictionary' => [
                    'Flat' => 'background: var(--e-global-color-primary); border: none; color: var(--e-global-color-light); border-radius: 16px;',
                    'Outline' => 'color: var(--e-global-color-primary); border: 2px solid var(--e-global-color-primary); border-radius: 50%;',
                    'Stacked' => 'color: var(--e-global-color-primary);',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-info-box-icon i' => '{{VALUE}}'
                ],
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'icon_font_size2',
            [
                'label'       => __( 'Icon Font Size', 'sf-widget' ),
                'type'        => \Elementor\Controls_Manager::SLIDER,
                'size_units'  => [ 'px' ],
                'range'       => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'default'     => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'   => [
                    // Only the icon itself
                    '{{WRAPPER}} .elementskit-info-box-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'render_type' => 'ui',
                'condition'   => [
                    'sf_icon_box_enable' => 'yes',
                ],
            ]
        );
 
        $this->add_control(
            'icon_wrapper_padding',
            [
                'label'       => __( 'Icon Wrapper Padding', 'sf-widget' ),
                'type'        => \Elementor\Controls_Manager::SLIDER,
                'size_units'  => [ 'px' ],
                'range'       => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'default'     => [
                    'unit' => 'px',
                    'size' => '18',               // change if you want a different start value
                ],
                'selectors'   => [
                    // Only the wrapper
                    '{{WRAPPER}} .elementskit-info-box-icon i' => 'padding: {{SIZE}}{{UNIT}};',
                ],
                'render_type' => 'ui',
                'condition'   => [
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style!' => 'Stacked',
                ],
            ]
        ); 

        $this->add_control(
            'ekit_icon_box-border-divider-',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style' => 'Outline'
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box-border-titl-',
            [
                'label' => esc_html__('Icon Border', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style' => 'Outline'
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box_button_border_type',
            [
                'label' => esc_html__('Border Type', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('None', 'sf-widget'),
                    'solid' => esc_html__('Solid', 'sf-widget'),
                    'double' => esc_html__('Double', 'sf-widget'),
                    'dotted' => esc_html__('Dotted', 'sf-widget'),
                    'dashed' => esc_html__('Dashed', 'sf-widget'),
                    'groove' => esc_html__('Groove', 'sf-widget'),
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .icon-wrapper' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style' => 'Outline'
                ],
            ]
        );

        /* Width */
        $this->add_responsive_control(
            'ekit_icon_box_border_width',
            [
                'label'      => esc_html__('Border Width', 'sf-widget'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 20 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .icon-wrapper' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [ 
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style' => 'Outline'
                ],
            ]
        );

        /* Color */
        $this->add_control(
            'ekit_icon_box_border_color',
            [
                'label'     => esc_html__('Border Color', 'sf-widget'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .icon-wrapper' => 'border-color: {{VALUE}};',
                ],
                'condition' => [ 
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style' => 'Outline'
                ],
            ]
        );

        
        $this->add_responsive_control(
            'ekit_icon_box_btn_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_icon_style' => 'Outline'
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_Icon_Width_Separator12',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                    'ekit_icon_box_enable_btn_show' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
        //Animation effect
        do_action('sf_iconbox_glow_options', $this);

        // start style for Icon Box Container
        $this->start_controls_section(
            'ekit_icon_box_section_background_style',
            [
                'label' => esc_html__('Icon Box Container', 'sf-widget'),
                'tab' => controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs('ekit_icon_box_style_background_tab');
        $this->start_controls_tab(
            'ekit_icon_box_section_background_style_n_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_infobox_bg_group',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-infobox',
            ]
        );

        $this->add_control(
            'bg_color',
            [
                'label' => esc_html__('Background Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-overlay)',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'bg_type' => 'color',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_box_infobox_box_shadow_group',
                'label' => esc_html__('Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-infobox',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_icon_box_iocnbox_border_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-infobox',
                'fields_options' => [
                    'border' => [
                        'default' => 'default',
                    ],
                    'size_units' => ['px'],
                    'width' => [
                        'default' => [
                            'top' => '',
                            'right' => '',
                            'bottom' => '',
                            'left' => '',
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .elementskit-infobox::before' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',       
                            '{{WRAPPER}} .elementskit-infobox' => 'border-width : {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',                          
                        ],
                    ],
                    'color' => [
                        'default' => '',
                        'type' => 'hidden', // This prevents UI rendering
                    ],
                ]
            ]
        );
 
        $this->add_control(
            'border_color',
            [
                'label' => __('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        do_action('sf_iconbox_gradient_border', $this);

        $this->add_responsive_control(
            'ekit_icon_box_infobox_border_radious',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'iconbox__padding',
            [
                'label' => __('Padding', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .my-flex-item .elementskit-infobox.icon-top-align ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'iconbox__margin',
            [
                'label' => __('Margin', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .ekit-wid-con .my-flex-item .elementskit-infobox.icon-top-align ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        

        $this->end_controls_tab();
        $this->start_controls_tab(
            'ekit_icon_box_section_background_style_n_hv_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_infobox_bg_hover_group',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover',
            ]
        );
        $this->add_responsive_control(
            'ekit_icon_box_infobox_bg_padding_inner',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],

                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_box_infobox_box_shadow_hv_group',
                'label' => esc_html__('Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_icon_box_icon_box_border_hv_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover',
            ]
        );
        $this->add_responsive_control(
            'ekit_icon_box_infobox_border_radious_hv',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'ekit_icon_box_info_box_hover_animation',
            [
                'label' => esc_html__('Hover Animation', 'sf-widget'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_icon_section_style_content',
            [
                'label' => esc_html__('Content', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_content_valign',
            [
                'label' => esc_html__('Vertical Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'top' => [
                        'title' => __('Top', 'sf-widget'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'middle' => [
                        'title' => __('Middle', 'sf-widget'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'bottom' => [
                        'title' => __('Bottom', 'sf-widget'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors_dictionary' => [
                    'top' => '-webkit-box-align: start; -ms-flex-align: start; -ms-grid-row-align: flex-start; align-items: flex-start;',
                    'middle' => '-webkit-box-align: center; -ms-flex-align: center; -ms-grid-row-align: center; align-items: center;',
                    'bottom' => '-webkit-box-align: end; -ms-flex-align: end; -ms-grid-row-align: flex-end; align-items: flex-end;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox' => '{{VALUE}}',
                ],
                'separator' => 'after',
                'condition' => [
                    'ekit_icon_box_icon_position' => ['left', 'right'],
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_heading_title',
            [
                'label' => esc_html__('Title', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'ekit_icon_box_title_size',
            [
                'label' => esc_html__('Title HTML Tag', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h5',
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_title_bottom_space',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_title_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->start_controls_tabs('ekit_icon_title_color_tabs');

        $this->start_controls_tab(
            'ekit_icon_title_color_tab_normal',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_title_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_icon_title_color_tab_hover',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_title_color_hover',
            [
                'label' => esc_html__('Color Hover', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover .elementskit-info-box-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_icon_title_typography_group',
                'selector' => '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-title',
            ]
        );

        $this->add_control(
            'ekit_icon_heading_description',
            [
                'label' => esc_html__('Description', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->start_controls_tabs('ekit_icon_description_color_tabs');

        $this->start_controls_tab(
            'ekit_icon_description_color_tab_normal',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_description_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .box-body > p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_icon_description_color_tab_hover',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_description_color_hover',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover .box-body > p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_icon_description_typography_group',
                'selector' => '{{WRAPPER}} .elementskit-infobox .box-body > p',
            ]
        );


        $this->add_responsive_control(
            'ekit_icon_box_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'size' => '',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box_watermark',
            [
                'label' => esc_html__('Water Mark', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'ekit_icon_box_enable_water_mark' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'ekit_icon_box_watermark_color',
            [
                'label' => esc_html__('Water Mark Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--e-global-color-light)',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .icon-hover' => 'color: {{VALUE}};fill: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_icon_box_enable_water_mark' => 'yes',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_watermark_font_size',
            [
                'label' => esc_html__('Water Mark Font Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .icon-hover > :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_enable_water_mark' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();

        // Icon style
        $this->start_controls_section(
            'ekit_icon_box_section_style_icon',
            [
                'label' => esc_html__('Icon/Image', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('ekit_icon_box_icon_colors');

        $this->start_controls_tab(
            'ekit_icon_box_icon_colors_normal',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_box_icon_primary_color',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-info-box-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box_icon_secondary_color_normal',
            [
                'label' => esc_html__('Icon BG Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .icon-wrapper' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'sf_icon_box_enable' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_icon_box_shadow_normal_group',
                'selector' => '{{WRAPPER}} .elementskit-info-box-icon',
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_icon_box_icon_colors_hover',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_box_hover_primary_color',
            [
                'label' => esc_html__('Icon Hover Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover .elementskit-info-box-icon' => 'color: {{VALUE}};fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box_hover_background_color',
            [
                'label' => esc_html__('Background Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover .elementskit-info-box-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_icon_box_border_icon_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover .elementskit-info-box-icon',
            ]
        );

        $this->add_control(
            'ekit_icon_icons_hover_animation',
            [
                'label' => esc_html__('Hover Animation', 'sf-widget'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_icon_box_shadow_group',
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover .elementskit-info-box-icon',
            ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->add_responsive_control(
            'ekit_icon_icon_size',
            [
                'label' => esc_html__('Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 6,
                        'max' => 300,
                    ],
                ],
                'default' => [
                    'size' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'ekit_icon_box_enable_header_icon' => 'icon'
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_space',
            [
                'label' => esc_html__('Spacing', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-box-header .elementskit-info-box-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                    'isLinked' => 'true',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_icon_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'size' => '',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_rotate',
            [
                'label' => esc_html__('Rotate', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                    'unit' => 'deg',
                ],
                'desktop_default' => [
                    'unit' => 'deg',
                ],
                'tablet_default' => [
                    'unit' => 'deg',
                ],
                'mobile_default' => [
                    'unit' => 'deg',
                ],
                'range' => [
                    'deg' => [
                        'min' => 0,
                        'max' => 360,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon svg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_height',
            [
                'label' => esc_html__('Image Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon svg' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_width',
            [
                'label' => esc_html__('Image Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon svg' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_line_height',
            [
                'label' => esc_html__('Line Height', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementkit-infobox-icon' => 'line-height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-infobox .elementskit-info-box-icon' => 'line-height: {{SIZE}}{{UNIT}};',
                ],

            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_icon_vertical_align',
            [
                'label' => esc_html__('Vertical Position ', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox .elementskit-box-header .elementskit-info-box-icon' => ' -webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}});',
                ],
                'condition' => [
                    'ekit_icon_box_icon_position!' => 'top'
                ]

            ]
        );
        $this->end_controls_section();

        // start Button style
        $this->start_controls_section(
            'ekit_icon_box_section_style',
            [
                'label' => esc_html__('Button', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_icon_box_enable_btn' => 'yes',
                ]
            ]
        );
        $this->add_responsive_control(
            'ekit_icon_box_text_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'ekit_icon_box_text_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_icon_box_typography_group',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-btn',
            ]
        );
        $this->add_responsive_control(
            'ekit_icon_box_btn_icon_font_size',
            array(
                'label' => esc_html__('Icon Font Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => array(
                    'px',
                    'em',
                    'rem',
                ),
                'range' => array(
                    'px' => array(
                        'min' => 1,
                        'max' => 100,
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .elementskit-btn i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-btn svg' => 'max-width: {{SIZE}}{{UNIT}};'
                ),
                'condition' => [
                    'ekit_icon_box_icons__switch' => 'yes',
                ],
            )
        );

        $this->add_control(
            'ekit_icon_box_btn_icon_right_space',
            [
                'label' => esc_html__('Icon Space', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 5,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-btn i' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-btn svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_icons__switch' => 'yes',
                    'ekit_icon_box_icon_align' => 'right',
                ],
            ]
        );

        $this->add_control(
            'ekit_icon_box_btn_icon_left_space',
            [
                'label' => esc_html__('Icon Space', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-btn i' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementskit-btn svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_icons__switch' => 'yes',
                    'ekit_icon_box_icon_align' => 'left',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_button_style');

        $this->start_controls_tab(
            'ekit_icon_box_tab_button_normal',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_box_button_text_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .elementskit-btn' => 'color: {{VALUE}};fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_btn_background_group',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-btn',
            ]
        );


        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_box_button_box_shadow',
                'selector' => '{{WRAPPER}} .elementskit-btn',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'ekit_icon_box_tab_button_hover',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_control(
            'ekit_icon_box_btn_hover_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover .elementskit-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_btn_background_hover_group',
                'label' => esc_html__('Background', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover .elementskit-btn',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ekit_icon_box_button_border_hv_color_group',
                'label' => esc_html__('Border', 'sf-widget'),
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover .elementskit-btn',
            ]
        );
        $this->add_responsive_control(
            'ekit_icon_box_btn_hover_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementskit-infobox:hover .elementskit-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_box_button_box_shadow_hover_group',
                'selector' => '{{WRAPPER}} .elementskit-infobox:hover .elementskit-btn',
            ]
        );

        $this->add_control(
            'ekit_icon_box_button_hover_animation',
            [
                'label' => esc_html__('Animation', 'sf-widget'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();


        $this->end_controls_section();

        //// Style Section: SF List Style
        $this->start_controls_section(
            'ekit_heading_section_extra_list_style',
            [
                'label' => esc_html__('List', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ekit_heading_section_extra_list_show' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_container_align',
            [
                'label' => esc_html__('Container Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list-wrapper' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
                    'sf_list_display_style' => 'column',
                ]
            ]
        );

        $this->add_control(
            'sf_list_flex_wrap',
            [
                'label' => esc_html__('Wrap Items', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'nowrap',
                'options' => [
                    'nowrap' => esc_html__('No Wrap', 'sf-widget'),
                    'wrap' => esc_html__('Wrap', 'sf-widget'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'flex-wrap: {{VALUE}};',
                ],
                'condition' => [
                    'sf_list_display_style' => 'row',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '', // Empty = fallback to auto
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_gap',
            [
                'label' => esc_html__('Item Gap', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_spacing_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_spacing_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_marker_spacing',
            [
                'label' => esc_html__('Marker Spacing', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-list-marker' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Icon Style
        $this->add_control(
            'sf_icon_styles_heading',
            [
                'label' => esc_html__('Icon/SVG Styles', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_icon_align',
            [
                'label' => esc_html__('Icon Vertical Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Top', 'sf-widget'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Bottom', 'sf-widget'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'align-self: {{VALUE}};',
                ],
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'sf_icon_inset_block_start',
            [
                'label' => esc_html__('Icon Inset Block Start', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'position: relative; inset-block-start: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );

        // Icon Normal and Hover Tabs
        $this->start_controls_tabs(
            'sf_icon_style_tabs',
            [
                'condition' => [
                    'sf_list_style' => 'icon',
                ],
            ]
        );

        $this->start_controls_tab(
            'sf_icon_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_responsive_control(
            'sf_list_icon_font_size',
            [
                'label' => esc_html__('Icon Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px', 'size' => ''],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper' => 'font-size: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper > :is(i, svg)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_icon_color',
            [
                'label' => esc_html__('Icon Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li > .sf-icon-wrapper > :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'sf_icon_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_responsive_control(
            'sf_list_icon_scale_hover',
            [
                'label' => esc_html__('Icon Hover Scale', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0.5, 'max' => 2, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li:hover > .sf-icon-wrapper > :is(i, svg)' => 'transform: scale({{SIZE}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_icon_color_hover',
            [
                'label' => esc_html__('Icon Hover Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li:hover > .sf-icon-wrapper > :is(i, svg)' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Text Styles
        $this->add_control(
            'sf_text_styles_heading',
            [
                'label' => esc_html__('Text Styles', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'sf_list_text_align',
            [
                'label' => esc_html__('Text Vertical Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Top', 'sf-widget'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Bottom', 'sf-widget'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li p' => 'align-self: {{VALUE}};',
                ],
            ]
        );

        // Text Normal and Hover Tabs
        $this->start_controls_tabs('sf_text_style_tabs');

        $this->start_controls_tab(
            'sf_text_normal_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sf_list_typography',
                'selector' => '{{WRAPPER}} .sf-custom-list li p',
                'default' => [
                    'font_size' => ['size' => '', 'unit' => 'px'],
                    'font_weight' => 'var(--e-global-typography-primary-font-weight)',
                ],
            ]
        );

        $this->add_responsive_control(
            'sf_list_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li p' => 'color: {{VALUE}};',
                ],
                'default' => '',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'sf_list_text_shadow',
                'selector' => '{{WRAPPER}} .sf-custom-list li p',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'sf_text_hover_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_responsive_control(
            'sf_list_color_hover',
            [
                'label' => esc_html__('Text Hover Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sf-custom-list li:hover p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'sf_list_text_shadow_hover',
                'selector' => '{{WRAPPER}} .sf-custom-list li:hover p',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();
        //SF List Style Control End

        // Background Overlay style
        $this->start_controls_section(
            'ekit_icon_box_section_bg_ovelry_style',
            [
                'label' => esc_html__('Background Overlay ', 'sf-widget'),
                'tab' => controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'ekit_icon_box_show_image_overlay',
            [
                'label' => esc_html__('Enable Image Overlay', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'ekit_icon_box_show_image',
            [
                'label' => esc_html__('Choose Image', 'sf-widget'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                    'id' => -1
                ],
                'condition' => [
                    'ekit_icon_box_show_image_overlay' => 'yes',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_image_ovelry_color',
                'label' => esc_html__('Background Overlay Color', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-infobox.image-active::before',
                'condition' => [
                    'ekit_icon_box_show_image_overlay' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'ekit_icon_box_show_overlay',
            [
                'label' => esc_html__('Enable Overlay', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        $this->start_controls_tabs(
            'ekit_icon_box_style_bg_overlay_tab',
            [
                'condition' => [
                    'ekit_icon_box_show_overlay' => 'yes'
                ]
            ]
        );
        $this->start_controls_tab(
            'ekit_icon_box_section_bg_ov_style_n_tab',
            [
                'label' => esc_html__('Normal', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_bg_ovelry_color',
                'label' => esc_html__('Background Overlay Color', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-infobox.gradient-active::before',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'ekit_icon_box_section_bg_ov_style_n_hv_tab',
            [
                'label' => esc_html__('Hover', 'sf-widget'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'ekit_icon_box_bg_ovelry_color_hv',
                'label' => esc_html__('Background Overlay Color', 'sf-widget'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementskit-infobox.gradient-active:hover::before',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control(
            'ekit_icon_box_section_bg_hover_color_direction',
            [
                'label' => esc_html__('Hover Direction', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'hover_from_left' => [
                        'title' => esc_html__('From Left', 'sf-widget'),
                        'icon' => 'fa fa-caret-right',
                    ],
                    'hover_from_top' => [
                        'title' => esc_html__('From Top', 'sf-widget'),
                        'icon' => 'fa fa-caret-down',
                    ],
                    'hover_from_right' => [
                        'title' => esc_html__('From Right', 'sf-widget'),
                        'icon' => 'fa fa-caret-left',
                    ],
                    'hover_from_bottom' => [
                        'title' => esc_html__('From Bottom', 'sf-widget'),
                        'icon' => 'fa fa-caret-up',
                    ],

                ],
                'default' => 'hover_from_left',
                'toggle' => true,
                'condition' => [
                    'ekit_icon_box_show_overlay' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'ekit_icon_box_badge_style_tab',
            [
                'label' => esc_html__('Badge', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_badge_padding',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_icon_box_badge_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'badge_text_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-badge' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'badge_bg_color',
            [
                'label' => esc_html__('Background Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-badge' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        do_action('sf_iconbox_badge_bg_gradient', $this);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_icon_box_badge_box_shadow',
                'label' => esc_html__('Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .ekit-badge',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_icon_box_badge_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .ekit-badge',
            ]
        );

        $this->end_controls_section();


        // New/Updated Button Style Section (Main Style Tab)
        $this->start_controls_section(
            'sf_item_button_style', // New section name to avoid conflict
            [
                'label' => esc_html__('Button', 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                // No condition—shows if widget has buttons; user can style globally
            ]
        );

        // Size (global, applies to all)
        $this->add_control(
            '_button_size',
            [
                'label' => esc_html__('Button Size', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'lg',
                'options' => [
                    'sm' => esc_html__('Small', 'sf-widget'),
                    'md' => esc_html__('Medium', 'sf-widget'),
                    'lg' => esc_html__('Lg', 'sf-widget'),
                    'xl' => esc_html__('Xl', 'sf-widget'),
                ],
                'selectors_dictionary' => [
                    'sm' => 'font-size: 12px; padding: 8px 16px;',
                    'md' => 'font-size: 14px; padding: 12px 24px;',
                    'lg' => 'font-size: 16px; padding: 16px 32px;',
                    'xl' => 'font-size: 18px; padding: 20px 40px;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => '{{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'width',
            [
                'label' => esc_html__('Width (%)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'width: {{SIZE}}%;',
                ]
            ]
        );

        // Padding (responsive, global)
        $this->add_responsive_control(
            '_ekit_btn_text_padding_1',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Typography, Shadow (global)
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ekit_btn_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .sf-item-button',
            ]
        );
        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'ekit_btn_shadow',
                'selector' => '{{WRAPPER}} .sf-item-button',
            ]
        );

        // Background Tabs (for Default/Flat/Outline/Stacked)
        $this->start_controls_tabs('sf_button_bg_tabs');
        $this->start_controls_tab('sf_button_normal_tab', ['label' => esc_html__('Normal', 'sf-widget')]);
        $this->add_control(
            'ekit_btn_text_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Stacked'], // Per-item, but style global
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_normal',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .sf-item-button',
                'fields_options' => [
                    'gradient_type' => ['default' => 'linear'],
                    'gradient_angle' => ['default' => ['unit' => 'deg', 'size' => 250]],
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Default', 'Flat'],
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab('sf_button_hover_tab', ['label' => esc_html__('Hover', 'sf-widget')]);
        $this->add_control(
            'ekit_btn_hover_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_hover',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .sf-item-button:hover',
                'fields_options' => [
                    'gradient_type' => ['default' => 'linear'],
                    'gradient_angle' => ['default' => ['unit' => 'deg', 'size' => 90]],
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Border (for Flat/Outline)
        $this->add_control(
            'ekit_btn_border_style_tabs',
            [
                'label' => esc_html__('Border', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
            ]
        );
        $this->add_responsive_control(
            'ekit_btn_border_style2',
            [
                'label' => esc_html_x('Border Type', 'Border Control', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'sf-widget'),
                    'solid' => esc_html_x('Solid', 'Border Control', 'sf-widget'),
                    // ... (add other options as in provided code)
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
            ]
        );
        // Add other border controls (width, color, radius, hover) similarly...
        $this->add_responsive_control(
            'ekit_btn_border_radius_normal',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
            ]
        );

        // Shadow
        $this->add_control(
            'ekit_btn_box_shadow_style',
            [
                'label' => esc_html__('Shadow', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_btn_box_shadow_group',
                'selector' => '{{WRAPPER}} .sf-item-button',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ekit_btn_hover_box_shadow_group',
                'label' => esc_html__('Hover Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .sf-item-button:hover',
            ]
        );

        // Icon Styles (global, for all buttons)
        $this->add_control(
            'ekit_btn_iconw_style',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );
        $this->add_responsive_control(
            'ekit_btn_normal_icon_font_size',
            [
                'label' => esc_html__('Font Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-item-button > :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_btn_normal_icon_padding_left',
            [
                'label' => esc_html__('Add space after icon', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '.rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, .rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: 0;',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
                    'ekit_btn_icon_align' => 'left',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_btn_normal_icon_padding_right',
            [
                'label' => esc_html__('Add space before icon', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '.rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > i, .rtl {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn > svg' => 'margin-left: 0; margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes',
                    'ekit_btn_icon_align' => 'right',
                ]
            ]
        );

        $this->add_responsive_control(
            'ekit_btn_normal_icon_vertical_align',
            [
                'label' => esc_html__('Move icon Vertically', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => -20,
                        'max' => 20,
                    ],
                    'em' => [
                        'min' => -5,
                        'max' => 5,
                    ],
                    'rem' => [
                        'min' => -5,
                        'max' => 5,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn i, {{WRAPPER}} .ekit-btn-wraper-' . ' .elementskit-btn svg' => '-webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}})',
                ],
                'condition' => [
                    'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();
        // animation blob style
        do_action('sf_iconbox_glow_style', $this);

        // start content style
        $this->insert_pro_message();
    }

    protected function render()
    {
        echo '<div class="ekit-wid-con" >';
        $this->render_raw();
        echo '</div>';
    }

    protected function render_raw()
    {
        $settings = $this->get_settings_for_display();
        if (empty($settings['icon_boxes'])) {
            return;
        }

        echo '<div class="my-flex-container" >';
        foreach ($settings['icon_boxes'] as $index => $item) {

            // Check if per-item width is set
            $width = !empty($item['item_width']['size']) ? $item['item_width']['size'] : '';
            $unit = !empty($item['item_width']['unit']) ? $item['item_width']['unit'] : '';
            // If per-item width is set, use inline style
            $style = $width && $unit ? 'style="min-width: 284px; width:' . esc_attr($width . $unit) . ';"' : '';


            // ---------------------------------------------------
            // 1. Remove the old add_render_attribute block
            // ---------------------------------------------------

            // ---------------------------------------------------
            // 2. NEW CODE – put it **inside** the foreach, right after
            //     $style = … (the inline width style)
            // ---------------------------------------------------
            $wrapper_key = 'item_wrapper_' . $index;   // <-- unique key

            $wrapper_classes = [
                'my-flex-item',
                'my-flex-item-' . $index,
                esc_attr( $settings['sf_iconbox_type'] ),
            ];

            if ( 'padding' === $settings['sf_iconbox_type'] ) {
                $wrapper_classes[] = 'card';
            }

            // Remove empty strings & duplicates (just in case)
            $wrapper_classes = array_unique( array_filter( $wrapper_classes ) );

            $this->add_render_attribute( $wrapper_key, 'class', $wrapper_classes );

            // ---------------------------------------------------
            // 3. Render the div with the **unique** key
            // ---------------------------------------------------
            echo '<div ' . $this->get_render_attribute_string( $wrapper_key ) . ' ' . $style . '>';
            $icon_image_post = $settings['ekit_icon_box_icon_position'];
            $icon_pos_class = '';
            $icon_pos_class .= $icon_image_post == 'right' ? 'elementskit-icon-right' : '';
            $icon_pos_class .= $icon_image_post == 'left' ? 'media' : '';
            $content_alignment = $settings['ekit_icon_box_text_align_responsive'];


            if ($icon_image_post == 'top') {
                $text_align = $settings['ekit_icon_box_text_align_responsive'] . ' ' . 'icon-top-align';
            } else {
                $text_align = $icon_image_post . ' ' . 'icon-lef-right-aligin';
            }
            $enable_overlay_color = '';
            if ($settings['ekit_icon_box_show_overlay'] == 'yes') {
                $enable_overlay_color = 'gradient-active';
            }

            $ekit_icon_box_show_image = '';
            if ($settings['ekit_icon_box_show_image_overlay'] == 'yes') {
                $ekit_icon_box_show_image = 'image-active';
            }
            // info box style

            $gradient_enabled = $this->get_settings_for_display('use_gradient_icon_color') === 'yes';
            $icon_class = $gradient_enabled ? 'gradient-icon' : 'normal-icon';

            $PrefixClass = $settings['sf_iconbox_type'];

            $this->add_render_attribute('infobox_wrapper', 'class', 'elementskit-infobox');
            $this->add_render_attribute('infobox_wrapper', 'class', $PrefixClass);
            $this->add_render_attribute('infobox_wrapper', 'class', 'text-' . (empty($content_alignment) && $icon_image_post == 'top' ? 'center' : $content_alignment));
            $this->add_render_attribute('infobox_wrapper', 'class', 'text-' . $text_align);
            $this->add_render_attribute('infobox_wrapper', 'class', 'elementor-animation-' . $settings['ekit_icon_box_info_box_hover_animation']);
            $this->add_render_attribute('infobox_wrapper', 'class', $icon_pos_class);
            $this->add_render_attribute('infobox_wrapper', 'class', $enable_overlay_color);
            $this->add_render_attribute('infobox_wrapper', 'class', $ekit_icon_box_show_image);
            $this->add_render_attribute('infobox_wrapper', 'class', $settings['ekit_icon_box_section_bg_hover_color_direction']);

            // Title HTML Tag
            $options_ekit_icon_box_title_size = array_keys([
                'h1' => 'H1',
                'h2' => 'H2',
                'h3' => 'H3',
                'h4' => 'H4',
                'h5' => 'H5',
                'h6' => 'H6',
                'div' => 'div',
                'span' => 'span',
                'p' => 'p',
            ]);
            $ekit_icon_box_title_size_esc = \ElementsKit_Lite\Utils::esc_options($settings['ekit_icon_box_title_size'], $options_ekit_icon_box_title_size, 'h3');

            // Icon
            $image = '';
            if (!empty($item['ekit_icon_box_show_image']['url']) && $item['ekit_icon_box_show_image_overlay'] == 'yes') {
                $this->add_render_attribute('image', 'src', $item['ekit_icon_box_show_image']['url']);
                $this->add_render_attribute('image', 'alt', Control_Media::get_image_alt($item['ekit_icon_box_show_image']));

                $image_html = \Elementskit_Lite\Utils::get_attachment_image_html($item, 'ekit_icon_box_show_image');
                $image = '<figure class="image-hover">' . $image_html . '</figure>';
            }
            ?>
                    <div <?php echo $this->get_render_attribute_string('infobox_wrapper'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Already escaped by elementor ?>>
                    <?php if ('yes' === $settings['ekit_icon_box_enable_icon_show']): ?>
                        <?php if (!empty($item['ekit_icon_box_header_icons']) && $item['ekit_icon_box_enable_header_icon'] == 'icon'): ?>
                    <div class="elementskit-box-header  <?php $style = 'display:flex;';
                        if (
                            $settings['ekit_icon_box_icon_position'] === 'top' &&
                            ( $settings['ekit_icon_box_text_align_responsive'] === 'center'
                            )
                        ) {
                            $style .= 'justify-content:center;';
                        } elseif (
                            $settings['ekit_icon_box_icon_position'] === 'top' &&
                            $settings['ekit_icon_box_text_align_responsive'] === 'right'
                        ) {
                            $style .= 'justify-content:flex-end;';
                        }
                        ?>
                <?php echo 'elementor-animation-' . esc_attr($settings['ekit_icon_icons_hover_animation']); ?>" style="<?php echo esc_attr($style); ?>">
                                    <?php
                                    $gradient_enabled = $this->get_settings_for_display('use_gradient_icon_bg_color') === 'yes';
                                    $icon_wrapper_class = $gradient_enabled ? 'icon-wrapper use-gradient-bg' : 'icon-wrapper';
                                    ?>
                                    <div class="<?php echo esc_attr($icon_wrapper_class); ?>">
                                        <div class="elementskit-info-box-icon normal-icon<?php echo ($settings['ekit_icon_box_icon_position'] != 'top' ? 'text-center' : ''); ?>">
                                            <?php

                                            $migrated = isset($item['__fa4_migrated']['ekit_icon_box_header_icons']);
                                            // Check if its a new widget without previously selected icon using the old Icon control
                                            $is_new = empty($item['ekit_icon_box_header_icon']);
                                            if ($is_new || $migrated) {

                                                // new icon
                                                Icons_Manager::render_icon($item['ekit_icon_box_header_icons'], ['aria-hidden' => 'true', 'class' => 'elementkit-infobox-icon']);
                                            } else {
                                                ?>
                                                        <i class="<?php echo esc_attr($item['ekit_icon_box_header_icon']); ?> elementkit-infobox-icon" aria-hidden="true"></i>
                                                        <?php
                                            }
                                            ?>

                                        </div>
                                    </div>
                
                              </div>
                        <?php endif; ?>

                        <?php if (!empty($item['ekit_icon_box_header_image']) && $item['ekit_icon_box_enable_header_icon'] == 'image'): ?>
                                <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon <?php echo ($settings['ekit_icon_box_icon_position'] != 'top' ? 'text-center' : ''); ?>">
                                        <?php
                                        echo wp_kses(
                                            \Elementskit_Lite\Utils::get_attachment_image_html($item, 'ekit_icon_box_header_image'),
                                            \ElementsKit_Lite\Utils::get_kses_array()
                                        );
                                        ?>
                                    </div>
                              </div>
                        <?php endif; ?>

                    <?php endif; ?>

                    <?php
                    $icon_position_class = ($settings['ekit_icon_box_icon_position'] === 'left') ? 'left-section' : '';
                    ?>

                    <div class="box-body <?php echo esc_attr($icon_position_class); ?>">
                        <?php if ($item['ekit_icon_box_title_text'] != '') { ?>
                                <?php if ($settings['ekit_icon_box_enable_title_show'] === 'yes'): ?>
                                        <<?php echo esc_attr($ekit_icon_box_title_size_esc); ?> class="elementskit-info-box-title">
                                            <?php echo esc_html($item['ekit_icon_box_title_text']); ?>
                                        </<?php echo esc_attr($ekit_icon_box_title_size_esc); ?>>
                                <?php endif; ?>
                        <?php } ?>
            
                        <?php if ($item['ekit_icon_box_description_text'] != ''): ?>
                                <?php if ($settings['ekit_icon_box_enable_description_show'] === 'yes'): ?>
                                          <p><?php echo wp_kses($item['ekit_icon_box_description_text'], \ElementsKit_Lite\Utils::get_kses_array()); ?></p>
                                 <?php endif; ?>
                        <?php endif; ?>

                        <?php if ($settings['ekit_heading_section_extra_list_show'] === 'yes'): ?>
                                <?php
                                $style = 'display:flex;';

                                if (
                                    $settings['ekit_icon_box_icon_position'] === 'top' &&
                                    (
                                        $settings['ekit_icon_box_text_align_responsive'] === 'center'
                                    )
                                ) {
                                    $style .= 'justify-content:center;';
                                } elseif (
                                    $settings['ekit_icon_box_icon_position'] === 'top' &&
                                    $settings['ekit_icon_box_text_align_responsive'] === 'right'
                                ) {
                                    $style .= 'justify-content:flex-end;';
                                }
                                ?>
                                <div class="sf-custom-list-wrapper" style="display:flex; width: 100%; box-sizing: border-box; <?php echo esc_attr($style); ?>">
                                    <ul class="sf-custom-list" style="display: flex; list-style-type: none;">
                                        <?php $texts = [
                                            $item['sf_list_text1'],
                                            $item['sf_list_text2'],
                                            $item['sf_list_text3'],
                                        ];
                                        foreach ($texts as $index => $items): ?>
                                                <li style="display: flex;">
                                                    <?php
                                                    switch ($settings['sf_list_style']) {
                                                        case 'number':
                                                            echo '<span class="sf-list-marker">' . ($index + 1) . '. </span>';
                                                            break;
                                                        case 'bullet':
                                                            echo '<span class="sf-list-marker">• </span>';
                                                            break;
                                                        case 'icon':
                                                            
                                                              if ( ! empty( $settings['sf_common_icon']['url'] ) && empty($settings['sf_common_icon']['value'])) {
                                                                ?>
                                                                <span class="sf-icon-wrapper" style="display: flex;">
                                                                    <img src="<?php echo esc_url( $settings['sf_common_icon']['url'] ); ?>" alt="List Icon" />
                                                                </span>
                                                                <?php
                                                            }
                                                             if (!empty($settings['sf_common_icon']['value'])) {
                                                                ?>
                                                                <span class="sf-icon-wrapper" style="display: flex;">
                                                                    <?php Icons_Manager::render_icon($settings['sf_common_icon'], ['aria-hidden' => 'true']); ?>
                                                                </span>
                                                                <?php
                                                            }
                                                            break;
                                                    }
                                                    ?>
                                                    <p class="sf-list-text" style="margin: 0;"><?php echo esc_html($items); ?></p>
                                                </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                        <?php endif; ?>
          
                    <?php if ($settings['show_button_sf_controls'] === 'yes'): ?>
                            <?php
                            // Generate classes from item settings
                            $btn_text = $item['ekit_btn_text'];
                            $btn_class = !empty($item['ekit_btn_class']) ? $item['ekit_btn_class'] : '';
                            $btn_id = !empty($item['ekit_btn_id']) ? $item['ekit_btn_id'] : '';

                            $icon_align = $item['ekit_btn_icon_align'] ?? 'left';

                            // Variant classes
                            $style = $item['ekit_icon_box_button_style_'] ?? 'Default';
                            $variant_class = '';
                            if ($style === 'Default') {
                                $variant_class = ' default-btn';
                            } elseif ($style === 'Flat') {
                                $button_variant = $item['button_variant'] ?? 'primary';
                                $variant_class = ' flat-' . $button_variant;
                            } elseif ($style === 'Outline') {
                                $outline_variant = $item['outline_variant'] ?? 'primary';
                                $variant_class = ' outline-' . $outline_variant;
                                if ($item['outline_hover_effect'] !== 'yes') {
                                    $btn_class .= ' no-hover-fill';
                                }
                            } elseif ($style === 'Stacked') {
                                $stacked_variant = $item['ekit_icon_box_stacked_'] ?? 'primary';
                                $variant_class = ' stacked-' . $stacked_variant;
                                $btn_class .= ' sf-widget-link-underline keydesign-underline';
                            }
                            $btn_class .= $variant_class . ' whitespace--normal';

                            if ($style === 'Stacked') {
                                $btn_class .= ' sf-widget-link-underline keydesign-underline';
                            }

                            // Size class (global from settings, but per-item ok)
                            $size = $settings['_button_size'] ?? 'md'; // Use global size
                            $size_class = ' size-' . $size;

                            $all_btn_classes = trim('elementskit-btn sf-item-button ' . $btn_class . $size_class); // Add sf-item-button for styles
            
                            $this->add_render_attribute('sf_item_button_' . $index, [
                                'class' => $all_btn_classes,
                                'id' => $btn_id
                            ]);


                            // Add link attributes (do this BEFORE rendering the <a> tag)
                            if (!empty($item['ekit_btn_url']['url'])) {
                                $this->add_link_attributes('sf_item_button_link_' . $index, $item['ekit_btn_url']);
                            }
                            ?>

                <div class="sf-item-button-wraper ekit-btn-inner">
                    <a <?php echo $this->get_render_attribute_string('sf_item_button_' . $index); ?>
                       <?php echo $this->get_render_attribute_string('sf_item_button_link_' . $index); ?>>
                        <?php if ($item['ekit_btn_icons__switch'] === 'yes' && !empty($item['ekit_btn_icons']['value'])): ?>
                                <?php if ($icon_align == 'right'): ?>
                                        <?php echo esc_html($btn_text); ?>
                                        <?php Icons_Manager::render_icon($item['ekit_btn_icons'], ['aria-hidden' => 'true', 'class' => 'icon-after']); ?>
                                <?php else: ?>
                                        <?php Icons_Manager::render_icon($item['ekit_btn_icons'], ['aria-hidden' => 'true', 'class' => 'icon-before']); ?>
                                        <?php echo esc_html($btn_text); ?>
                                <?php endif; ?>
                        <?php else: ?>
                                <?php echo esc_html($btn_text); ?>
                        <?php endif; ?>
                    </a>
                </div>
                    <?php endif; ?>
                    </div>
                
                    <?php if (!empty($item['ekit_icon_box_enable_water_mark']) && $item['ekit_icon_box_enable_water_mark'] == 'yes'): ?>

                        <div class="icon-hover">
                            <?php
                            // new icon
                            $migrated = isset($item['__fa4_migrated']['ekit_icon_box_water_mark_icons']);
                            // Check if its a new widget without previously selected icon using the old Icon control
                            $is_new = empty($item['ekit_icon_box_water_mark_icon']);
                            if ($is_new || $migrated) {
                                // new icon
                                Icons_Manager::render_icon($item['ekit_icon_box_water_mark_icons'], ['aria-hidden' => 'true']);
                            } else {
                                ?>
                                        <i class="<?php echo esc_attr($item['ekit_icon_box_water_mark_icon']); ?>" aria-hidden="true"></i>
                                        <?php
                            }
                            ?>
                        </div>

                    <?php endif; ?>

                    <?php if (!empty($item['ekit_icon_box_show_image_overlay']) && $item['ekit_icon_box_show_image_overlay'] == 'yes'): ?>
                            <?php echo wp_kses($image, \ElementsKit_Lite\Utils::get_kses_array()); ?>
                    <?php endif; ?>

                    <?php if ($item['ekit_icon_box_badge_control'] == 'yes' && $item['ekit_icon_box_badge_title'] != ''): ?>
                            <div class="ekit-icon-box-badge ekit_position_<?php echo esc_attr($item['ekit_icon_box_badge_position']); ?>">
                                <span class="ekit-badge"><?php echo esc_html($item['ekit_icon_box_badge_title']) ?></span>
                            </div>
                    <?php endif; ?>
                    </div>
                    <?php // end link Closing
                    echo '<div class="blob"></div>';
                    echo '<div class="fakeblob"></div>';
                    echo '</div>';
        }
        echo '</div>';
    }
}