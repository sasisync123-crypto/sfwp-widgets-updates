<?php
namespace SFWPStudio\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;
class Heading2 extends \Elementor\ElementsKit_Widget_Heading {
    use \ElementsKit_Lite\Widgets\Widget_Notice;
    use \SFWPStudio\Core\Helpers\Traits\ButtonTrait;
    use \SFWPStudio\Core\Helpers\Traits\ListTrait;
    use \SFWPStudio\Core\Helpers\Traits\ParaTrait;

    public function get_name()
    {
        return 'sf_heading_2';
    }

    public function get_title()
    {
        return __('SF Heading2', 'heading-elementor-widgets');
    }

    public function get_icon()
    {
        return 'sync-widget-icon eicon-tabs';
    }

    public function get_keywords()
    {
        return ['sf' ,'heading'];
    }

    //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS

    protected function register_controls(){

        parent::register_controls();

        $this->register_button_controls("One");

        $this->register_list_controls("no", "column");
        $this->register_para_controls("no");

        $this->remove_responsive_control( 'One_ekit_btn_align' );
        $this->remove_control( 'shadow_text_section' );
        $this->remove_control( 'shadow_text_style_section' );

        $this->update_control(
            'sf_paragraph_position',
            [
                'default' => 'before',
            ]
        );


        $this->update_control(
            'ekit_heading_show_seperator',
            [
                'default'   => '',        
            ]
        );

        $this->update_responsive_control(
			'ekit_heading_title_align', [
				'label'			 =>esc_html__( 'Left Alignment', 'elementskit-lite' ),
			]
		);
        
        $this->update_control(
            'ekit_heading_focused_title_color',
            [
                'default'   => '',
            ]
        );

        $this->update_responsive_control(
			'ekit_heading_focused_title_color_hover', [
				'default' => '',
			]
		);

        $this->update_responsive_control(
            'sf_list_spacing_margin',
            [
                'default' => [
                    'top'      => '',
                    'right'    => '',
                    'bottom'   => '0',
                    'left'     => '',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_heading_title_align',
        ]);

        $this->add_control(
            'content_alignment',
            [
                'label' => esc_html__( 'Right Alignment', 'elementskit-lite' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Left', 'elementskit-lite' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'elementskit-lite' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Right', 'elementskit-lite' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}} .sf-right-section' => 'align-items: {{VALUE}};',
                    '{{WRAPPER}} .sf-custom-list-wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_injection();

        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_heading_section_general',
        ]);

        $this->add_control(
            'show_button_position',
            [
                'label' => esc_html__( 'Button Position', 'elementskit-lite' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__( 'Left', 'elementskit-lite' ),
                    'right' => esc_html__( 'Right', 'elementskit-lite' ),
                    'center' => esc_html__( 'Center (Both)', 'elementskit-lite' ),
                ],
                'default' => 'center',
            ]
        );

        $this->add_responsive_control(
          'sf_heading_sections_gap',
            [
                'label' => esc_html__('Gap Between Sections', 'elementskit-lite'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-heading-widget' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        // ---------- LEFT SECTION WIDTH ----------
        $this->add_responsive_control(
        'sf_left_section_width',
        [
            'label'      => esc_html__('Left Section Width', 'heading-elementor-widgets'),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range'      => [
                'px' => ['min' => 100, 'max' => 1000],
                '%'  => ['min' => 10,  'max' => 90],
                'vw' => ['min' => 10,  'max' => 90],
            ],
            'selectors'  => [
                '{{WRAPPER}} .sf-left-section' => 'flex: 0 0 {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
            ],
        ]
        );

        // ---------- RIGHT SECTION WIDTH ----------
        $this->add_responsive_control(
        'sf_right_section_width',
        [
            'label'      => esc_html__('Right Section Width', 'heading-elementor-widgets'),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range'      => [
                'px' => ['min' => 100, 'max' => 1000],
                '%'  => ['min' => 10,  'max' => 90],
                'vw' => ['min' => 10,  'max' => 90],
            ],
            'selectors'  => [
                '{{WRAPPER}} .sf-right-section' => 'flex: 0 0 {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
            ],
        ]
        );

        // ---------- FLEX WRAP ----------
        $this->add_responsive_control(
        'sf_heading_flex_wrap',
        [
            'label'   => esc_html__('Flex Wrap', 'heading-elementor-widgets'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'wrap'    => esc_html__('Wrap', 'heading-elementor-widgets'),
                'nowrap'  => esc_html__('No Wrap', 'heading-elementor-widgets'),
            ],
            'default' => 'wrap',
            'selectors' => [
                '{{WRAPPER}} .sf-heading-widget' => 'flex-wrap: {{VALUE}};',
            ],
        ]
        );

        // ---------- JUSTIFY CONTENT ----------
        $this->add_responsive_control(
        'sf_heading_justify_content',
        [
            'label'   => esc_html__('Justify Content', 'heading-elementor-widgets'),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'flex-start'    => [
                    'title' => esc_html__('Start', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-h-align-left',
                ],
                'center'        => [
                    'title' => esc_html__('Center', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-h-align-center',
                ],
                'flex-end'      => [
                    'title' => esc_html__('End', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-h-align-right',
                ],
                'space-between' => [
                    'title' => esc_html__('Space Between', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-h-align-stretch',
                ],
                'space-around'  => [
                    'title' => esc_html__('Space Around', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-h-align-stretch',
                ],
                'space-evenly'  => [
                    'title' => esc_html__('Space Evenly', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-h-align-stretch',
                ],
            ],
            'default' => 'flex-start',
            'selectors' => [
                '{{WRAPPER}} .sf-heading-widget' => 'justify-content: {{VALUE}};',
            ],
        ]
        );

        // ---------- ALIGN ITEMS ----------
        $this->add_responsive_control(
        'sf_heading_align_items',
        [
            'label'   => esc_html__('Align Items', 'heading-elementor-widgets'),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'flex-start' => [
                    'title' => esc_html__('Top', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-v-align-top',
                ],
                'center'     => [
                    'title' => esc_html__('Middle', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-v-align-middle',
                ],
                'flex-end'   => [
                    'title' => esc_html__('Bottom', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-v-align-bottom',
                ],
                'stretch'    => [
                    'title' => esc_html__('Stretch', 'heading-elementor-widgets'),
                    'icon'  => 'eicon-v-align-stretch',
                ],
            ],
            'default' => 'flex-start',
            'selectors' => [
                '{{WRAPPER}} .sf-heading-widget' => 'align-items: {{VALUE}};',
            ],
        ]
        );

        $this->end_injection();

        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_heading_section_general',
        ]);

        $this->add_responsive_control(
            'sf_heading_widget_flex_direction',
            [
                'label' => esc_html__('Layout Direction', 'elementskit-lite'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'row' => [
                        'title' => esc_html__('Row', 'elementskit-lite'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'row-reverse' => [
                        'title' => esc_html__('Row Reverse', 'elementskit-lite'),
                        'icon' => 'eicon-h-align-right',
                    ],
                    'column' => [
                        'title' => esc_html__('Column', 'elementskit-lite'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'column-reverse' => [
                        'title' => esc_html__('Column Reverse', 'elementskit-lite'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sf-heading-widget' => 'flex-direction: {{VALUE}}; ',
                ],
            ]
        );
        $this->end_injection();
    }

    protected function render_raw() {
        $settings = $this->get_settings_for_display();
        $paragraph_position = $settings['sf_paragraph_position'] ?? 'before';
        $button_position = $this->get_settings_for_display('show_button_position');
        $settings = $this->get_settings_for_display();
        $alignment = $settings['ekit_heading_title_align'];

        $justify = 'flex-start'; 
        if ( $alignment === 'text_center' ) {
            $justify = 'center';
        } 
        elseif ( $alignment === 'text_right' ) {
            $justify = 'flex-end';
        }

        echo '<div class="sf-heading-widget">';
        echo '<div class="sf-left-section">';

        parent::render_raw();
        if ( $button_position === 'left' || $button_position === 'center' ) {
            echo '<div class="sf-heading-button-div" style="justify-content: ' . esc_attr( $justify ) . ';">';
            $this->render_button("One");
            echo '</div>';
        }
        echo '</div>';

        echo '<div class="sf-right-section">';
        if ($paragraph_position === 'before') {
            $this->render_para();
            $this->render_list();
        }
        else {
            $this->render_list();
            $this->render_para();   
        }
        if ( $button_position === 'right' || $button_position === 'center' ) {
            $this->render_button("One");
        }
        echo '</div>';
        echo '</div>';
    }

}