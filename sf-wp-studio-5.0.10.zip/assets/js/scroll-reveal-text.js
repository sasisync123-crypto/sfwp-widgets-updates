(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf_scroll_word_reveal.default', function ($scope) {
            setTimeout(() => textReveal($scope), 0);
        });
    });
 
    function textReveal($scope) {
        const wrappers = $scope.find(".scroll-wrapper");
 
        wrappers.each(function () {
            const wrapper = $(this)[0];
            const containers = wrapper.querySelectorAll("#scrollText");
            if (!containers.length) return;
 
            const headingContainer = Array.from(containers).find(c => c.classList.contains('text_heading'));
            const descriptionContainer = Array.from(containers).find(c => c.classList.contains('text_description'));
 
            const headingSpans = headingContainer ? (() => {
                const words = headingContainer.textContent.trim().split(/\s+/);
                headingContainer.innerHTML = words.map(word => `<span>${word} </span>`).join("");
                return headingContainer.querySelectorAll("span");
            })() : null;
 
            const descriptionSpans = descriptionContainer ? (() => {
                const words = descriptionContainer.textContent.trim().split(/\s+/);
                descriptionContainer.innerHTML = words.map(word => `<span>${word} </span>`).join("");
                return descriptionContainer.querySelectorAll("span");
            })() : null;
 
            const completionOffset = 300;
            const totalHeadingWords = headingSpans ? headingSpans.length : 0;
            const totalDescriptionWords = descriptionSpans ? descriptionSpans.length : 0;
 
            const updateActiveWords = () => {
                const rect = wrapper.getBoundingClientRect();
 
                if (rect.top <= 0 && rect.bottom > 0) {
                    const scrollOffset = Math.abs(rect.top);
                    const scrollRange = Math.max(1, rect.height - window.innerHeight - completionOffset);
                    const progress = Math.min(scrollOffset / scrollRange, 1);
 
                    if (headingContainer && headingSpans) {
                        const headingProgress = totalDescriptionWords > 0 ? Math.min(progress / 0.5, 1) : progress;
                        const headingWordIndex = Math.floor(headingProgress * totalHeadingWords);
                        headingSpans.forEach((span, index) => {
                            span.classList.toggle("active", index <= headingWordIndex);
                        });
 
                        if (headingProgress >= 1 && descriptionContainer && descriptionSpans) {
                            const descriptionProgress = Math.min((progress - 0.5) / 0.5, 1);
                            const descriptionWordIndex = Math.floor(descriptionProgress * totalDescriptionWords);
                            descriptionSpans.forEach((span, index) => {
                                span.classList.toggle("active", index <= descriptionWordIndex);
                            });
                        } else if (descriptionSpans) {
                            descriptionSpans.forEach(span => span.classList.remove("active"));
                        }
                    } else if (descriptionContainer && descriptionSpans) {
                        const descriptionProgress = progress;
                        const descriptionWordIndex = Math.floor(descriptionProgress * totalDescriptionWords);
                        descriptionSpans.forEach((span, index) => {
                            span.classList.toggle("active", index <= descriptionWordIndex);
                        });
                    }
                } else {
                    headingSpans?.forEach(span => span.classList.remove("active"));
                    descriptionSpans?.forEach(span => span.classList.remove("active"));
                }
            };
 
            window.addEventListener("scroll", updateActiveWords, { passive: true });
            updateActiveWords();
        });
    }
})(jQuery);