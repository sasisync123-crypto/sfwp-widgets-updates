<?php
namespace SFWPStudio\Core\Helpers\Traits;

    if (!defined('ABSPATH')) {
        exit;
    }

    use Elementor\Controls_Manager;
    use Elementor\Group_Control_Background;
    use Elementor\Group_Control_Box_Shadow;
    use Elementor\Group_Control_Typography;
    use Elementor\Group_Control_Border;

    trait BadgeTrait
    {
        /**
         * Register badge controls for the Elementor widget.
         */
        protected function register_badge_controls()
        {
            $this->start_controls_section(
                'ekit_icon_box_badge_control_tab',
                [
                    'label' => esc_html__( 'Badge', 'sf-widget' ),
                    'tab' => Controls_Manager::TAB_CONTENT,
                ]
            );

            $this->add_control(
                'ekit_icon_box_badge_control',
                [
                    'label' => esc_html__( 'Show Badge', 'sf-widget' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Show', 'sf-widget' ),
                    'label_off' => esc_html__( 'Hide', 'sf-widget' ),
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );
            $this->add_control(
                'ekit_icon_box_badge_title',
                [
                    'label' => esc_html__( 'Title', 'sf-widget' ),
                    'type' => Controls_Manager::TEXT,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => esc_html__( 'EXCLUSIVE', 'sf-widget' ),
                    'placeholder' => esc_html__( 'Type your title here', 'sf-widget' ),
                    'condition' => [
                        'ekit_icon_box_badge_control' => 'yes'
                    ]
                ]
            );

            $this->add_control(
                'ekit_icon_box_badge_position',
                [
                    'label' => esc_html__( 'Position', 'sf-widget' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'top_left',
                    'options' => [
                        'top_left'  => esc_html__( 'Top Left', 'sf-widget' ),
                        'top_center' => esc_html__( 'Top Center', 'sf-widget' ),
                        'top_right' => esc_html__( 'Top Right', 'sf-widget' ),
                        'center_left' => esc_html__( 'Center Left', 'sf-widget' ),
                        'center_right' => esc_html__( 'Center Right', 'sf-widget' ),
                        'bottom_left' => esc_html__( 'Bottom Left', 'sf-widget' ),
                        'bottom_center' => esc_html__( 'Bottom Center', 'sf-widget' ),
                        'bottom_right' => esc_html__( 'Bottom Right', 'sf-widget' ),
                        'custom' => esc_html__( 'Custom', 'sf-widget' ),
                    ],
                    'condition' => [
                        'ekit_icon_box_badge_control' => 'yes'
                    ]
                ]
            );

            $this->add_responsive_control(
                'badge_arrow_horizontal_position',
                [
                    'label' => esc_html__( 'Horizontal Position', 'sf-widget' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -1000,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => -1000,
                            'max' => 1000,
                        ],
                    ],
                    'desktop_default' => [
                        'size' => 0,
                        'unit' => 'px',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ekit-wid-con .ekit-widget-badge' => 'left: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'ekit_icon_box_badge_position'  => 'custom'
                    ]
                ]
            );

            $this->add_responsive_control(
                'badge_arrow_horizontal_position_vertial',
                [
                    'label' => esc_html__( 'Vertical Position', 'sf-widget' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -1000,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => -1000,
                            'max' => 1000,
                        ],
                    ],
                    'desktop_default' => [
                        'size' => 0,
                        'unit' => 'px',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .ekit-wid-con .ekit-widget-badge' => 'top: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'ekit_icon_box_badge_position'  => 'custom'
                    ]
                ]
            );

            $this->end_controls_section();

            $this->start_controls_section(
                'ekit_icon_box_badge_style_tab',
                [
                    'label' => esc_html__('Badge', 'sf-widget'),
                    'tab' => Controls_Manager::TAB_STYLE,
                    'condition' => [
                        'ekit_icon_box_badge_control' => 'yes',
                        'ekit_icon_box_badge_title!' => '',
                    ],
                ]
            );

            $this->start_controls_tabs('badge_style_tabs');

            // Normal Tab
            $this->start_controls_tab(
                'badge_tab_normal',
                [
                    'label' => esc_html__('Normal', 'sf-widget'),
                ]
            );

            $this->add_control(
                'badge_text_color',
                [
                    'label' => esc_html__('Color', 'sf-widget'),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ekit-badge' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'ekit_icon_box_badge_background',
                    'label' => esc_html__('Background', 'sf-widget'),
                    'types' => ['classic', 'gradient'],
                    'selector' => '{{WRAPPER}} .ekit-badge',
                ]
            );

            $this->end_controls_tab();

            // Hover Tab
            $this->start_controls_tab(
                'badge_tab_hover',
                [
                    'label' => esc_html__('Hover', 'sf-widget'),
                ]
            );

            $this->add_control(
                'badge_text_color_hover',
                [
                    'label' => esc_html__('Color', 'sf-widget'),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .ekit-badge:hover' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'ekit_icon_box_badge_background_hover',
                    'label' => esc_html__('Background', 'sf-widget'),
                    'types' => ['classic', 'gradient'],
                    'selector' => '{{WRAPPER}} .ekit-badge:hover',
                ]
            );

            $this->end_controls_tab();
            $this->end_controls_tabs();

            $this->add_control(
                'badge_divider',
                [
                    'type' => Controls_Manager::DIVIDER,
                    'style' => 'solid',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'ekit_badge_border_group',
                    'selector' => '{{WRAPPER}} .ekit-badge',
                ]
            );

            $this->add_responsive_control(
                'ekit_icon_box_badge_border_radius',
                [
                    'label' => esc_html__('Border Radius', 'sf-widget'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'em'],
                    'selectors' => [
                        '{{WRAPPER}} .ekit-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'ekit_icon_box_badge_box_shadow',
                    'selector' => '{{WRAPPER}} .ekit-badge',
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'ekit_icon_box_badge_typography',
                    'selector' => '{{WRAPPER}} .ekit-badge',
                ]
            );

            $this->add_responsive_control(
                'badge_padding',
                [
                    'label' => __('Padding', 'plugin-name'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'em'],
                    'selectors' => [
                        '{{WRAPPER}} .ekit-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            
            $this->end_controls_section();
        }

        protected function render_badge() {
            $settings = $this->get_settings_for_display();
            
            if ($settings['ekit_icon_box_badge_control'] === 'yes' && !empty($settings['ekit_icon_box_badge_title'])) {
                echo '<div class="ekit-widget-badge ekit_position_' . esc_attr($settings['ekit_icon_box_badge_position']) . '" style="position: absolute; z-index: 10; line-height: 1;">';
                echo '<span class="ekit-badge">' . esc_html($settings['ekit_icon_box_badge_title']) . '</span>';
                echo '</div>';
            }
        }


    }