<?php
namespace SFWPStudio\Widgets;

use Elementor\Controls_Manager;
use Elementor\Icons_Manager;

if (!defined('ABSPATH')) {
    exit;
}

class Stylish_List extends \Elementor\ElementsKit_Widget_Stylish_List
{

    public function get_name()
    {
        return 'sf-stylish-list';
    }

    public function get_title()
    {
        return __('SF Stylish List', 'sfwpstudio');
    }

    public function get_icon()
    {
        return 'eicon-bullet-list';
    }

    public function get_script_depends()
    {
        return ['stylish-list'];
    }

    //SFWP CODE STARTS
    public function get_categories()
    {
        return ['syncfusion-widgets'];
    }

    public function is_dynamic_content(): bool
    {
        return false;
    }
    //SFWP CODE ENDS
    protected function _register_controls()
    {
        parent::register_controls();

        $this->update_control(
            'ekit_stylish_list_icon_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-icon > i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ekit-stylish-list-content-icon > svg path' => 'stroke: {{VALUE}} !important;',
                    '{{WRAPPER}} .ekit-stylish-list-content-icon > img' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->update_control(
            'ekit_stylish_list_title_hover_color',
            [
                'label' => esc_html__('Hover Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper:hover .ekit-stylish-list-content-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_stylish_list_divider',
        ]);

        $this->add_control(
            'ekit_stylish_list_active_list',
            [
                'label' => esc_html__('Enable Default Active List?', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_injection();

        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_section_common_style',
        ]);

        $this->add_responsive_control(
            'ekit_stylish_list_content_gap',
            [
                'label' => esc_html__('Gap', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                    'em' => ['min' => 0, 'max' => 10],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ekit_stylish_list_content_width',
            [
                'label' => esc_html__('Width', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vw', '%'],
                'default' => [
                    'unit' => 'px',
                    'size' => 230,
                ],
                'range' => [
                    'px' => ['min' => 100, 'max' => 300],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .list-color' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
			'stylish_list_justify',
			[
				'label' => esc_html__('Justify List Content', 'elementskit'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__('Left', 'elementskit'),
						'icon' => 'eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__('Center', 'elementskit'),
						'icon' => 'eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__('Right', 'elementskit'),
						'icon' => 'eicon-justify-end-h',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .list-color' => 'justify-content: {{VALUE}};',
				]
			]
		);

        $this->end_injection();

        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_stylish_list_border_border',
        ]);

        $this->add_control(
            'use_gradient_border',
            [
                'label' => esc_html__('Use Gradient Border Color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_1',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => '--grad-color-1: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_2',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => '--grad-color-2: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_3',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => '--grad-color-3: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border' => 'yes',
                ],
            ]
        );

        $this->end_injection();


        $this->start_injection([
            'at' => 'after',
            'of' => 'ekit_stylish_list_border_hover_border',
        ]);

        $this->add_control(
            'use_gradient_border_hover',
            [
                'label' => esc_html__('Use Gradient Border Color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'hover_border_color',
            [
                'label' => esc_html__('Border Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_1_hover',
            [
                'label' => __('Gradient Border Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => '--grad-color-1-hover: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_2_hover',
            [
                'label' => __('Gradient Border Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => '--grad-color-2-hover: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'gradient_color_3_hover',
            [
                'label' => __('Gradient Border Color 3', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper' => '--grad-color-3-hover: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_border_hover' => 'yes',
                ],
            ]
        );

        $this->end_injection();

        $this->start_injection([
            'at' => 'before',
            'of' => 'ekit_stylish_list_icon_hover_color',
        ]);

        $this->add_control(
            'use_gradient_hover',
            [
                'label' => esc_html__('Use Gradient Color', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'ekit_stylish_list_icon_gradient_color_1',
            [
                'label' => __('Gradient Color 1', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-icon' => '--icon-grad-color-1: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_hover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'ekit_stylish_list_icon_gradient_color_2',
            [
                'label' => __('Gradient Color 2', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-icon' => '--icon-grad-color-2: {{VALUE}};',
                ],
                'condition' => [
                    'use_gradient_hover' => 'yes',
                ],
            ]
        );

        $this->end_injection();

        $this->update_control(
            'ekit_stylish_list_icon_hover_color',
            [
                'label' => esc_html__('Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper:hover .ekit-stylish-list-content-icon > i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper:hover .ekit-stylish-list-content-icon > img' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ekit-stylish-list-content-wrapper:hover .ekit-stylish-list-content-icon > svg path' => 'stroke: {{VALUE}} !important;',
                ],
                'condition' => [
                    'use_gradient_hover!' => 'yes',
                ],
            ]
        );

        $this->update_control(
            'ekit_stylist_lists',
            [
                'default' => [
                    [
                        'title' => esc_html__('List Item 1', 'sf-widget'),
                        'description' => esc_html__('Description for item 1', 'sf-widget'),
                    ],
                    [
                        'title' => esc_html__('List Item 2', 'sf-widget'),
                        'description' => esc_html__('Description for item 2', 'sf-widget'),
                    ],
                    [
                        'title' => esc_html__('List Item 3', 'sf-widget'),
                        'description' => esc_html__('Description for item 3', 'sf-widget'),
                    ],
                ],
            ]
        );

        $this->update_control(
            'ekit_stylish_list_type',
            [
                'default' => 'row',
            ]
        );

        $this->update_control(
            'ekit_stylish_list_padding',
            [
                'default' => [
                    'unit' => 'px',
                    'top' => '',
                    'left' => '',
                    'bottom' => '',
                    'right' => '',
                ],
            ]
        );

        $this->update_control(
            'ekit_stylish_list_border_radius',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
            ]
        );

        $this->update_control(
            'ekit_stylish_list_icon_size',
            [
                'label' => esc_html__('Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'default' => [
                    'unit' => 'px',
                    'size' => '',
                ],
            ]
        );

        $this->update_control(
            'ekit_stylish_list_title_color',
            [
                'default' => '',
            ]
        );

        $this->update_control(
            'ekit_stylish_list_align_item',
            [
                'default' => 'center'
            ]
        );
         
        $this->update_control(
            'ekit_stylish_list_icon_hover_color',
            [
                'default' => ''
            ]
        );

        $this->update_control(
            'ekit_stylish_list_icon_margin',
            [
                'label' => esc_html__('Margin', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-stylish-list-content-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    }

    protected function render_raw()
    {
        $settings = $this->get_settings_for_display();
        extract($settings);

        $list_type_class = $ekit_stylish_list_type == 'row' ? 'list-inline' : '';
        $divider_class = $ekit_stylish_list_type == 'row' ? '-inline' : '';

        $entrance_animation = '';
        $animation_duration = '';

        if ($ekit_stylish_list_animation_use == 'yes') {
            $entrance_animation = "data-ekit-animation= $ekit_stylish_list_entrance_animation";
            $animation_duration = ' animated-' . $ekit_stylish_list_animation_duration;
        } ?>

        <ul id="myHeader" class="ekit-stylish-list <?php echo esc_attr($list_type_class) ?>" <?php echo esc_attr($entrance_animation); ?>>
            <?php foreach ($ekit_stylist_lists as $index => $list):
                $animation_delay = $ekit_stylish_list_animation_use == 'yes' ? (' data-ekit-delay=' . $ekit_stylish_list_animation_delay * $index * 1000) : '';
                ?>
                <li class="stylish">
                    <div class="list-color ekit-stylish-list-content-wrapper elementor-repeater-item-<?php echo esc_attr($list['_id'] . $animation_duration); ?>"
                        <?php echo esc_attr($animation_delay); ?>
                        data-gradient-border="<?php echo esc_attr($settings['use_gradient_border']); ?>"
                        data-gradient-border-hover="<?php echo esc_attr($settings['use_gradient_border_hover']); ?>">
                        <div class="">
                            <?php if (!empty($list['link']['url'])):
                                $this->add_link_attributes('link' . $list['_id'], $list['link']); ?>
                                <a class="ekit-wrapper-link <?php echo ('yes' === $settings['ekit_stylish_list_active_list'] && 0 === $index) ? 'active' : ''; ?>"
                                    <?php $this->print_render_attribute_string('link' . $list['_id']); ?>></a>
                            <?php endif; ?>

                            <div class="ekit-stylish-list-content">
                                <?php if ($ekit_stylish_list_counter == 'yes'): ?>
                                    <div class="ekit-stylish-list-content-counter"></div>
                                <?php endif; ?>
                                <?php if ($list['media_type'] == 'icon' && !empty($list['icon']['value'])): ?>
                                    <div class="ekit-stylish-list-content-icon"
                                        data-gradient="<?php echo esc_attr($settings['use_gradient_hover']); ?>">
                                        <?php Icons_Manager::render_icon($list['icon'], ['aria-hidden' => 'true']); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($list['media_type'] == 'image' && !empty($list['image']['id'])): ?>
                                    <div class="ekit-stylish-list-content-icon"
                                        data-gradient="<?php echo esc_attr($settings['use_gradient_hover']); ?>">
                                        <?php echo wp_kses(wp_get_attachment_image($list['image']['id'], 'full', false, ''), \ElementsKit_Lite\Utils::get_kses_array()); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="ekit-stylish-list-content-text">
                                    <span
                                        class="ekit-stylish-list-content-title"><?php echo wp_kses($list['title'], \ElementsKit_Lite\Utils::get_kses_array()) ?></span>
                                    <?php if (!empty($list['description'])): ?>
                                        <span
                                            class="ekit-stylish-list-content-description"><?php echo wp_kses($list['description'], \ElementsKit_Lite\Utils::get_kses_array()); ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($list['badge_show'] == 'yes'): ?>
                                    <div class="ekit-stylish-list-content-badge">
                                        <span class="elementor-inline-editing"><?php echo esc_html($list['badge_title']); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="blob"></div>
                            <div class="fakeblob"></div>
                        </div>

                    </div>
                </li>
                <?php if ($ekit_stylish_list_divider == 'yes'): ?>
                    <div class="ekit-stylish-list-divider<?php echo esc_attr($divider_class) ?>"></div>
                <?php endif; ?>
            <?php endforeach; ?>
        </ul>
        <?php
    }
}