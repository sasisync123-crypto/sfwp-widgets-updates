<?php


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

//All Trait Is Loaded
foreach ( glob( __DIR__ . '/helpers/traits/*.php' ) as $trait_file ) {
    require_once $trait_file;
}



//Container Extension Loaded
$container_file= SFWP_DIR.'core/extensions/hooked-widgets/container-extension.php';
if( file_exists( $container_file ) ) {
    require_once $container_file;
    \SFWPStudio\Core\Extensions\HookedWidgets\Container_Extension::instance();
}


