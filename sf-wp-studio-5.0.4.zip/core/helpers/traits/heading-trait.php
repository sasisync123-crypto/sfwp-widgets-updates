<?php
namespace SFWPStudio\Core\Helpers\Traits;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH')) exit;

trait HeadingTrait
{
    protected function register_heading_controls()
    {
        // HEADING SECTION
        $this->start_controls_section(
            'section_heading',
            [
                'label' => __('Heading', 'elementor-avatar-widget'),
            ]
        );

        $this->add_control(
            'avatar_heading',
            [
                'label' => __('Heading Text', 'elementor-avatar-widget'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Human Resources Manager', 'elementor-avatar-widget'),
                'placeholder' => __('Add Your heading Text Here', 'elementor-avatar-widget'),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'avatar_heading_tag',
            [
                'label' => __('Heading Tag', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'h6',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p' => 'p',
                    'div' => 'div',
                    'span' => 'span',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => __('Show Title', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'elementor-avatar-widget'),
                'label_off' => __('No', 'elementor-avatar-widget'),
                'return_value' => 'yes',
                'default' => 'No',
            ]
        );

        $this->add_control(
            'title_position',
            [
                'label' => __('Title Position', 'elementor-avatar-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'above' => __('Above Avatar', 'elementor-avatar-widget'),
                    'below' => __('Below Avatar', 'elementor-avatar-widget'),
                    'before' => __('Left Avatar', 'elementor-avatar-widget'),
                    'after' => __('Right Avatar', 'elementor-avatar-widget'),
                ],
                'default' => 'above',
            ]
        );

        $this->end_controls_section();
    }

    protected function render_heading($settings, $position = null)
    {
        $heading = $settings['avatar_heading'];
        $heading_tag = $settings['avatar_heading_tag'];
        $title_position = $position ?? ($settings['title_position'] ?? 'above');

        if ($settings['show_title'] === 'yes' && !empty($heading)) {
            // Render only if position matches or no specific position provided
            if ($position === null || $title_position === $position) {
                echo '<' . esc_attr($heading_tag) . ' class="avatar-heading">' . esc_html($heading) . '</' . esc_attr($heading_tag) . '>';
            }
        }
    }

    protected function register_heading_style_controls()
    {
        // HEADING STYLE SECTION
        $this->start_controls_section(
            'section_heading_style',
            [
                'label' => __('Heading', 'elementor-avatar-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_title' => 'yes', // Show this section only if show_title is 'yes'
                ],
            ]
        );

        $this->add_control(
            'heading_text_color',
            [
                'label' => __('Text Color', 'elementor-avatar-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'var(--e-global-color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .avatar-heading' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'heading_hover_color',
            [
                'label' => __('Hover Color', 'elementor-avatar-widget'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .avatar-heading:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'heading_text_shadow',
                'label' => __('Text Shadow', 'elementor-avatar-widget'),
                'selector' => '{{WRAPPER}} .avatar-heading',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Heading Typography', 'elementor-avatar-widget'),
                'selector' => '{{WRAPPER}} .avatar-heading',
            ]
        );

        $this->add_responsive_control(
            'heading_alignment',
            [
                'label' => __('Alignment', 'elementor-avatar-widget'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'elementor-avatar-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-heading' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'heading_padding',
            [
                'label' => __('Padding', 'elementor-avatar-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .avatar-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'heading_margin',
            [
                'label' => __('Margin', 'elementor-avatar-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'default' => [
                    'top' => 10,
                    'right' => 0,
                    'bottom' => 10,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .avatar-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }
}
