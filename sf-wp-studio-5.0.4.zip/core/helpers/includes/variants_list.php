<?php
return [
  'style-1'   => __('Style 1', 'plugin-name'),
  'style-2' => __('Style 2', 'plugin-name'),
];