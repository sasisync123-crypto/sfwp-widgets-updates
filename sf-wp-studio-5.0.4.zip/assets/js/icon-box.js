(function ($) {
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/sf-icon-box.default', function ($scope) {
            const cards = document.querySelectorAll(".card");
 
            cards.forEach((card) => {
                const blob = card.querySelector(".blob");
                const fblob = card.querySelector(".fakeblob");
 
                // Show glow on mouse enter
                card.addEventListener("mouseenter", () => {
                    blob.style.opacity = "1";
                });
 
                // Animate glow on mouse move
                card.addEventListener("mousemove", (ev) => {
                    const rec = fblob.getBoundingClientRect();
 
                    blob.animate(
                        [
                            {
                                transform: `translate(${
                                    (ev.clientX - rec.left) - (rec.width / 2)
                                }px,${(ev.clientY - rec.top) - (rec.height / 2)}px)`
                            }
                        ],
                        {
                            duration: 300,
                            fill: "forwards"
                        }
                    );
                });
 
                // Hide glow on mouse leave
                card.addEventListener("mouseleave", () => {
                    blob.style.opacity = "0";
                });
            });
        });
    });
})(jQuery);
 
 