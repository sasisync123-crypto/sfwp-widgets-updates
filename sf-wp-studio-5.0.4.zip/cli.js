#!/usr/bin/env node
import { Command } from 'commander';
import inquirer from 'inquirer';
import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import simpleGit from 'simple-git';

const program = new Command();
const PLUGIN_NAME = 'sf-wp-studio';

async function zipSourceFolder(version, targetDir) {
  const zipPath = path.join(targetDir, `${PLUGIN_NAME}-${version}.zip`);
  const output = fs.createWriteStream(zipPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(process.cwd(), false); // zip current folder
    archive.finalize();
  });
}

function writeUpdateJson(version, description, targetDir, branch, baseUrl) {
  const jsonPath = path.join(targetDir, 'update.json');
  const jsonData = {
    name: 'Sasi widget',
    version,
    download_url: `${baseUrl}/${PLUGIN_NAME}-${version}.zip`,
    sections: { description }
  };
  fs.writeFileSync(jsonPath, JSON.stringify(jsonData, null, 2));
}

async function pushProductionFolder(version, targetDir, repoUrl, branch) {
  const git = simpleGit(targetDir);
  const remotes = await git.getRemotes(true);
  if (!remotes.some(r => r.name === 'origin')) {
    await git.addRemote('origin', repoUrl);
  }
  await git.add(['*.zip', 'update.json']);
  await git.commit(`Deploy version ${version}`);
  await git.push('origin', branch);
}

async function deploy() {
  const answers = await inquirer.prompt([
    { type: 'input', name: 'version', message: 'Enter version number:' },
    { type: 'input', name: 'description', message: 'Enter description:', default: 'Powerful widget from sfwp team' },
    { type: 'input', name: 'targetDir', message: 'Enter target directory:', default: 'D:/Browser-Downloads/sfwp-widgets-updates' },
    { type: 'input', name: 'repoUrl', message: 'Enter repo URL (SSH):', default: 'git@github.com:sasisync123-crypto/sfwp-widgets-updates.git' },
    { type: 'input', name: 'branch', message: 'Enter branch name:', default: 'main' },
    { type: 'input', name: 'baseUrl', message: 'Enter zip file base URL:', default: 'https://github.com/sasisync123-crypto/sfwp-widgets-updates/raw/main' }
  ]);

  const { version, description, targetDir, repoUrl, branch, baseUrl } = answers;

  await zipSourceFolder(version, targetDir);
  writeUpdateJson(version, description, targetDir, branch, baseUrl);
  await pushProductionFolder(version, targetDir, repoUrl, branch);

  console.log(`✅ Deployed ${version} to ${repoUrl} on branch ${branch}`);
}

program.command('deploy').description('Deploy plugin').action(deploy);
program.parse(process.argv);
