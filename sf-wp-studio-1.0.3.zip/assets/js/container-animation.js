(function () {
    function observeContainer(container) {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('sf-in-view');
                        observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold: 0.15,
                rootMargin: '0px 0px -100px 0px'
            }
        );
        observer.observe(container);
    }
 
    function scanAndObserve() {
        const selector =
            '.elementor-element[class^="sf-animation-"], .elementor-element[class*=" sf-animation-"]';

        document.querySelectorAll(selector).forEach(observeContainer);

        const mutationObserver = new MutationObserver((mutations) => {
            mutations.forEach((mut) => {
                mut.addedNodes.forEach((node) => {
                    if (node.nodeType !== 1) return;

                    if (node.matches && node.matches(selector)) {
                        observeContainer(node);
                    }

                    if (node.querySelectorAll) {
                        node.querySelectorAll(selector).forEach(observeContainer);
                    }
                });
            });
        });

        mutationObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    if (
        document.body.classList.contains('elementor-editor-active') ||
        document.body.classList.contains('elementor-editor-preview')
    ) {
        const waitForPreview = setInterval(() => {
            if (document.body && document.querySelector('.elementor')) {
                clearInterval(waitForPreview);
                scanAndObserve();
            }
        }, 100);
    } else {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', scanAndObserve);
        } else {
            scanAndObserve();
        }
    }
})();