<?php
// namespace SFWpStudio\Traits;
namespace SFWPStudio\Core\Helpers\Traits;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Conditions;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

// Group Controls
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;

// Media & Icons
use Elementor\Icons_Manager;
use Elementor\Control_Media;

// Other Control Types
use Elementor\Control_Select2;
use Elementor\Control_Slider;
use Elementor\Control_Switcher;
use Elementor\Control_Heading;
use Elementor\Control_Textarea;
use Elementor\Control_Number;
use Elementor\Control_Dimensions;
use Elementor\Control_Color;
use Elementor\Control_Gallery;
use Elementor\Control_Date_Time;
use Elementor\Control_Code;

// Schemes
use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;

// Utilities & Core
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Core\Base\Document;
use Elementor\Core\Responsive\Responsive;
use Elementor\Core\Kits\Documents\Kit;
use Elementor\Core\Settings\Manager;

trait ButtonTrait
{
    protected function register_button_controls($prefix = '', $tab_title_label = '')
    {
        // Use prefix to make control IDs unique
        $control_prefix = !empty($prefix) ? $prefix . '_' : '';

        $this->start_controls_section(
            $control_prefix . 'ekit_btn_section_content',
            array(
                'label' => esc_html__('Button ' . $tab_title_label, 'sf-widget'),
            )
        );

        $this->add_control(
            $control_prefix . 'show_button_sf_controls',
            [
                'label' => esc_html__('Show Button', 'sf-widget'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_text',
            [
                'label' => esc_html__('Label', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn more ', 'sf-widget'),
                'placeholder' => esc_html__('Learn more ', 'sf-widget'),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_url',
            [
                'label' => esc_html__('URL', 'sf-widget'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_url('https://wpmet.com'),
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => '#',
                ],
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_section_settings',
            [
                'label' => esc_html__('Settings', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_icons__switch',
            [
                'label' => esc_html__('Add icon? ', 'sf-widget'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => esc_html__('Yes', 'sf-widget'),
                'label_off' => esc_html__('No', 'sf-widget'),
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_icons',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => $control_prefix . 'ekit_btn_icon',
                'label_block' => true,
                'default' => [
                    'value' => '',
                ],
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes',
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_icon_align',
            [
                'label' => esc_html__('Icon Position', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => esc_html__('Before', 'sf-widget'),
                    'right' => esc_html__('After', 'sf-widget'),
                ],
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes',
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_align',
            [
                'label' => esc_html__('Alignment', 'sf-widget'),
                'type' => Controls_Manager::CHOOSE,
                'default' => 'center',
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'sf-widget'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'sf-widget'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'sf-widget'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors_dictionary' => [
                    'left' => 'justify-content: flex-start;',
                    'center' => 'justify-content: center;',
                    'right' => 'justify-content: flex-end;',
                ],
                'prefix_class' => 'elementor-align-%s',
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => '{{VALUE}};',
                ],
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_class',
            [
                'label' => esc_html__('Class', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('Class Name', 'sf-widget'),
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_id',
            [
                'label' => esc_html__('id', 'sf-widget'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('ID', 'sf-widget'),
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes'
                ]
            ]
        );

        // SF Button Type variant Options added here
        do_action('sf_button_variant_options',$this,$control_prefix, $prefix);

        $this->end_controls_section();

        $this->start_controls_section(
            $control_prefix . 'ekit_btn_section_style',
            [
                'label' => esc_html__('Button ' . $tab_title_label, 'sf-widget'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    $control_prefix . 'show_button_sf_controls' => 'yes',
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'width',
            [
                'label' => esc_html__('Width (%)', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => 'width: {{SIZE}}%;',
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . '_ekit_btn_text_padding_1',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . '_button_size' => 'md',
                ],
            ]
        );

        $this->add_responsive_control(
            $control_prefix . '_ekit_btn_text_padding_2',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . '_button_size' => 'sm',
                ],
            ]
        );
        $this->add_responsive_control(
            $control_prefix . '_ekit_btn_text_padding_3',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . '_button_size' => 'lg',
                ],
            ]
        );
        $this->add_responsive_control(
            $control_prefix . '_ekit_btn_text_padding_4',
            [
                'label' => esc_html__('Padding', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . '_button_size' => 'xl',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => $control_prefix . 'ekit_btn_typography',
                'label' => esc_html__('Typography', 'sf-widget'),
                'selector' => '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => $control_prefix . 'ekit_btn_shadow',
                'selector' => '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn',
            ]
        );

        // Background Tabs for Default and Flat
        $this->start_controls_tabs($control_prefix . 'background_tabs');

        $this->add_control(
            $control_prefix . 'ekit_btn_text_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Stacked'],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => $control_prefix . 'background_normal',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn',
                'fields_options' => [
                    'gradient_type' => [
                        'default' => 'linear',
                    ],
                    'gradient_angle' => [
                        'default' => [
                            'unit' => 'deg',
                            'size' => 250,
                        ],
                    ],
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Default'],
                ],
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_hover_color',
            [
                'label' => esc_html__('Text Color', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Default', 'Stacked'],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => $control_prefix . 'background_hover',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn:hover',
                'fields_options' => [
                    'gradient_type' => [
                        'default' => 'linear',
                    ],
                    'gradient_angle' => [
                        'default' => [
                            'unit' => 'deg',
                            'size' => 90,
                        ],
                    ],
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Default'],
                ],
            ]
        );

        $this->end_controls_tabs();

        // Border Controls for Flat and Outline
        $this->add_control(
            $control_prefix . 'ekit_btn_border_style_tabs',
            [
                'label' => esc_html__('Border', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_border_style2',
            [
                'label' => esc_html_x('Border Type', 'Border Control', 'sf-widget'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'sf-widget'),
                    'solid' => esc_html_x('Solid', 'Border Control', 'sf-widget'),
                    'double' => esc_html_x('Double', 'Border Control', 'sf-widget'),
                    'dotted' => esc_html_x('Dotted', 'Border Control', 'sf-widget'),
                    'dashed' => esc_html_x('Dashed', 'Border Control', 'sf-widget'),
                    'groove' => esc_html_x('Groove', 'Border Control', 'sf-widget'),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_border_dimensions',
            [
                'label' => esc_html_x('Width', 'Border Control', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [
                    $control_prefix . 'ekit_btn_border_style2!' => 'none',
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_border_color',
            [
                'label' => esc_html_x('Border Color', 'Border Control', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                    $control_prefix . 'ekit_btn_border_style2!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_border_radius_normal',
            [
                'label' => esc_html__('Border Radius', 'sf-widget'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ],
            ]
        );

        $this->add_control(
            $control_prefix . 'ekit_btn_hover_border_color',
            [
                'label' => esc_html_x('Hover Border Color', 'Border Control', 'sf-widget'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_icon_box_button_style_' => ['Flat', 'Outline'],
                ]
            ]
        );

        // Shadow Controls
        $this->add_control(
            $control_prefix . 'ekit_btn_box_shadow_style',
            [
                'label' => esc_html__('Shadow', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => $control_prefix . 'ekit_btn_box_shadow_group',
                'selector' => '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => $control_prefix . 'ekit_btn_hover_box_shadow_group',
                'label' => esc_html__('Hover Box Shadow', 'sf-widget'),
                'selector' => '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn:hover',
            ]
        );

        // Icon Controls
        $this->add_control(
            $control_prefix . 'ekit_btn_iconw_style',
            [
                'label' => esc_html__('Icon', 'sf-widget'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_normal_icon_font_size',
            [
                'label' => esc_html__('Font Size', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 14,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_normal_icon_padding_left',
            [
                'label' => esc_html__('Add space after icon', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > i, {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '.rtl {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > i, .rtl {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > svg' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: 0;',
                ],
                'condition' => [
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes',
                    $control_prefix . 'ekit_btn_icon_align' => 'left',
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_normal_icon_padding_right',
            [
                'label' => esc_html__('Add space before icon', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > i, {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '.rtl {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > i, .rtl {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn > svg' => 'margin-left: 0; margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes',
                    $control_prefix . 'ekit_btn_icon_align' => 'right',
                ]
            ]
        );

        $this->add_responsive_control(
            $control_prefix . 'ekit_btn_normal_icon_vertical_align',
            [
                'label' => esc_html__('Move icon Vertically', 'sf-widget'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => -20,
                        'max' => 20,
                    ],
                    'em' => [
                        'min' => -5,
                        'max' => 5,
                    ],
                    'rem' => [
                        'min' => -5,
                        'max' => 5,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn i, {{WRAPPER}} .ekit-btn-wraper-' . $control_prefix . ' .elementskit-btn svg' => '-webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}})',
                ],
                'condition' => [
                    $control_prefix . 'ekit_btn_icons__switch' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function render_button($prefix = '')
    {
        $settings = $this->get_settings_for_display();
        $control_prefix = !empty($prefix) ? $prefix . '_' : '';

        // Generate unique wrapper class
        $wrapper_class = 'ekit-btn-wraper-' . $control_prefix;

        if ($settings[$control_prefix . 'show_button_sf_controls'] === 'yes') {

            $btn_text = $settings[$control_prefix . 'ekit_btn_text'];
            $btn_class = !empty($settings[$control_prefix . 'ekit_btn_class']) ? $settings[$control_prefix . 'ekit_btn_class'] : '';
            $btn_id = !empty($settings[$control_prefix . 'ekit_btn_id']) ? $settings[$control_prefix . 'ekit_btn_id'] : '';

            $options_ekit_btn_icon_align = array_keys([
                'left' => esc_html__('Before', 'elementskit-lite'),
                'right' => esc_html__('After', 'elementskit-lite'),
            ]);

            $icon_align = \ElementsKit_Lite\Utils::esc_options($settings[$control_prefix . 'ekit_btn_icon_align'], $options_ekit_btn_icon_align, 'left');

            // Get button style and variant for dynamic class addition
            $style = $settings[$control_prefix . 'ekit_icon_box_button_style_'] ?? 'Default';
            $variant_class = '';

            // Add variant-specific class for Outline
            if ($style === 'Default') {
                $variant_class = ' default-btn';
            } elseif ($style === 'Flat') {
                $button_variant = $settings[$control_prefix . 'button_variant'] ?? 'primary';
                $variant_class = ' flat-' . $button_variant;
            } elseif ($style === 'Outline') {
                $outline_variant = $settings[$control_prefix . 'outline_variant'] ?? 'primary';
                $variant_class = ' outline-' . $outline_variant;
                if ($settings[$control_prefix . 'outline_hover_effect'] !== 'yes') {
                    $btn_class .= ' no-hover-fill';
                }
            } elseif ($style === 'Stacked') {
                $stacked_variant = $settings[$control_prefix . 'ekit_icon_box_stacked_'] ?? 'primary';
                $variant_class = ' stacked-' . $stacked_variant;
                $btn_class .= ' sf-widget-link-underline keydesign-underline';
            }

            // Append the variant-specific class
            $btn_class .= $variant_class;

            if (!empty($settings[$control_prefix . 'ekit_btn_url']['url'])) {
                $this->add_link_attributes('button_' . $control_prefix, $settings[$control_prefix . 'ekit_btn_url']);
            }

            $btn_class .= ' whitespace--normal';

            if ($style === 'Stacked') {
                $btn_class .= ' sf-widget-link-underline keydesign-underline';
            }

            // Add size-specific class
            $size = $settings[$control_prefix . '_button_size'] ?? 'md';
            $size_class = ' size-' . $size;

            // Combine all button classes
            $all_btn_classes = trim('elementskit-btn ' . $btn_class . $size_class);

            $this->add_render_attribute('button_' . $control_prefix, [
                'class' => $all_btn_classes,
                'id' => $btn_id
            ]);

            ?>
            <div class="<?php echo esc_attr($wrapper_class); ?> ekit-btn-inner">
                <a <?php $this->print_render_attribute_string('button_' . $control_prefix); ?>>
                    <?php if ($icon_align == 'right'): ?>
                        <?php echo esc_html($btn_text); ?>
                        <?php
                        // Add 'icon-after' class to the icon
                        \Elementor\Icons_Manager::render_icon(
                            $settings[$control_prefix . 'ekit_btn_icons'],
                            [
                                'aria-hidden' => 'true',
                                'class' => 'icon-after'
                            ]
                        );
                        ?>
                    <?php elseif ($icon_align == 'left'): ?>
                        <?php
                        // Add 'icon-before' class to the icon
                        \Elementor\Icons_Manager::render_icon(
                            $settings[$control_prefix . 'ekit_btn_icons'],
                            [
                                'aria-hidden' => 'true',
                                'class' => 'icon-before'
                            ]
                        );
                        echo esc_html($btn_text);
                        ?>
                    <?php else: ?>
                        <?php echo esc_html($btn_text); ?>
                    <?php endif; ?>
                </a>
            </div>
            <?php
        }
    }
}
