<?php
// Load core logic
require_once plugin_dir_path( __FILE__ ) . '../core/init.php';

// Register widgets
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
    foreach ( glob(  SFWP_DIR . 'widgets/*.php' ) as $widget_file ) {
        require_once $widget_file;

        $base_file_name = basename( $widget_file, '.php' );
        $class_name = str_replace( '-','_',ucfirst( $base_file_name ) );
        $namespaced_class = 'SFWPStudio\\Widgets\\' . $class_name;

        if ( class_exists( $namespaced_class ) ) {
            $widgets_manager->register( new $namespaced_class() );
        }
    }
});
 
add_action( 'elementor/frontend/after_enqueue_styles', function() {
    wp_enqueue_style( 'sfwp-global-style', plugin_dir_url( dirname(__FILE__) ) . 'assets/css/sfwp-global-style.css',['elementor-frontend', 'ekit-widget-styles', 'keydesign-frontend', 'sierra-global', 'ekit-widget-styles-pro'],'1.0' );
});

// To Include JS 
add_action('elementor/frontend/after_register_scripts', function () {
    $js_dir = plugin_dir_path(__FILE__) . '../assets/js/';
    $js_url = plugin_dir_url(__FILE__) . '../assets/js/';
 
    foreach (glob($js_dir . '*.js') as $file) {
        wp_register_script(
            basename($file, '.js'), // handle
            $js_url . basename($file),
            ['jquery'],             // dependencies
            filemtime($file),       // version
            true                    // in footer
        );
    }
});

add_action('elementor/frontend/after_enqueue_styles', function () {
    $css_dir = plugin_dir_path(__FILE__) . '../assets/css/';
    $css_url = plugin_dir_url(__FILE__) . '../assets/css/';
 
    foreach (glob($css_dir . '*.css') as $file) {
        wp_enqueue_style(
            basename($file, '.css'), // handle = file name without .css
            $css_url . basename($file),
            [],
            filemtime($file) // cache busting
        );
    }
});
 

// register category
add_action('elementor/elements/categories_registered', function($elements_manager) {
    $elements_manager->add_category(
        'syncfusion-widgets',
        [
            'title' => esc_html__('Syncfusion Widgets', 'sfwp-widget'),
        ]
    );
});


add_action('elementor/frontend/after_register_scripts', function () {
   
    $js_url = plugin_dir_url(__FILE__) . '../assets/js/container-animation.js';
 
       wp_enqueue_script(
        'animation',
            $js_url ,
            ['jquery'],
            true                  
        );
   
});